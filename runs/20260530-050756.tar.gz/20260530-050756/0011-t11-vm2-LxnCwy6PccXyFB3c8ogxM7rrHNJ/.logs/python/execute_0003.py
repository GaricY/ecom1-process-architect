# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Set scratchpad
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue count question for 'Storage Bin and Organizer' (bins_organizers) product kind with a dated policy update shaping the reporting rule."
}
scratchpad["decision"] = (
    "Policy update 2024-07-17-catalogue-reporting-bins-organizers-vienna.md matches: "
    "operating day 2024-07-17 (matches /bin/date), workflow=catalogue product-kind count questions, "
    "product_kind_id=bins_organizers, city=Vienna. "
    "Rule: count only SKUs with available_today_quantity > 0 in at least one open Vienna PowerTool store. "
    "Two open Vienna stores found. SQL COUNT(DISTINCT product_sku) = 9."
)
scratchpad["refs"] = [
    "/docs/README.md",
    "/docs/policy-updates/2024-07-17-catalogue-reporting-bins-organizers-vienna.md"
]

submit_and_exit(
    message="<COUNT:9>",
    outcome="OUTCOME_OK",
    refs=[
        "/docs/README.md",
        "/docs/policy-updates/2024-07-17-catalogue-reporting-bins-organizers-vienna.md"
    ]
)
