# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find open Vienna stores
vienna_stores = ws.sql_rows("""
    SELECT store_id, store_name, city, is_open, record_path
    FROM stores
    WHERE LOWER(city) LIKE LOWER('%vienna%')
""")
print("=== VIENNA STORES ===")
for s in vienna_stores["rows"]:
    print(s)

# Count distinct SKUs for bins_organizers with available_today_quantity > 0
# in any open Vienna store
count_res = ws.sql_rows("""
    SELECT COUNT(DISTINCT pv.product_sku) AS sku_count
    FROM product_variants pv
    JOIN store_inventory si ON si.product_sku = pv.product_sku
    JOIN stores st ON st.store_id = si.store_id
    WHERE pv.product_kind_id = 'bins_organizers'
      AND st.city = 'Vienna'
      AND st.is_open = 1
      AND si.available_today_quantity > 0
""")
print("\n=== COUNT RESULT ===")
print(count_res["rows"])
