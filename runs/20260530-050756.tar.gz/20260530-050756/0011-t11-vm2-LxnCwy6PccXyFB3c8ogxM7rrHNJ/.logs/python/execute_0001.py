# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Read the policy update file for bins/organizers
policy_update = ws.read("/docs/policy-updates/2024-07-17-catalogue-reporting-bins-organizers-vienna.md")
print("=== POLICY UPDATE ===")
print(policy_update["content"])

# Step 2: Check product_kinds to find "Storage Bin and Organizer"
kinds = ws.sql_rows("SELECT product_kind_id, product_kind_name, product_category_id FROM product_kinds")
print("\n=== PRODUCT KINDS ===")
for k in kinds["rows"]:
    print(k)
