tree l2 /
//
├── AGENTS.MD
├── bin/
│   ├── checkout
│   ├── claude
│   ├── codex
│   ├── date
│   ├── discount
│   ├── id
│   ├── payments
│   ├── README.md
│   └── sql
├── docs/
│   ├── checkout.md
│   ├── discounts.md
│   ├── merchant-continuity-and-critical-incidents.md
│   ├── os-and-tooling-incidents-and-workarounds.md
│   ├── payments/
│   ├── policy-updates/
│   ├── powertools-agentic-os-origin-story.md
│   ├── README.md
│   ├── returns.md
│   ├── security.md
│   ├── store-associate-exception-handbook.md
│   └── warehouse-systems-migration-runbook.md
├── proc/
│   ├── baskets/
│   ├── catalog/
│   ├── customers/
│   ├── employees/
│   ├── payments/
│   ├── README.md
│   ├── returns/
│   └── stores/
└── run/
    └── actions/
