# Catalogue Count Reporting Update

Operating day: 2024-07-17
Workflow: catalogue product-kind count questions
Requested product kind: Storage Bin and Organizer
Requested product_kind_id: bins_organizers

For today's count report, count only catalogue SKUs for the requested product
kind that have at least one current inventory row in an open PowerTool store in
Vienna with available_today_quantity greater than 0. Count each SKU once even if it is
available in multiple Vienna branches.
