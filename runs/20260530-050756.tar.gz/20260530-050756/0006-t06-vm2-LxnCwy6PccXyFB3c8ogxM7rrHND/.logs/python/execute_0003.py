# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Set business process and refs, then submit
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue claim verification: checking if a single Portwest PW3 DX 3TU-ST2 Work Gloves SKU carries both size L and size M properties.",
}

scratchpad["decision"] = {
    "base_sku": "SFE-2WR7B6IJ",
    "base_sku_name": "Portwest PW3 DX 3TU-ST2 Work Gloves cut-5 L Green",
    "base_sku_properties": {"color_family": "green", "protection_class": "cut-5", "size": "L", "standard": "EN 388"},
    "extra_claim": "has size M",
    "verdict": "Extra claim absent on base SKU. SFE-2WR7B6IJ has size=L only; size M is a different SKU (SFE-1WT01OHC) in the same line but is not the base product asked about.",
    "sibling_m_sku": "SFE-1WT01OHC (not cited in refs — not the product the brief is about)"
}

scratchpad["refs"] = ["/proc/catalog/Portwest/SFE-2WR7B6IJ.json"]

submit_and_exit(
    message="<NO> SFE-2WR7B6IJ",
    outcome="OUTCOME_OK",
    refs=["/proc/catalog/Portwest/SFE-2WR7B6IJ.json"]
)
