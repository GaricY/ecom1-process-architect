# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Check product_variant_properties for the size L variant (base SKU)
# SFE-2WR7B6IJ has size L - check if it also has size M
res = ws.sql_rows("""
    SELECT product_sku, property_key, property_value_text, property_value_number
    FROM product_variant_properties
    WHERE product_sku = 'SFE-2WR7B6IJ'
    ORDER BY property_key
""")
print(f"SFE-2WR7B6IJ (size L) properties:")
for row in res['rows']:
    print(row)

print()
# Also check the size M variant for completeness
res2 = ws.sql_rows("""
    SELECT product_sku, property_key, property_value_text, property_value_number
    FROM product_variant_properties
    WHERE product_sku = 'SFE-1WT01OHC'
    ORDER BY property_key
""")
print(f"SFE-1WT01OHC (size M) properties:")
for row in res2['rows']:
    print(row)
