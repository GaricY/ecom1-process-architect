# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Search for Portwest Work Gloves - PW3 DX 3TU-ST2 line
res = ws.sql_rows("""
    SELECT pv.product_sku, pv.record_path, pv.brand, pv.series, pv.model,
           pv.product_name, pv.properties
    FROM product_variants pv
    WHERE pv.brand LIKE '%Portwest%'
      AND pv.product_name LIKE '%Work Gloves%'
    ORDER BY pv.product_sku
""", limit=50)

print(f"Row count: {res['row_count']}")
for row in res['rows']:
    print(row)
