# BitGN ECOM trial

- benchmark: bitgn/ecom1-dev
- task_id: t06
- trial_id: vm2-LxnCwy6PccXyFB3c8ogxM7rrHND

## Task instruction

<task-instruction>
A support note claims we stock the Work Gloves from Portwest in the Portwest PW3 DX 3TU-ST2 Work Gloves line that has size L and has size M. Check the actual catalogue item, cite the exact product record, and if the base product exists but that extra catalogue claim is absent, answer with <NO> and include the checked SKU.
</task-instruction>

## How to work in this directory

The orchestrator prepared this folder with:

- `vault/` — fresh dump of live `/docs`, `/bin`, every `AGENTS.md` and `README.md`.
- `tree.md` — `tree -L 2 /` snapshot at trial start.
- `bin-help/` — `--help` output for every `/bin/<tool>` that exists.
- `CLAUDE.md` — executor role, scratchpad/state contract, refs/submission.
- `business_processes/` — short policy reminders.
- `runtime_prelude.py`, `workspace.py` — Python prelude loaded by every `execute_python` snippet.

Live workspace/policy always wins over the local snapshot. All runtime
reads, SQL queries, `/bin/*` actions, and final answer submission go
through the MCP tool `execute_python` — that is the only runtime
boundary. Do NOT use the host shell.

Read `CLAUDE.md` first, then this file, then call `execute_python`
with your first Python snippet.
