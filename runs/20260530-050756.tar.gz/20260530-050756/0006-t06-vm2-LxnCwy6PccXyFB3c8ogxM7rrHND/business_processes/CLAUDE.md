# ATTENTION — some business-process files below may be out of date

Since these BP files were drafted, the live workspace has changed. The BPs may quote sentences that no longer exist, or omit ones that now do. When a BP description disagrees with what you read live via `execute_python`, **trust the live read** and adjust your plan.

## Live workspace files that have changed

These files are general-purpose references — they are quoted from, or linked to, by most BP files in this directory. Skim each diff before applying a BP that touches the same area; the additions tend to introduce **new policies, new tool subcommands, or new SQL tables** the BPs cannot know about.

- `bin-help/claude.help.txt` — [diff](../attention/world-diffs/bin-help_claude.help.txt.patch)
- `bin-help/codex.help.txt` — [diff](../attention/world-diffs/bin-help_codex.help.txt.patch)

## How to use this header

1. Open each `*.patch` link above before reading any BP file that touches the same area.
2. A new `/docs/...` policy, a new `/bin/<tool>` subcommand, or a new SQL column shown in a diff is **not** covered by any BP — discover it from the live workspace via `execute_python`.
3. When a diff removes a sentence quoted by a BP, treat the BP sentence as obsolete.
4. The live workspace is always the source of truth — `Read` `/AGENTS.MD`, `/docs/*`, and `/bin/<tool> --help` directly whenever a BP and live state disagree.

# Business processes

**The single entry point is [`index.md`](index.md).** It maps trigger phrases
to per-process files; open it first, then read only the per-process files it
points you at for the trial in front of you.

## Current state

`/bin/id` and `/bin/date` are constant for the trial and pre-run for you
below — trusted source, no need to re-run them.

`/bin/id`:

```
user: anonymous
roles: GUEST
```

`/bin/date`:

```
2025-10-08T16:53:18Z
```
