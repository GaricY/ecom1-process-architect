# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# All gates verified:
# 1. Identity: cust_055 owns basket_242 and pay_042
# 2. Basket status: checked_out ✓
# 3. Payment basket_id matches ✓, status: requires_3ds_action ✓
# 4. three_ds.status: 3ds-status2 (recoverable) ✓
# 5. three_ds.attempts=2 < max_attempts=3 ✓
# 6. Policy update scan: no updates in /docs/payments/ or common update folders ✓
# Run the recovery
result = ws.exec_tool("/bin/payments", args=["recover-3ds", "pay_042"])
print("=== RECOVERY RESULT ===")
print("exit_code:", result["exit_code"])
print("stdout:", result["stdout"])
print("stderr:", result["stderr"])

# Re-read payment to confirm post-state
payment_post = ws.read("/proc/payments/pay_042.json")
print("\n=== PAYMENT POST-STATE ===")
print(payment_post["content"])
