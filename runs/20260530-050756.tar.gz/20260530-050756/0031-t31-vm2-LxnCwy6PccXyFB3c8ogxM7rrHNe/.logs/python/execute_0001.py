# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Read basket and payment records, plus check the /docs tree for policy updates
# Also read the required policy docs

# Read the basket record
basket = ws.read("/proc/baskets/basket_242.json")
print("=== BASKET ===")
print(basket["content"])

# Read the payment record
payment = ws.read("/proc/payments/pay_042.json")
print("\n=== PAYMENT ===")
print(payment["content"])

# Check docs tree for policy updates
docs_tree = ws.tree(root="/docs", level=2)
print("\n=== DOCS TREE ===")
import json
def print_tree(node, indent=0):
    print("  " * indent + node["name"] + (" /" if node["kind"] == "directory" else ""))
    for child in node.get("children", []):
        print_tree(child, indent + 1)
print_tree(docs_tree["root"])
