# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read required policy docs and check for policy updates

# Read 3ds.md
docs_3ds = ws.read("/docs/payments/3ds.md")
print("=== 3DS POLICY ===")
print(docs_3ds["content"])

# Read checkout.md (prerequisite per 3ds.md)
docs_checkout = ws.read("/docs/checkout.md")
print("\n=== CHECKOUT POLICY ===")
print(docs_checkout["content"])

# Read docs README.md to check for any update folder structure
docs_readme = ws.read("/docs/README.md")
print("\n=== DOCS README ===")
print(docs_readme["content"])
