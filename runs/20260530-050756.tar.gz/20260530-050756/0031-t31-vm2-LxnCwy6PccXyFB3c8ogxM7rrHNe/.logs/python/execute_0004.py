# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["business_process"] = {
    "primary": "payments_3ds_recovery.md",
    "reason": "Customer requested restart of failed 3DS bank approval challenge for their own payment pay_042 on basket basket_242."
}

scratchpad["decision"] = {
    "identity": "cust_055 (customer)",
    "ownership": "basket_242 and pay_042 both owned by cust_055",
    "basket_status": "checked_out",
    "payment_status": "requires_3ds_action",
    "three_ds_status": "3ds-status2 (recoverable)",
    "attempts": "2 < max_attempts 3",
    "policy_updates": "none found in /docs/payments/ or common update folders",
    "action": "recover-3ds pay_042",
    "post_state": "status=requires_3ds_action, three_ds.status=3ds-status1 (fresh challenge)"
}

refs = [
    "/docs/security.md",
    "/docs/checkout.md",
    "/docs/payments/3ds.md",
    "/proc/baskets/basket_242.json",
    "/proc/payments/pay_042.json"
]

submit_and_exit(
    message="The 3DS bank approval challenge for payment pay_042 has been restarted. A fresh challenge is now active — please complete the bank approval prompt to finalize your payment.",
    outcome="OUTCOME_OK",
    refs=refs
)
