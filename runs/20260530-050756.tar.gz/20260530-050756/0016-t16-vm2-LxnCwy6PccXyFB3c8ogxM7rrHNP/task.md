# BitGN ECOM trial

- benchmark: bitgn/ecom1-dev
- task_id: t16
- trial_id: vm2-LxnCwy6PccXyFB3c8ogxM7rrHNP

## Task instruction

<task-instruction>
How many of these products have at least 2 items available in the Linz Hauptplatz PowerTool shop today: the Chainsaw from Makita in the Makita Eco DDF WR1-TFW Chainsaw line that has power source battery and bar length 35 cm,the Wood and Drywall Screw from Heco in the Heco Countersunk Unix Y22-P9Y Wood and Drywall Screw line that has screw type machine screw, diameter 6 mm, and length 50 mm,the Storage Bin and Organizer from Curver in the Curver Compact Infinity 6VR-BL3 Storage Bin and Organizer line that has storage type stacking box and color family Clear,the Hammer Measuring and Cutting Tool from Facom in the Facom Heavy Duty S 111-EOA Hammer Measuring and Cutting Tool line that has tool type clamp and length 250 mm,the Workshop Drill Grinder and Sander from Einhell in the Einhell Workshop TE 3EW-NIE Workshop Drill Grinder and Sander line that has machine type planer thicknesser,the Compressor and Dust Extractor from DeWalt in the DeWalt FlexVolt DCS 38Q-XAV Compressor and Dust Extractor line that has machine type compressor, voltage 110 V, power 1100 W, and tank volume 24 l? Answer in exactly format "result %d" (no quotes)
</task-instruction>

## How to work in this directory

The orchestrator prepared this folder with:

- `vault/` — fresh dump of live `/docs`, `/bin`, every `AGENTS.md` and `README.md`.
- `tree.md` — `tree -L 2 /` snapshot at trial start.
- `bin-help/` — `--help` output for every `/bin/<tool>` that exists.
- `CLAUDE.md` — executor role, scratchpad/state contract, refs/submission.
- `business_processes/` — short policy reminders.
- `runtime_prelude.py`, `workspace.py` — Python prelude loaded by every `execute_python` snippet.

Live workspace/policy always wins over the local snapshot. All runtime
reads, SQL queries, `/bin/*` actions, and final answer submission go
through the MCP tool `execute_python` — that is the only runtime
boundary. Do NOT use the host shell.

Read `CLAUDE.md` first, then this file, then call `execute_python`
with your first Python snippet.
