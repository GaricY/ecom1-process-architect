# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import json

# Identified SKUs based on properties:
# 1. Makita chainsaw: power_source=battery, bar_length=35cm → GRD-3FHVOI0G
# 2. Heco screw: screw_type=machine screw, diameter=6mm, length=50mm → FST-1B91S3N3 (verify)
# 3. Curver storage: stacking box, color clear → STO-3SP7VKPD
# 4. Facom tool: clamp, length 250mm → HND-3V41EOE2
# 5. Einhell: planer thicknesser → MAC-RQDOT28Q
# 6. DeWalt: compressor, 110V, 1100W, 24l → MAC-EWWTZ94N

# First verify Heco screw FST-1B91S3N3 full properties
heco_res = ws.sql_rows("SELECT product_sku, properties FROM product_variants WHERE product_sku = 'FST-1B91S3N3'")
print("Heco screw:", heco_res["rows"])

# Now check inventory for all 6 at store_linz_hauptplatz
skus = ['GRD-3FHVOI0G', 'FST-1B91S3N3', 'STO-3SP7VKPD', 'HND-3V41EOE2', 'MAC-RQDOT28Q', 'MAC-EWWTZ94N']
sku_list = "','".join(skus)
inv_res = ws.sql_rows(f"""
    SELECT si.product_sku, si.available_today_quantity, pv.record_path
    FROM store_inventory si
    JOIN product_variants pv ON pv.product_sku = si.product_sku
    WHERE si.store_id = 'store_linz_hauptplatz'
    AND si.product_sku IN ('{sku_list}')
""")
print("\nInventory at Linz Hauptplatz:")
for r in inv_res["rows"]:
    print(r)
