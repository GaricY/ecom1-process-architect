# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get all variants for the 6 families
family_ids = [
    'fam_garden_tools_chainsaws_0005_2lci0gdk',
    'fam_fasteners_wood_drywall_screws_0018_lcozjddz',
    'fam_storage_bins_organizers_0006_3l4k6izb',
    'fam_hand_tools_hammers_measuring_cutting_0017_18vajvaz',
    'fam_workshop_machines_drill_grinders_sanders_0010_1wm9hfd8',
    'fam_workshop_machines_compressors_extractors_0010_1tylf47h',
]
fam_list = "','".join(family_ids)
variants_res = ws.sql_rows(f"""
    SELECT pv.product_sku, pv.product_family_id, pv.brand, pv.series, pv.model, pv.properties, pv.record_path
    FROM product_variants pv
    WHERE pv.product_family_id IN ('{fam_list}')
""")
print(f"Total variants: {variants_res['row_count']}")
for v in variants_res["rows"]:
    print(v["product_sku"], v["product_family_id"], v["properties"][:120])
