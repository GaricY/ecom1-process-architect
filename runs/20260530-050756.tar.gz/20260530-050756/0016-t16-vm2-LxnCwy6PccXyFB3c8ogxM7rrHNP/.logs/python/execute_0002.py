# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 2: Find product families for each of the 6 products
# Products identified by brand/series/model

families_res = ws.sql_rows("""
    SELECT product_family_id, brand, series, model, product_family_name, product_kind_id
    FROM product_families
    WHERE
        (brand = 'Makita' AND series = 'Eco DDF WR1-TFW') OR
        (brand = 'Heco' AND series = 'Countersunk Unix Y22-P9Y') OR
        (brand = 'Curver' AND series = 'Compact Infinity 6VR-BL3') OR
        (brand = 'Facom' AND series = 'Heavy Duty S 111-EOA') OR
        (brand = 'Einhell' AND series = 'Workshop TE 3EW-NIE') OR
        (brand = 'DeWalt' AND series = 'FlexVolt DCS 38Q-XAV')
""")
for f in families_res["rows"]:
    print(f)
