# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Try broader search - check what's in the DB for these brands
for brand in ['Makita', 'Heco', 'Curver', 'Facom', 'Einhell', 'DeWalt']:
    res = ws.sql_rows(f"SELECT brand, series, model FROM product_families WHERE brand = '{brand}' LIMIT 5")
    print(f"{brand}: {res['rows']}")
