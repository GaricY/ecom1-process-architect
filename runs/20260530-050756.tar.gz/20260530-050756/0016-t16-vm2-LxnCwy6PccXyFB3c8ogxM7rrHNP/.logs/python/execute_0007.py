# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Set scratchpad and submit
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Inventory availability count question for a specific store across 6 product variants",
}

scratchpad["decision"] = {
    "store": "store_linz_hauptplatz",
    "store_name": "PowerTool Linz Hauptplatz",
    "products_checked": [
        {"sku": "GRD-3FHVOI0G", "desc": "Makita Eco chainsaw battery 35cm", "result": "no inventory row - not stocked"},
        {"sku": "FST-1B91S3N3", "desc": "Heco Countersunk machine screw 6mm 50mm", "result": "no inventory row - not stocked"},
        {"sku": "STO-3SP7VKPD", "desc": "Curver Compact stacking box clear", "result": "no inventory row - not stocked"},
        {"sku": "HND-3V41EOE2", "desc": "Facom Heavy Duty clamp 250mm", "available_today_quantity": 8, "result": "PASS"},
        {"sku": "MAC-RQDOT28Q", "desc": "Einhell Workshop planer thicknesser", "available_today_quantity": 8, "result": "PASS"},
        {"sku": "MAC-EWWTZ94N", "desc": "DeWalt FlexVolt compressor 110V 1100W 24l", "available_today_quantity": 8, "result": "PASS"},
    ],
    "count_with_at_least_2": 3,
}

refs = [
    "/proc/stores/store_linz_hauptplatz.json",
    "/proc/catalog/hand_tools/hammers_measuring_cutting/fam_hand_tools_hammers_measuring_cutting_0017_18vajvaz/HND-3V41EOE2.json",
    "/proc/catalog/workshop_machines/drill_grinders_sanders/fam_workshop_machines_drill_grinders_sanders_0010_1wm9hfd8/MAC-RQDOT28Q.json",
    "/proc/catalog/workshop_machines/compressors_extractors/fam_workshop_machines_compressors_extractors_0010_1tylf47h/MAC-EWWTZ94N.json",
]

submit_and_exit(
    message="result 3",
    outcome="OUTCOME_OK",
    refs=refs,
)
