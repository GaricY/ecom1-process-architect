# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find the Linz Hauptplatz PowerTool store
store_res = ws.sql_rows("""
    SELECT store_id, store_name, city, is_open, record_path
    FROM stores
    WHERE store_name LIKE '%Linz%' OR city LIKE '%Linz%'
""")
print("Stores in Linz:", store_res["rows"])
