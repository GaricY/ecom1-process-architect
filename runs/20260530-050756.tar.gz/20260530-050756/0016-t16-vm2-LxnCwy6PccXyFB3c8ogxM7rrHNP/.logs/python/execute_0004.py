# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Search more specifically by series and model patterns
searches = [
    ("Makita", "Eco", "DDF WR1-TFW"),
    ("Heco", "Countersunk", "Unix Y22-P9Y"),
    ("Curver", "Compact", "Infinity 6VR-BL3"),
    ("Facom", "Heavy Duty", "S 111-EOA"),
    ("Einhell", "Workshop", "TE 3EW-NIE"),
    ("DeWalt", "FlexVolt", "DCS 38Q-XAV"),
]
for brand, series, model in searches:
    res = ws.sql_rows(f"""
        SELECT product_family_id, brand, series, model, product_family_name
        FROM product_families
        WHERE brand = '{brand}' AND series = '{series}' AND model = '{model}'
    """)
    print(f"{brand}/{series}/{model}: {res['rows']}")
