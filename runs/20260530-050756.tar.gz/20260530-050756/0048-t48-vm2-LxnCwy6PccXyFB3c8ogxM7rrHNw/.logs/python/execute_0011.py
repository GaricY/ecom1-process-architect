# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from collections import defaultdict
from datetime import datetime

rows = state['rows']
row_map = {r['row_id']: r for r in rows}

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Build final fraud cohort
fraud_rows = set()
fraud_evidence = {}

# HARD SIGNAL 1: Cross-actor DFP sharing
shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']
for dfp in shared_dfps:
    for r in rows:
        if r['device_fingerprint'] == dfp:
            fraud_rows.add(r['row_id'])
            fraud_evidence[r['row_id']] = f"cross-actor DFP sharing ({dfp})"

# HARD SIGNAL 2: Impossible observed travel (0-15 min window, L1 > 2.0)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)
for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    for i in range(1, len(cust_rows)):
        prev, curr = cust_rows[i-1], cust_rows[i]
        l1 = l1_distance(float(prev['observed_lat']), float(prev['observed_lon']),
                         float(curr['observed_lat']), float(curr['observed_lon']))
        mins = (parse_ts(curr['created_at']) - parse_ts(prev['created_at'])).total_seconds() / 60.0
        if 0 <= mins <= 15 and l1 > 2.0:
            for rid, r in [(prev['row_id'], prev), (curr['row_id'], curr)]:
                fraud_rows.add(rid)
                if rid not in fraud_evidence:
                    fraud_evidence[rid] = f"impossible travel: {prev['store_city']}->{curr['store_city']} in {mins:.1f}min L1={l1:.3f}"

# Compute total
total_cents = sum(int(row_map[rid]['amount_cents']) for rid in fraud_rows)
total_euros = total_cents // 100
total_cents_rem = total_cents % 100
print(f"Total fraud rows: {len(fraud_rows)}")
print(f"Total: EUR {total_euros}.{total_cents_rem:02d}")

# Build refs list (row refs as required by task)
ARCHIVE_PATH = "/archive/payment_batch_export_DpD8iQtr2j.tsv"
refs = sorted([f"{ARCHIVE_PATH}#row={rid}" for rid in fraud_rows])
print(f"\nRefs count: {len(refs)}")

# Update scratchpad with sweep ledger
scratchpad["hard_sweep_ledger"] = {
    "scope": "all rows in /archive/payment_batch_export_DpD8iQtr2j.tsv (208 rows)",
    "universe_size": 208,
    "columns_considered": ["row_id","archive_payment_id","created_at","customer_ref","store_ref","store_city","amount_cents","currency","payment_method_fingerprint","device_fingerprint","observed_lat","observed_lon","sku_summary","archive_channel"],
    "PMF_cross_actor": {"result": "zero", "max_metric": "no duplicates"},
    "DFP_cross_actor": {"result": "hard hit", "count": 2, "dfps": shared_dfps, "rows": 12},
    "workflow_state": {"result": "not applicable", "reason": "no payment_status or 3DS columns in export"},
    "record_invariants": {"result": "zero", "max_metric": "no dup row_ids, no dup payment_ids, no zero amounts"},
    "impossible_observed_travel": {"result": "hard hit", "pairs_found": 28, "rows_flagged_cumulative": len(fraud_rows) - 12},
    "stationary_single_actor_burst": {"result": "zero", "max_metric": "max distinct_stores with spread<0.05 = 0"},
}
scratchpad["business_process"] = {
    "primary": "fraud_risk_review.md",
    "reason": "Archived payment export review to identify fraud rows via hard sweep"
}
scratchpad["answer"] = f"EUR {total_euros}.{total_cents_rem:02d}"
scratchpad["fraud_row_count"] = len(fraud_rows)
scratchpad["total_cents"] = total_cents
scratchpad["refs"] = refs
print("Scratchpad updated.")
