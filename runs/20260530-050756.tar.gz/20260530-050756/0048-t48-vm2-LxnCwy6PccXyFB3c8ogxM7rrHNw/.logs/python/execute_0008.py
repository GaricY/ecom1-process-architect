# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from collections import defaultdict

rows = state['rows']

# Check record invariants: duplicate IDs, zero amounts
print("=== HARD SWEEP 4: Record invariants ===")

# Check duplicate row_ids
row_ids = [r['row_id'] for r in rows]
dup_row_ids = [rid for rid in row_ids if row_ids.count(rid) > 1]
print(f"Duplicate row_ids: {dup_row_ids}")

# Check duplicate archive_payment_ids
pmt_ids = [r['archive_payment_id'] for r in rows]
dup_pmt_ids = [pid for pid in pmt_ids if pmt_ids.count(pid) > 1]
print(f"Duplicate archive_payment_ids: {dup_pmt_ids}")

# Check zero/negative amounts
zero_neg = [r for r in rows if int(r['amount_cents']) <= 0]
print(f"Zero/negative amounts: {[r['row_id'] for r in zero_neg]}")

# Check identical timestamps across customers (same time, different customer)
ts_to_custs = defaultdict(list)
for r in rows:
    ts_to_custs[r['created_at']].append(r)
dup_ts = {ts: rrs for ts, rrs in ts_to_custs.items() if len(rrs) > 1}
print(f"\nIdentical timestamps (different records):")
for ts, rrs in sorted(dup_ts.items()):
    custs = [r['customer_ref'] for r in rrs]
    row_ids_ts = [r['row_id'] for r in rrs]
    if len(set(custs)) > 1:
        print(f"  {ts}: rows={row_ids_ts} custs={custs}")

# Check same customer, same amount, very close times (duplicate payment pattern)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

print(f"\n=== All currencies ===")
currencies = set(r['currency'] for r in rows)
print(f"Currencies: {currencies}")
