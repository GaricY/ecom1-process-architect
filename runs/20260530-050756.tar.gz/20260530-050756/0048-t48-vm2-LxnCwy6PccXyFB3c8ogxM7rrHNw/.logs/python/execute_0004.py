# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Look at details of rows with shared device fingerprints
rows = state['rows']

shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']

print("=== DETAILS OF SHARED DFP ROWS ===")
for dfp in shared_dfps:
    print(f"\nDFP: {dfp}")
    dfp_rows = [r for r in rows if r['device_fingerprint'] == dfp]
    dfp_rows.sort(key=lambda r: r['created_at'])
    for r in dfp_rows:
        print(f"  row_id={r['row_id']} cust={r['customer_ref']} created_at={r['created_at']} store={r['store_ref']} city={r['store_city']} amount_cents={r['amount_cents']} lat={r['observed_lat']} lon={r['observed_lon']}")
