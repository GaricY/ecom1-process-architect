# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from datetime import datetime
from collections import defaultdict

rows = state['rows']

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

# Proper stationary burst: distinct_stores >= 4 AND observed_spread < 0.05
print("=== HARD SWEEP 3b: Stationary burst (proper: spread < 0.05, 5-min window) ===")
stationary_bursts = []
max_stores_low_spread = 0

for cust, cust_rows in by_customer.items():
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        in_window = []
        for other in cust_rows:
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) < 2:
            continue
        
        stores = set(r['store_ref'] for r in in_window)
        lats = [float(r['observed_lat']) for r in in_window]
        lons = [float(r['observed_lon']) for r in in_window]
        max_spread = max(
            l1_distance(lats[a], lons[a], lats[b], lons[b])
            for a in range(len(in_window))
            for b in range(len(in_window))
        )
        
        if max_spread < 0.05:
            if len(stores) > max_stores_low_spread:
                max_stores_low_spread = len(stores)
            if len(stores) >= 4:
                stationary_bursts.append({
                    'cust': cust, 'anchor_ts': anchor['created_at'],
                    'stores': len(stores), 'spread': max_spread,
                    'rows': [r['row_id'] for r in in_window],
                })

print(f"Stationary burst (spread<0.05, stores>=4) hits: {len(stationary_bursts)}")
if stationary_bursts:
    for b in stationary_bursts:
        print(f"  {b}")
print(f"Max distinct_stores with spread<0.05 (max-metric validation): {max_stores_low_spread}")

# Also find max spread for cases with distinct_stores >= 4 (regardless of spread)
print("\n--- Checking if any stationary burst exists at all (max_metric) ---")
best = []
for cust, cust_rows in by_customer.items():
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        in_window = []
        for other in cust_rows:
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) < 2:
            continue
        
        stores = set(r['store_ref'] for r in in_window)
        lats = [float(r['observed_lat']) for r in in_window]
        lons = [float(r['observed_lon']) for r in in_window]
        max_spread = max(
            l1_distance(lats[a], lons[a], lats[b], lons[b])
            for a in range(len(in_window))
            for b in range(len(in_window))
        )
        best.append((len(stores), max_spread, cust, anchor['created_at']))

best.sort(key=lambda x: -x[0])
print("Top 5 windows by distinct_stores:")
for b in best[:5]:
    print(f"  stores={b[0]} spread={b[1]:.4f} cust={b[2]} anchor={b[3]}")
