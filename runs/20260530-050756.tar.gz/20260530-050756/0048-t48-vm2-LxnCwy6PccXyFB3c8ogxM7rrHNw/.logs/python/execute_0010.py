# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from collections import defaultdict
from datetime import datetime

rows = state['rows']
row_map = {r['row_id']: r for r in rows}

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Compile fraud cohort
fraud_rows = set()
fraud_evidence = {}

# ===== HARD SIGNAL 1: Cross-actor DFP sharing =====
shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']
for dfp in shared_dfps:
    dfp_rows = [r for r in rows if r['device_fingerprint'] == dfp]
    for r in dfp_rows:
        fraud_rows.add(r['row_id'])
        fraud_evidence[r['row_id']] = f"DFP sharing: {dfp}"

print(f"After DFP sharing: {len(fraud_rows)} rows")

# ===== HARD SIGNAL 2: Impossible observed travel =====
# Collect all unique row_ids involved in impossible travel pairs (0-15 min, L1 > 2.0)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    for i in range(1, len(cust_rows)):
        prev = cust_rows[i-1]
        curr = cust_rows[i]
        
        prev_lat = float(prev['observed_lat'])
        prev_lon = float(prev['observed_lon'])
        curr_lat = float(curr['observed_lat'])
        curr_lon = float(curr['observed_lon'])
        
        prev_ts = parse_ts(prev['created_at'])
        curr_ts = parse_ts(curr['created_at'])
        
        minutes = (curr_ts - prev_ts).total_seconds() / 60.0
        l1 = l1_distance(prev_lat, prev_lon, curr_lat, curr_lon)
        
        if 0 <= minutes <= 15 and l1 > 2.0:
            fraud_rows.add(prev['row_id'])
            fraud_rows.add(curr['row_id'])
            travel_desc = f"impossible travel: {prev['store_city']}->{curr['store_city']} in {minutes:.1f}min L1={l1:.3f}"
            if prev['row_id'] not in fraud_evidence:
                fraud_evidence[prev['row_id']] = travel_desc
            if curr['row_id'] not in fraud_evidence:
                fraud_evidence[curr['row_id']] = travel_desc

print(f"After impossible travel: {len(fraud_rows)} rows")

# Print all fraud rows with evidence
print("\nFraud cohort:")
total_cents = 0
for row_id in sorted(fraud_rows):
    r = row_map[row_id]
    cents = int(r['amount_cents'])
    total_cents += cents
    print(f"  {row_id} cust={r['customer_ref']} {r['created_at']} {r['store_city']} amt={cents} evidence={fraud_evidence[row_id]}")

print(f"\nTotal rows: {len(fraud_rows)}")
print(f"Total amount: {total_cents} cents = EUR {total_cents // 100}.{total_cents % 100:02d}")
