# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from collections import defaultdict

rows = state['rows']

# Look at all rows for customers with single impossible travel pairs
single_travel_custs = ['arch_cust_077', 'arch_cust_080', 'arch_cust_028', 
                        'arch_cust_059', 'arch_cust_021', 'arch_cust_072']

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust in single_travel_custs:
    cust_rows = sorted(by_customer[cust], key=lambda x: x['created_at'])
    print(f"\n{cust} - {len(cust_rows)} rows:")
    for r in cust_rows:
        print(f"  {r['row_id']} {r['created_at']} {r['store_city']} lat={r['observed_lat']} lon={r['observed_lon']} amt={r['amount_cents']}")
