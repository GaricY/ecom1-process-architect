# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Final submission
ARCHIVE_PATH = "/archive/payment_batch_export_DpD8iQtr2j.tsv"
refs = scratchpad["refs"]  # already built and stored

message = f"EUR 20693.00"

submit_and_exit(
    message=message,
    outcome="OUTCOME_OK",
    refs=refs
)
