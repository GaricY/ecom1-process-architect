# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# First, read the archive TSV file to understand its structure
res = ws.read("/archive/payment_batch_export_DpD8iQtr2j.tsv")
print(f"Content type: {res['content_type']}")
print(f"Truncated: {res['truncated']}")
print(f"Size: {len(res['content'])} chars")
# Print first 3000 chars to see structure
print(res['content'][:3000])
