# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from datetime import datetime, timezone
from collections import defaultdict

rows = state['rows']

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Hard sweep 3: Stationary single-actor burst
# One actor at many distinct stores in 5-min window, low observed spread

# Do self-join on customer, time window 5 min
print("=== HARD SWEEP 3: Stationary single-actor burst (5-min window) ===")

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

burst_windows = []
for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        anchor_lat = float(anchor['observed_lat'])
        anchor_lon = float(anchor['observed_lon'])
        
        in_window = []
        for j, other in enumerate(cust_rows):
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) >= 2:
            stores = set(r['store_ref'] for r in in_window)
            cities = set(r['store_city'] for r in in_window)
            
            # Calculate observed spread
            lats = [float(r['observed_lat']) for r in in_window]
            lons = [float(r['observed_lon']) for r in in_window]
            max_l1 = max(
                l1_distance(lats[a], lons[a], lats[b], lons[b])
                for a in range(len(in_window))
                for b in range(len(in_window))
            )
            
            if len(stores) >= 3:
                burst_windows.append({
                    'cust': cust,
                    'anchor_ts': anchor['created_at'],
                    'payment_count': len(in_window),
                    'distinct_stores': len(stores),
                    'distinct_cities': len(cities),
                    'observed_spread_l1': max_l1,
                    'row_ids': [r['row_id'] for r in in_window],
                    'stores': list(stores),
                    'cities': list(cities),
                })

# Deduplicate - keep only the max-store window per customer
seen = set()
unique_bursts = []
for b in sorted(burst_windows, key=lambda x: -x['distinct_stores']):
    key = b['cust']
    if key not in seen:
        seen.add(key)
        unique_bursts.append(b)

print(f"Burst hits (distinct_stores >= 3 in 5-min window): {len(unique_bursts)}")
for b in unique_bursts:
    print(f"  cust={b['cust']} anchor={b['anchor_ts']} payments={b['payment_count']} stores={b['distinct_stores']} cities={b['distinct_cities']} observed_spread={b['observed_spread_l1']:.4f}")
    print(f"    rows={b['row_ids']}")
    print(f"    cities={sorted(b['cities'])}")

# Also check if any of the impossible travel ones have a burst pattern
print("\n--- Customers with impossible travel: arch_cust_065, arch_cust_011, arch_cust_076, arch_cust_052 ---")
for cust in ['arch_cust_065', 'arch_cust_011', 'arch_cust_076', 'arch_cust_052']:
    cust_rows = sorted(by_customer[cust], key=lambda x: x['created_at'])
    print(f"\n{cust} - all rows:")
    for r in cust_rows:
        print(f"  {r['row_id']} {r['created_at']} {r['store_city']} lat={r['observed_lat']} lon={r['observed_lon']} amt={r['amount_cents']}")
