# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from datetime import datetime, timezone
import math

rows = state['rows']

# Hard sweep 2: Impossible observed travel
# Check sequential events by same actor where coordinates move impossibly far

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Group by customer, sort by time
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust in by_customer:
    by_customer[cust].sort(key=lambda x: x['created_at'])

print("=== HARD SWEEP 2: Impossible observed travel ===")
impossible_travel = []
max_speed_row = None
max_speed_val = 0

for cust, cust_rows in by_customer.items():
    for i in range(1, len(cust_rows)):
        prev = cust_rows[i-1]
        curr = cust_rows[i]
        
        prev_lat = float(prev['observed_lat'])
        prev_lon = float(prev['observed_lon'])
        curr_lat = float(curr['observed_lat'])
        curr_lon = float(curr['observed_lon'])
        
        prev_ts = parse_ts(prev['created_at'])
        curr_ts = parse_ts(curr['created_at'])
        
        minutes = (curr_ts - prev_ts).total_seconds() / 60.0
        if minutes < 0:
            continue
        
        l1 = l1_distance(prev_lat, prev_lon, curr_lat, curr_lon)
        
        # Check if between 0 and 15 minutes and large jump
        if 0 <= minutes <= 15 and l1 > 2.0:
            impossible_travel.append({
                'cust': cust,
                'prev_row': prev['row_id'],
                'curr_row': curr['row_id'],
                'prev_ts': prev['created_at'],
                'curr_ts': curr['created_at'],
                'minutes': minutes,
                'l1': l1,
                'prev_city': prev['store_city'],
                'curr_city': curr['store_city'],
            })
        
        # Track max speed for validation
        if minutes > 0:
            speed = l1 / minutes
            if speed > max_speed_val:
                max_speed_val = speed
                max_speed_row = (cust, prev['row_id'], curr['row_id'], minutes, l1)

print(f"Impossible travel hits (0-15 min, L1>2): {len(impossible_travel)}")
for t in impossible_travel:
    print(f"  cust={t['cust']} rows={t['prev_row']}->{t['curr_row']} {t['prev_ts']}->{t['curr_ts']} minutes={t['minutes']:.1f} L1={t['l1']:.4f} cities={t['prev_city']}->{t['curr_city']}")

print(f"\nMax inter-event observed L1 (for max-metric): {max_speed_val:.6f} L1/min")
print(f"  Details: {max_speed_row}")
