# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

from collections import defaultdict
import math

rows = state['rows']

# Hard sweep 1: Cross-actor exact identifier collisions
# Check shared payment_method_fingerprint across different customers
pmf_to_customers = defaultdict(set)
pmf_to_rows = defaultdict(list)
for r in rows:
    pmf_to_customers[r['payment_method_fingerprint']].add(r['customer_ref'])
    pmf_to_rows[r['payment_method_fingerprint']].append(r['row_id'])

shared_pmf = {pmf: custs for pmf, custs in pmf_to_customers.items() if len(custs) > 1}
print(f"=== HARD SWEEP 1a: Shared payment_method_fingerprint across different customers ===")
print(f"Shared PMF count: {len(shared_pmf)}")
for pmf, custs in shared_pmf.items():
    rows_for_pmf = pmf_to_rows[pmf]
    print(f"  PMF {pmf}: customers={custs}, rows={rows_for_pmf}")

# Check shared device_fingerprint across different customers
dfp_to_customers = defaultdict(set)
dfp_to_rows = defaultdict(list)
for r in rows:
    dfp_to_customers[r['device_fingerprint']].add(r['customer_ref'])
    dfp_to_rows[r['device_fingerprint']].append(r['row_id'])

shared_dfp = {dfp: custs for dfp, custs in dfp_to_customers.items() if len(custs) > 1}
print(f"\n=== HARD SWEEP 1b: Shared device_fingerprint across different customers ===")
print(f"Shared DFP count: {len(shared_dfp)}")
for dfp, custs in shared_dfp.items():
    rows_for_dfp = dfp_to_rows[dfp]
    print(f"  DFP {dfp}: customers={custs}, rows={rows_for_dfp}")
