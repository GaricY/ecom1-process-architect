# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import csv
import io

# Parse the full TSV file
res = ws.read("/archive/payment_batch_export_DpD8iQtr2j.tsv")
content = res['content']

reader = csv.DictReader(io.StringIO(content), delimiter='\t')
rows = list(reader)

print(f"Total rows: {len(rows)}")
print(f"Columns: {list(rows[0].keys())}")
print(f"\nSample row:")
for k, v in rows[0].items():
    print(f"  {k}: {v}")

# Store in state for further analysis
state['rows'] = rows
