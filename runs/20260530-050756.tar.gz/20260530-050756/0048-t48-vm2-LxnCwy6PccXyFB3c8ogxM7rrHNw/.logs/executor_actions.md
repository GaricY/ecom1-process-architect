# Executor actions — t48 (vm2-LxnCwy6PccXyFB3c8ogxM7rrHNw)

- **status:** FAIL
- **score:** 75.0%
- **answer_outcome:** OUTCOME_OK
- **snippets:** 12
- **inner tool calls:** 3

## Task instruction

```
Risk Ops is reviewing a two-year-old archive export. The records in this export are not present in current /proc/payments or /bin/sql.

Read /archive/payment_batch_export_DpD8iQtr2j.tsv, identify the archived payment rows that belong to fraud incidents, and do not modify files.

Answer message must contain only the total fraudulent payment amount, formatted exactly as:

EUR %d.%02d

Do not put row IDs in the message.

For grounding refs, cite every fraud row using exactly this row-ref format:

/archive/payment_batch_export_DpD8iQtr2j.tsv#row=<RowID>
```

## Score detail (from get_trial)

- answer amount mismatch
- archive fraud refs recovered ~97% EUR from fraud amount, and also marked more than ten payments as false positives.

## Final answer (answer.json)

```json
{
  "message": "EUR 20693.00",
  "outcome": "OUTCOME_OK",
  "refs": [
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3apJaL",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3pNGua",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-4bvBaW",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7DnJeE",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7JpJje",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7SVeiD",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7xrWuM",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-82WAxz",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-8Bi5dr",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-9Y7TRZ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-A8K2Md",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CGxJeC",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CkpJTq",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Cz72c2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EAeuiL",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EWjHjK",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FHgLUN",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FZK91x",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FbqUUD",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fceajx",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FfgYrP",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fhuqmw",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-GFxdWw",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-HMazkN",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KJXqwy",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzKRkf",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzPiH3",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-MEbLC9",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-NJPjX8",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Nmiezi",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-P853L2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-R2rGdH",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-SPFS5k",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TLvcQE",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Tbv2Dc",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TukfPA",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UYgiDA",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UyBZ7e",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-VLnGku",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Vz1Yp6",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-XrKRJF",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YVmNNJ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YiGah2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ZVRtcq",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-a8inLV",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-apeKg7",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-b3JUxG",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bGvr7H",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bNbJbT",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-boP9yJ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-c54YzR",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-d3nqzP",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-dJUm2U",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-e4jREQ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-eanseK",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ek3T33",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-fGXvXQ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-heFEta",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-hv9gFT",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-jKd1oY"
  ]
}
```

## Snippet timeline

### Snippet 1 — `.logs/python/execute_0001.py`

```python

# First, read the archive TSV file to understand its structure
res = ws.read("/archive/payment_batch_export_DpD8iQtr2j.tsv")
print(f"Content type: {res['content_type']}")
print(f"Truncated: {res['truncated']}")
print(f"Size: {len(res['content'])} chars")
# Print first 3000 chars to see structure
print(res['content'][:3000])
```

**Inner tool calls** (in order):
- `read path='/archive/payment_batch_export_DpD8iQtr2j.tsv'`

**stdout:**
```
Content type: text/tab-separated-values
Truncated: False
Size: 42448 chars
row_id	archive_payment_id	created_at	customer_ref	store_ref	store_city	amount_cents	currency	payment_method_fingerprint	device_fingerprint	observed_lat	observed_lon	sku_summary	archive_channel
AR-NRV4JK	ap_KSrnEvcZ6j	2023-09-24T16:53:18Z	arch_cust_044	arch_store_ljubljana_center	Ljubljana	200	EUR	pm_arch_3R4eVPfEmq1e	dev_arch_XosPJfG3jwDF	46.05088	14.50511	Dresselhaus Outdoor Pro 1VG-P5G	web
AR-Rvrr8H	ap_D5Zn77vdgF	2023-09-24T18:43:18Z	arch_cust_058	arch_store_bratislava_stare_mesto	Bratislava	15600	EUR	pm_arch_pp5iZve7GBpJ	dev_arch_UDFBzLPcKpHY	48.14418	17.11001	Mascot Advanced ACC 35W-IIS	store_terminal
AR-iREC5w	ap_44NJ9JzWgq	2023-09-24T19:08:18Z	arch_cust_084	arch_store_bratislava_stare_mesto	Bratislava	41400	EUR	pm_arch_6H4UsPs62oAk	dev_arch_BezF59zEt1pn	48.14419	17.10992	Festool Modular CTL XPW-76I	store_terminal
AR-cnhppm	ap_DihEu4Jg6S	2023-09-24T20:03:18Z	arch_cust_009	arch_store_brno_veveri	Brno	19800	EUR	pm_arch_Bu9BySMuG9gf	dev_arch_Luy5nVXFTiiu	49.20466	16.59351	Bahco Comfort Grip BE 1ZR-PGS	web
AR-YJVjDE	ap_46XYz3ST7o	2023-09-24T20:37:18Z	arch_cust_062	arch_store_brno_veveri	Brno	7300	EUR	pm_arch_Jy7rJx7vZ2wM	dev_arch_5BNSdSa5KNvX	49.20494	16.59386	Bahco Workshop BAH 3VZ-SPH	web
AR-7tt9cV	ap_AGUiA5G2mo	2023-09-25T02:23:18Z	arch_cust_067	arch_store_graz_jakomini	Graz	5600	EUR	pm_arch_SHRz65JV8GSG	dev_arch_NYvFYah2oQBb	47.06567	15.44277	Gorilla Crystal Grip 2ZQ-D83	web
AR-Pxxr9y	ap_5evamVN3cq	2023-09-25T02:38:18Z	arch_cust_007	arch_store_brno_veveri	Brno	4800	EUR	pm_arch_YAdeMq2uacce	dev_arch_2NQ14Cr8CJhn	49.20483	16.59381	Fischer SX SX 7UY-G03	store_terminal
AR-RHzdfU	ap_DAbWvWQVUf	2023-09-25T03:18:18Z	arch_cust_055	arch_store_linz_hauptplatz	Linz	700	EUR	pm_arch_ARPL5rSztyX5	dev_arch_ETdaKwaTyqiC	48.30714	14.28553	Sonax Premium Gloss 304-ZK0	web
AR-VwoMW9	ap_HHTJhHzams	2023-09-25T04:05:18Z	arch_cust_063	arch_store_graz_jakomini	Graz	31600	EUR	pm_arch_EJkevjUuRXj7	dev_arch_8KNFUtgA5yWs	47.06547	15.44292	Engelbert Strauss Classic e.s. 37H-N9K	web
AR-FK9ujx	ap_4seMCJhs3T	2023-09-25T05:17:18Z	arch_cust_077	arch_store_vienna_meidling	Vienna	4700	EUR	pm_arch_V3YMiABsyBPv	dev_arch_Xxr4gRJv2wiD	48.17479	16.33528	Festool Modular CTL XPW-76I	web
AR-3251wn	ap_C8CUqr9sE9	2023-09-25T08:38:18Z	arch_cust_019	arch_store_ljubljana_center	Ljubljana	2200	EUR	pm_arch_6ErfSL6ZV5qZ	dev_arch_NGxnksi47EFP	46.05111	14.50480	Bahco Comfort Grip BE 1ZR-PGS	store_terminal
AR-9Rx44H	ap_LuDud4Mtid	2023-09-25T09:23:18Z	arch_cust_008	arch_store_brno_veveri	Brno	1400	EUR	pm_arch_U3HTwkC4dBgD	dev_arch_K8mgXo2cfFB8	49.20444	16.59347	Sonax Premium Gloss 304-ZK0	web
AR-TCZB6S	ap_R8rEKy5RGp	2023-09-25T10:51:18Z	arch_cust_070	arch_store_graz_jakomini	Graz	9300	EUR	pm_arch_DvL8G87Rg6WL	dev_arch_NvWAAoqgvseS	47.06581	15.44307	Sonax Premium Gloss 304-ZK0	web
AR-YE7rXk	ap_DrPj5yCEf9	2023-09-25T11:11:18Z	arch_cust_073	arch_store_graz_jakomini	Graz	1400	EUR	pm_arch_PYmEGurzJBQc	dev_arch_Y2Ge4LVUK2cv	47.06571	15.44311	Bahco Workshop BAH 3VZ-SPH	web
AR-4kUmNk	ap_Fd25DmdyvG	2023-09
```

### Snippet 2 — `.logs/python/execute_0002.py`

```python

import csv
import io

# Parse the full TSV file
res = ws.read("/archive/payment_batch_export_DpD8iQtr2j.tsv")
content = res['content']

reader = csv.DictReader(io.StringIO(content), delimiter='\t')
rows = list(reader)

print(f"Total rows: {len(rows)}")
print(f"Columns: {list(rows[0].keys())}")
print(f"\nSample row:")
for k, v in rows[0].items():
    print(f"  {k}: {v}")

# Store in state for further analysis
state['rows'] = rows
```

**Inner tool calls** (in order):
- `read path='/archive/payment_batch_export_DpD8iQtr2j.tsv'`

**stdout:**
```
Total rows: 208
Columns: ['row_id', 'archive_payment_id', 'created_at', 'customer_ref', 'store_ref', 'store_city', 'amount_cents', 'currency', 'payment_method_fingerprint', 'device_fingerprint', 'observed_lat', 'observed_lon', 'sku_summary', 'archive_channel']

Sample row:
  row_id: AR-NRV4JK
  archive_payment_id: ap_KSrnEvcZ6j
  created_at: 2023-09-24T16:53:18Z
  customer_ref: arch_cust_044
  store_ref: arch_store_ljubljana_center
  store_city: Ljubljana
  amount_cents: 200
  currency: EUR
  payment_method_fingerprint: pm_arch_3R4eVPfEmq1e
  device_fingerprint: dev_arch_XosPJfG3jwDF
  observed_lat: 46.05088
  observed_lon: 14.50511
  sku_summary: Dresselhaus Outdoor Pro 1VG-P5G
  archive_channel: web
```

### Snippet 3 — `.logs/python/execute_0003.py`

```python

from collections import defaultdict
import math

rows = state['rows']

# Hard sweep 1: Cross-actor exact identifier collisions
# Check shared payment_method_fingerprint across different customers
pmf_to_customers = defaultdict(set)
pmf_to_rows = defaultdict(list)
for r in rows:
    pmf_to_customers[r['payment_method_fingerprint']].add(r['customer_ref'])
    pmf_to_rows[r['payment_method_fingerprint']].append(r['row_id'])

shared_pmf = {pmf: custs for pmf, custs in pmf_to_customers.items() if len(custs) > 1}
print(f"=== HARD SWEEP 1a: Shared payment_method_fingerprint across different customers ===")
print(f"Shared PMF count: {len(shared_pmf)}")
for pmf, custs in shared_pmf.items():
    rows_for_pmf = pmf_to_rows[pmf]
    print(f"  PMF {pmf}: customers={custs}, rows={rows_for_pmf}")

# Check shared device_fingerprint across different customers
dfp_to_customers = defaultdict(set)
dfp_to_rows = defaultdict(list)
for r in rows:
    dfp_to_customers[r['device_fingerprint']].add(r['customer_ref'])
    dfp_to_rows[r['device_fingerprint']].append(r['row_id'])

shared_dfp = {dfp: custs for dfp, custs in dfp_to_customers.items() if len(custs) > 1}
print(f"\n=== HARD SWEEP 1b: Shared device_fingerprint across different customers ===")
print(f"Shared DFP count: {len(shared_dfp)}")
for dfp, custs in shared_dfp.items():
    rows_for_dfp = dfp_to_rows[dfp]
    print(f"  DFP {dfp}: customers={custs}, rows={rows_for_dfp}")
```

**stdout:**
```
=== HARD SWEEP 1a: Shared payment_method_fingerprint across different customers ===
Shared PMF count: 0

=== HARD SWEEP 1b: Shared device_fingerprint across different customers ===
Shared DFP count: 2
  DFP dev_arch_HiZesFhREbYh: customers={'arch_cust_071', 'arch_cust_057', 'arch_cust_064', 'arch_cust_085', 'arch_cust_050', 'arch_cust_078'}, rows=['AR-d3nqzP', 'AR-7DnJeE', 'AR-YVmNNJ', 'AR-UYgiDA', 'AR-3pNGua', 'AR-YiGah2']
  DFP dev_arch_JWYVrTPvoW7V: customers={'arch_cust_008', 'arch_cust_097', 'arch_cust_064', 'arch_cust_053', 'arch_cust_075', 'arch_cust_086'}, rows=['AR-e4jREQ', 'AR-ek3T33', 'AR-bNbJbT', 'AR-4bvBaW', 'AR-XrKRJF', 'AR-boP9yJ']
```

### Snippet 4 — `.logs/python/execute_0004.py`

```python

# Look at details of rows with shared device fingerprints
rows = state['rows']

shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']

print("=== DETAILS OF SHARED DFP ROWS ===")
for dfp in shared_dfps:
    print(f"\nDFP: {dfp}")
    dfp_rows = [r for r in rows if r['device_fingerprint'] == dfp]
    dfp_rows.sort(key=lambda r: r['created_at'])
    for r in dfp_rows:
        print(f"  row_id={r['row_id']} cust={r['customer_ref']} created_at={r['created_at']} store={r['store_ref']} city={r['store_city']} amount_cents={r['amount_cents']} lat={r['observed_lat']} lon={r['observed_lon']}")
```

**stdout:**
```
=== DETAILS OF SHARED DFP ROWS ===

DFP: dev_arch_HiZesFhREbYh
  row_id=AR-d3nqzP cust=arch_cust_050 created_at=2023-11-23T05:53:18Z store=arch_store_linz_hauptplatz city=Linz amount_cents=50400 lat=48.30705 lon=14.28611
  row_id=AR-7DnJeE cust=arch_cust_057 created_at=2023-11-23T05:56:54Z store=arch_store_linz_hauptplatz city=Linz amount_cents=22700 lat=48.30690 lon=14.28567
  row_id=AR-YVmNNJ cust=arch_cust_064 created_at=2023-11-23T06:00:30Z store=arch_store_graz_lend city=Graz amount_cents=65300 lat=47.07334 lon=15.42586
  row_id=AR-UYgiDA cust=arch_cust_071 created_at=2023-11-23T06:04:06Z store=arch_store_linz_hauptplatz city=Linz amount_cents=21600 lat=48.30697 lon=14.28575
  row_id=AR-3pNGua cust=arch_cust_078 created_at=2023-11-23T06:07:42Z store=arch_store_graz_jakomini city=Graz amount_cents=48000 lat=47.06544 lon=15.44325
  row_id=AR-YiGah2 cust=arch_cust_085 created_at=2023-11-23T06:11:18Z store=arch_store_brno_veveri city=Brno amount_cents=26400 lat=49.20441 lon=16.59356

DFP: dev_arch_JWYVrTPvoW7V
  row_id=AR-e4jREQ cust=arch_cust_053 created_at=2023-11-24T05:53:18Z store=arch_store_vienna_praterstern city=Vienna amount_cents=57900 lat=48.21880 lon=16.39291
  row_id=AR-ek3T33 cust=arch_cust_064 created_at=2023-11-24T05:56:54Z store=arch_store_linz_hauptplatz city=Linz amount_cents=183000 lat=48.30706 lon=14.28568
  row_id=AR-bNbJbT cust=arch_cust_075 created_at=2023-11-24T06:00:30Z store=arch_store_bratislava_stare_mesto city=Bratislava amount_cents=22700 lat=48.14372 lon=17.10971
  row_id=AR-4bvBaW cust=arch_cust_086 created_at=2023-11-24T06:04:06Z store=arch_store_innsbruck_wilten city=Innsbruck amount_cents=65300 lat=47.25856 lon=11.38958
  row_id=AR-XrKRJF cust=arch_cust_097 created_at=2023-11-24T06:07:42Z store=arch_store_brno_veveri city=Brno amount_cents=27600 lat=49.20494 lon=16.59372
  row_id=AR-boP9yJ cust=arch_cust_008 created_at=2023-11-24T06:11:18Z store=arch_store_innsbruck_wilten city=Innsbruck amount_cents=34200 lat=47.25836 lon=11.38906
```

### Snippet 5 — `.logs/python/execute_0005.py`

```python

from datetime import datetime, timezone
import math

rows = state['rows']

# Hard sweep 2: Impossible observed travel
# Check sequential events by same actor where coordinates move impossibly far

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Group by customer, sort by time
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust in by_customer:
    by_customer[cust].sort(key=lambda x: x['created_at'])

print("=== HARD SWEEP 2: Impossible observed travel ===")
impossible_travel = []
max_speed_row = None
max_speed_val = 0

for cust, cust_rows in by_customer.items():
    for i in range(1, len(cust_rows)):
        prev = cust_rows[i-1]
        curr = cust_rows[i]
        
        prev_lat = float(prev['observed_lat'])
        prev_lon = float(prev['observed_lon'])
        curr_lat = float(curr['observed_lat'])
        curr_lon = float(curr['observed_lon'])
        
        prev_ts = parse_ts(prev['created_at'])
        curr_ts = parse_ts(curr['created_at'])
        
        minutes = (curr_ts - prev_ts).total_seconds() / 60.0
        if minutes < 0:
            continue
        
        l1 = l1_distance(prev_lat, prev_lon, curr_lat, curr_lon)
        
        # Check if between 0 and 15 minutes and large jump
        if 0 <= minutes <= 15 and l1 > 2.0:
            impossible_travel.append({
                'cust': cust,
                'prev_row': prev['row_id'],
                'curr_row': curr['row_id'],
                'prev_ts': prev['created_at'],
                'curr_ts': curr['created_at'],
                'minutes': minutes,
                'l1': l1,
                'prev_city': prev['store_city'],
                'curr_city': curr['store_city'],
            })
        
        # Track max speed for validation
        if minutes > 0:
            speed = l1 / minutes
            if speed > max_speed_val:
                max_speed_val = speed
                max_speed_row = (cust, prev['row_id'], curr['row_id'], minutes, l1)

print(f"Impossible travel hits (0-15 min, L1>2): {len(impossible_travel)}")
for t in impossible_travel:
    print(f"  cust={t['cust']} rows={t['prev_row']}->{t['curr_row']} {t['prev_ts']}->{t['curr_ts']} minutes={t['minutes']:.1f} L1={t['l1']:.4f} cities={t['prev_city']}->{t['curr_city']}")

print(f"\nMax inter-event observed L1 (for max-metric): {max_speed_val:.6f} L1/min")
print(f"  Details: {max_speed_row}")
```

**stdout:**
```
=== HARD SWEEP 2: Impossible observed travel ===
Impossible travel hits (0-15 min, L1>2): 28
  cust=arch_cust_077 rows=AR-FbqUUD->AR-KzPiH3 2023-10-08T03:10:18Z->2023-10-08T03:15:26Z minutes=5.1 L1=5.2420 cities=Brno->Ljubljana
  cust=arch_cust_080 rows=AR-FZK91x->AR-ZVRtcq 2023-10-09T03:28:18Z->2023-10-09T03:35:18Z minutes=7.0 L1=4.2224 cities=Innsbruck->Graz
  cust=arch_cust_028 rows=AR-7SVeiD->AR-KJXqwy 2023-10-08T04:33:18Z->2023-10-08T04:35:44Z minutes=2.4 L1=3.7518 cities=Vienna->Salzburg
  cust=arch_cust_059 rows=AR-KzKRkf->AR-c54YzR 2023-10-08T04:05:18Z->2023-10-08T04:07:57Z minutes=2.6 L1=7.1504 cities=Brno->Innsbruck
  cust=arch_cust_021 rows=AR-Fceajx->AR-A8K2Md 2023-10-09T02:53:18Z->2023-10-09T02:56:18Z minutes=3.0 L1=2.4741 cities=Linz->Ljubljana
  cust=arch_cust_065 rows=AR-9Y7TRZ->AR-SPFS5k 2023-10-26T10:00:18Z->2023-10-26T10:00:32Z minutes=0.2 L1=3.6511 cities=Salzburg->Vienna
  cust=arch_cust_065 rows=AR-Vz1Yp6->AR-bGvr7H 2023-10-26T10:00:50Z->2023-10-26T10:01:21Z minutes=0.5 L1=4.3943 cities=Bratislava->Salzburg
  cust=arch_cust_065 rows=AR-bGvr7H->AR-Tbv2Dc 2023-10-26T10:01:21Z->2023-10-26T10:01:43Z minutes=0.4 L1=3.7528 cities=Salzburg->Vienna
  cust=arch_cust_065 rows=AR-NJPjX8->AR-VLnGku 2023-10-26T10:01:48Z->2023-10-26T10:02:10Z minutes=0.4 L1=2.9868 cities=Bratislava->Linz
  cust=arch_cust_065 rows=AR-jKd1oY->AR-UyBZ7e 2023-10-26T10:02:34Z->2023-10-26T10:02:42Z minutes=0.1 L1=4.3949 cities=Salzburg->Bratislava
  cust=arch_cust_065 rows=AR-UyBZ7e->AR-EAeuiL 2023-10-26T10:02:42Z->2023-10-26T10:03:13Z minutes=0.5 L1=2.7539 cities=Bratislava->Graz
  cust=arch_cust_065 rows=AR-EAeuiL->AR-3apJaL 2023-10-26T10:03:13Z->2023-10-26T10:03:58Z minutes=0.8 L1=4.2210 cities=Graz->Innsbruck
  cust=arch_cust_065 rows=AR-3apJaL->AR-82WAxz 2023-10-26T10:03:58Z->2023-10-26T10:04:18Z minutes=0.3 L1=6.6063 cities=Innsbruck->Bratislava
  cust=arch_cust_065 rows=AR-fGXvXQ->AR-FHgLUN 2023-10-26T10:04:54Z->2023-10-26T10:06:22Z minutes=1.5 L1=3.2053 cities=Brno->Linz
  cust=arch_cust_072 rows=AR-8Bi5dr->AR-a8inLV 2023-10-08T02:53:18Z->2023-10-08T03:01:03Z minutes=7.8 L1=3.7523 cities=Vienna->Salzburg
  cust=arch_cust_011 rows=AR-MEbLC9->AR-apeKg7 2023-10-08T03:53:18Z->2023-10-08T04:00:46Z minutes=7.5 L1=5.9630 cities=Vienna->Innsbruck
  cust=arch_cust_011 rows=AR-TukfPA->AR-7JpJje 2023-10-27T10:00:18Z->2023-10-27T10:00:41Z minutes=0.4 L1=2.3741 cities=Graz->Linz
  cust=arch_cust_011 rows=AR-7JpJje->AR-GFxdWw 2023-10-27T10:00:41Z->2023-10-27T10:01:00Z minutes=0.3 L1=3.2053 cities=Linz->Brno
  cust=arch_cust_011 rows=AR-GFxdWw->AR-dJUm2U 2023-10-27T10:01:00Z->2023-10-27T10:01:06Z minutes=0.1 L1=3.2052 cities=Brno->Linz
  cust=arch_cust_011 rows=AR-EWjHjK->AR-heFEta 2023-10-27T10:01:24Z->2023-10-27T10:01:43Z minutes=0.3 L1=2.4753 cities=Linz->Ljubljana
  cust=arch_cust_011 rows=AR-Nmiezi->AR-CkpJTq 2023-10-27T10:02:31Z->2023-10-27T10:02:42Z minutes=0.2 L1=3.9536 cities=Ljubljana->Vienna
  cust=arch_cust_011 rows=AR-eanseK->AR-7xrWuM 2023-10-27T10:03:06Z->2023-10-27T10:03:14Z minutes=0.1 L1=2.1029 cities=Vienna->Graz
  cust=arch_cust_011 rows=AR-7xrWuM->AR-hv9gFT 2023-10-27T10:03:14Z->2023-10-27T10:03:27Z minutes=0.2 L1=2.0022 cities=Graz->Vienna
  cust=arch_cust_076 rows=AR-FfgYrP->AR-b3JUxG 2023-10-20T02:02:04Z->2023-10-20T02:05:03Z minutes=3.0 L1=5.2418 cities=Brno->Ljubljana
  cust=arch_cust_076 rows=AR-P853L2->AR-HMazkN 2023-10-20T02:21:17Z->2023-10-20T02:33:28Z minutes=12.2 L1=2.0105 cities=Vienna->Graz
  cust=arch_cust_052 rows=AR-TLvcQE->AR-CGxJeC 2023-12-05T01:01:04Z->2023-12-05T01:11:00Z minutes=9.9 L1=4.3227 cities=Ljubljana->Innsbruck
  cust=arch_cust_052 rows=AR-CGxJeC->AR-Fhuqmw 2023-12-05T01:11:00Z->2023-12-05T01:12:41Z minutes=1.7 L1=7.1503 cities=Innsbruck->Brno
  cust=arch_cust_052 rows=AR-R2rGdH->AR-Cz72c2 2023-12-05T01:30:42Z->2023-12-05T01:32:59Z minutes=2.3 L1=2.1032 cities=Vienna->Graz

Max inter-event observed L1 (for max-metric): 32.961600 L1/min
  Details: ('arch_cust_065', 'AR-jKd1oY', 'AR-UyBZ7e', 0.13333333333333333, 4.394879999999999)
```

### Snippet 6 — `.logs/python/execute_0006.py`

```python

from datetime import datetime, timezone
from collections import defaultdict

rows = state['rows']

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Hard sweep 3: Stationary single-actor burst
# One actor at many distinct stores in 5-min window, low observed spread

# Do self-join on customer, time window 5 min
print("=== HARD SWEEP 3: Stationary single-actor burst (5-min window) ===")

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

burst_windows = []
for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        anchor_lat = float(anchor['observed_lat'])
        anchor_lon = float(anchor['observed_lon'])
        
        in_window = []
        for j, other in enumerate(cust_rows):
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) >= 2:
            stores = set(r['store_ref'] for r in in_window)
            cities = set(r['store_city'] for r in in_window)
            
            # Calculate observed spread
            lats = [float(r['observed_lat']) for r in in_window]
            lons = [float(r['observed_lon']) for r in in_window]
            max_l1 = max(
                l1_distance(lats[a], lons[a], lats[b], lons[b])
                for a in range(len(in_window))
                for b in range(len(in_window))
            )
            
            if len(stores) >= 3:
                burst_windows.append({
                    'cust': cust,
                    'anchor_ts': anchor['created_at'],
                    'payment_count': len(in_window),
                    'distinct_stores': len(stores),
                    'distinct_cities': len(cities),
                    'observed_spread_l1': max_l1,
                    'row_ids': [r['row_id'] for r in in_window],
                    'stores': list(stores),
                    'cities': list(cities),
                })

# Deduplicate - keep only the max-store window per customer
seen = set()
unique_bursts = []
for b in sorted(burst_windows, key=lambda x: -x['distinct_stores']):
    key = b['cust']
    if key not in seen:
        seen.add(key)
        unique_bursts.append(b)

print(f"Burst hits (distinct_stores >= 3 in 5-min window): {len(unique_bursts)}")
for b in unique_bursts:
    print(f"  cust={b['cust']} anchor={b['anchor_ts']} payments={b['payment_count']} stores={b['distinct_stores']} cities={b['distinct_cities']} observed_spread={b['observed_spread_l1']:.4f}")
    print(f"    rows={b['row_ids']}")
    print(f"    cities={sorted(b['cities'])}")

# Also check if any of the impossible travel ones have a burst pattern
print("\n--- Customers with impossible travel: arch_cust_065, arch_cust_011, arch_cust_076, arch_cust_052 ---")
for cust in ['arch_cust_065', 'arch_cust_011', 'arch_cust_076', 'arch_cust_052']:
    cust_rows = sorted(by_customer[cust], key=lambda x: x['created_at'])
    print(f"\n{cust} - all rows:")
    for r in cust_rows:
        print(f"  {r['row_id']} {r['created_at']} {r['store_city']} lat={r['observed_lat']} lon={r['observed_lon']} amt={r['amount_cents']}")
```

**stdout:**
```
=== HARD SWEEP 3: Stationary single-actor burst (5-min window) ===
Burst hits (distinct_stores >= 3 in 5-min window): 2
  cust=arch_cust_065 anchor=2023-10-26T10:00:18Z payments=13 stores=8 cities=7 observed_spread=7.1507
    rows=['AR-9Y7TRZ', 'AR-SPFS5k', 'AR-Vz1Yp6', 'AR-bGvr7H', 'AR-Tbv2Dc', 'AR-NJPjX8', 'AR-VLnGku', 'AR-jKd1oY', 'AR-UyBZ7e', 'AR-EAeuiL', 'AR-3apJaL', 'AR-82WAxz', 'AR-fGXvXQ']
    cities=['Bratislava', 'Brno', 'Graz', 'Innsbruck', 'Linz', 'Salzburg', 'Vienna']
  cust=arch_cust_011 anchor=2023-10-27T10:00:18Z payments=14 stores=8 cities=6 observed_spread=5.2419
    rows=['AR-TukfPA', 'AR-7JpJje', 'AR-GFxdWw', 'AR-dJUm2U', 'AR-EWjHjK', 'AR-heFEta', 'AR-Nmiezi', 'AR-CkpJTq', 'AR-J3rrFv', 'AR-eanseK', 'AR-7xrWuM', 'AR-hv9gFT', 'AR-Hh28US', 'AR-ci2BfW']
    cities=['Bratislava', 'Brno', 'Graz', 'Linz', 'Ljubljana', 'Vienna']

--- Customers with impossible travel: arch_cust_065, arch_cust_011, arch_cust_076, arch_cust_052 ---

arch_cust_065 - all rows:
  AR-BKUajL 2023-09-27T16:57:18Z Vienna lat=48.21918 lon=16.39287 amt=2000
  AR-9Y7TRZ 2023-10-26T10:00:18Z Salzburg lat=47.81353 lon=13.04575 amt=2000
  AR-SPFS5k 2023-10-26T10:00:32Z Vienna lat=48.17516 lon=16.33520 amt=8400
  AR-Vz1Yp6 2023-10-26T10:00:50Z Bratislava lat=48.14371 lon=17.10952 amt=2500
  AR-bGvr7H 2023-10-26T10:01:21Z Salzburg lat=47.81317 lon=13.04574 amt=3300
  AR-Tbv2Dc 2023-10-26T10:01:43Z Vienna lat=48.21901 lon=16.39275 amt=2400
  AR-NJPjX8 2023-10-26T10:01:48Z Bratislava lat=48.14396 lon=17.11004 amt=6500
  AR-VLnGku 2023-10-26T10:02:10Z Linz lat=48.30684 lon=14.28611 amt=7900
  AR-jKd1oY 2023-10-26T10:02:34Z Salzburg lat=47.81313 lon=13.04583 amt=800
  AR-UyBZ7e 2023-10-26T10:02:42Z Bratislava lat=48.14419 lon=17.10965 amt=500
  AR-EAeuiL 2023-10-26T10:03:13Z Graz lat=47.07381 lon=15.42614 amt=2000
  AR-3apJaL 2023-10-26T10:03:58Z Innsbruck lat=47.25814 lon=11.38950 amt=7900
  AR-82WAxz 2023-10-26T10:04:18Z Bratislava lat=48.14406 lon=17.10990 amt=5200
  AR-fGXvXQ 2023-10-26T10:04:54Z Brno lat=49.20436 lon=16.59393 amt=5700
  AR-FHgLUN 2023-10-26T10:06:22Z Linz lat=48.30715 lon=14.28583 amt=7900

arch_cust_011 - all rows:
  AR-CwaehX 2023-09-29T06:23:18Z Innsbruck lat=47.25823 lon=11.38923 amt=17200
  AR-MEbLC9 2023-10-08T03:53:18Z Vienna lat=48.21876 lon=16.39230 amt=8800
  AR-apeKg7 2023-10-08T04:00:46Z Innsbruck lat=47.25827 lon=11.38975 amt=2000
  AR-TukfPA 2023-10-27T10:00:18Z Graz lat=47.07342 lon=15.42582 amt=1600
  AR-7JpJje 2023-10-27T10:00:41Z Linz lat=48.30724 lon=14.28551 amt=1000
  AR-GFxdWw 2023-10-27T10:01:00Z Brno lat=49.20465 lon=16.59338 amt=14000
  AR-dJUm2U 2023-10-27T10:01:06Z Linz lat=48.30673 lon=14.28612 amt=700
  AR-EWjHjK 2023-10-27T10:01:24Z Linz lat=48.30695 lon=14.28589 amt=9600
  AR-heFEta 2023-10-27T10:01:43Z Ljubljana lat=46.05093 lon=14.50522 amt=9200
  AR-Nmiezi 2023-10-27T10:02:31Z Ljubljana lat=46.05128 lon=14.50536 amt=4300
  AR-CkpJTq 2023-10-27T10:02:42Z Vienna lat=48.17497 lon=16.33524 amt=9100
  AR-J3rrFv 2023-10-27T10:02:54Z Vienna lat=48.17500 lon=16.33582 amt=7000
  AR-eanseK 2023-10-27T10:03:06Z Vienna lat=48.21887 lon=16.39276 amt=6200
  AR-7xrWuM 2023-10-27T10:03:14Z Graz lat=47.06565 lon=15.44313 amt=2800
  AR-hv9gFT 2023-10-27T10:03:27Z Vienna lat=48.17532 lon=16.33561 amt=7900
  AR-Hh28US 2023-10-27T10:03:38Z Bratislava lat=48.14362 lon=17.10937 amt=11000
  AR-ci2BfW 2023-10-27T10:04:30Z Brno lat=49.20425 lon=16.59329 amt=9600

arch_cust_076 - all rows:
  AR-eTKE6Z 2023-10-03T16:49:18Z Ljubljana lat=46.05135 lon=14.50487 amt=15800
  AR-8XxvxB 2023-10-08T07:58:18Z Bratislava lat=48.14373 lon=17.11002 amt=2600
  AR-CmJyGH 2023-10-10T15:48:35Z Ljubljana lat=46.05089 lon=14.50493 amt=700
  AR-U39bcx 2023-10-11T15:58:02Z Ljubljana lat=46.05091 lon=14.50505 amt=8400
  AR-JQZFM6 2023-10-12T12:07:28Z Brno lat=49.20426 lon=16.59358 amt=400
  AR-skhb8G 2023-10-13T15:25:55Z Innsbruck lat=47.25800 lon=11.38915 amt=9000
  AR-Cq9nm4 2023-10-14T16:56:39Z Graz lat=47.06571 lon=15.44275 amt=1400
  AR-EAqgQU 2023-10-15T15:08:06Z Linz lat=48.30656 lon=14.28586 amt=17200
  AR-cAMKFG 2023-10-16T11:09:21Z Bratislava lat=48.14422 lon=17.10945 amt=9000
  AR-9Q6QKP 2023-10-17T12:11:40Z Brno lat=49.20474 lon=16.59379 amt=57900
  AR-NApA6X 2023-10-18T14:19:57Z Salzburg lat=47.81323 lon=13.04570 amt=55200
  AR-fc7dH1 2023-10-19T13:14:34Z Ljubljana lat=46.05077 lon=14.50508 amt=21000
  AR-6DAx76 2023-10-20T01:45:29Z Bratislava lat=48.14356 lon=17.10966 amt=48000
  AR-FfgYrP 2023-10-20T02:02:04Z Brno lat=49.20443 lon=16.59331 amt=214100
  AR-b3JUxG 2023-10-20T02:05:03Z Ljubljana lat=46.05115 lon=14.50477 amt=69900
  AR-P853L2 2023-10-20T02:21:17Z Vienna lat=48.17469 lon=16.33530 amt=214100
  AR-HMazkN 2023-10-20T02:33:28Z Graz lat=47.07355 lon=15.42591 amt=183000

arch_cust_052 - all rows:
  AR-TZ8VZ9 2023-11-27T18:50:45Z Vienna lat=48.17485 lon=16.33521 amt=11000
  AR-VQp2ja 2023-11-28T10:57:52Z Graz lat=47.07377 lon=15.42575 amt=800
  AR-FyF1KT 2023-11-29T14:31:51Z Graz lat=47.07316 lon=15.42576 amt=72000
  AR-h5BpEF 2023-11-30T17:30:20Z Vienna lat=48.17505 lon=16.33527 amt=3500
  AR-3Q7pNR 2023-12-01T11:34:16Z Salzburg lat=47.81325 lon=13.04598 amt=18400
  AR-MMYoKy 2023-12-02T10:27:37Z Graz lat=47.06568 lon=15.44309 amt=9900
  AR-A8y2rA 2023-12-03T16:10:23Z Ljubljana lat=46.05138 lon=14.50518 amt=6200
  AR-YXkXE9 2023-12-04T18:14:58Z Graz lat=47.07357 lon=15.42634 amt=1400
  AR-TLvcQE 2023-12-05T01:01:04Z Ljubljana lat=46.05101 lon=14.50480 amt=69900
  AR-CGxJeC 2023-12-05T01:11:00Z Innsbruck lat=47.25829 lon=11.38934 amt=69900
  AR-Fhuqmw 2023-12-05T01:12:41Z Brno lat=49.20453 lon=16.59345 amt=50400
  AR-R2rGdH 2023-12-05T01:30:42Z Vienna lat=48.21922 lon=16.39231 amt=57900
  AR-Cz72c2 2023-12-05T01:32:59Z Graz lat=47.06515 lon=15.44313 amt=48000
```

### Snippet 7 — `.logs/python/execute_0007.py`

```python

from collections import defaultdict

rows = state['rows']

# Look at all rows for customers with single impossible travel pairs
single_travel_custs = ['arch_cust_077', 'arch_cust_080', 'arch_cust_028', 
                        'arch_cust_059', 'arch_cust_021', 'arch_cust_072']

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust in single_travel_custs:
    cust_rows = sorted(by_customer[cust], key=lambda x: x['created_at'])
    print(f"\n{cust} - {len(cust_rows)} rows:")
    for r in cust_rows:
        print(f"  {r['row_id']} {r['created_at']} {r['store_city']} lat={r['observed_lat']} lon={r['observed_lon']} amt={r['amount_cents']}")
```

**stdout:**
```
arch_cust_077 - 4 rows:
  AR-FK9ujx 2023-09-25T05:17:18Z Vienna lat=48.17479 lon=16.33528 amt=4700
  AR-4hhBwg 2023-09-27T20:29:18Z Bratislava lat=48.14404 lon=17.10974 amt=34800
  AR-FbqUUD 2023-10-08T03:10:18Z Brno lat=49.20492 lon=16.59338 amt=12400
  AR-KzPiH3 2023-10-08T03:15:26Z Ljubljana lat=46.05116 lon=14.50510 amt=9600

arch_cust_080 - 4 rows:
  AR-JY1NAg 2023-09-26T00:05:18Z Vienna lat=48.17524 lon=16.33557 amt=36000
  AR-deLU2A 2023-09-30T02:02:18Z Linz lat=48.30680 lon=14.28546 amt=68400
  AR-FZK91x 2023-10-09T03:28:18Z Innsbruck lat=47.25849 lon=11.38913 amt=1000
  AR-ZVRtcq 2023-10-09T03:35:18Z Graz lat=47.07323 lon=15.42628 amt=14000

arch_cust_028 - 6 rows:
  AR-b9rVWJ 2023-09-26T00:57:18Z Innsbruck lat=47.25841 lon=11.38914 amt=1600
  AR-RFAJ47 2023-10-01T00:47:18Z Vienna lat=48.21878 lon=16.39285 amt=96000
  AR-Wi885d 2023-10-01T21:33:18Z Vienna lat=48.17509 lon=16.33537 amt=7600
  AR-jeW3Fn 2023-10-01T21:47:18Z Brno lat=49.20432 lon=16.59344 amt=700
  AR-7SVeiD 2023-10-08T04:33:18Z Vienna lat=48.21871 lon=16.39237 amt=4400
  AR-KJXqwy 2023-10-08T04:35:44Z Salzburg lat=47.81321 lon=13.04606 amt=247000

arch_cust_059 - 3 rows:
  AR-Kpfmu6 2023-09-26T06:35:18Z Salzburg lat=47.81296 lon=13.04578 amt=15600
  AR-KzKRkf 2023-10-08T04:05:18Z Brno lat=49.20454 lon=16.59352 amt=4000
  AR-c54YzR 2023-10-08T04:07:57Z Innsbruck lat=47.25837 lon=11.38931 amt=18200

arch_cust_021 - 3 rows:
  AR-P9v6cv 2023-09-27T07:53:18Z Brno lat=49.20495 lon=16.59328 amt=12400
  AR-Fceajx 2023-10-09T02:53:18Z Linz lat=48.30657 lon=14.28580 amt=2400
  AR-A8K2Md 2023-10-09T02:56:18Z Ljubljana lat=46.05145 lon=14.50482 amt=6200

arch_cust_072 - 3 rows:
  AR-j5MTaD 2023-09-28T02:21:18Z Bratislava lat=48.14417 lon=17.10996 amt=9400
  AR-8Bi5dr 2023-10-08T02:53:18Z Vienna lat=48.21919 lon=16.39255 amt=2800
  AR-a8inLV 2023-10-08T03:01:03Z Salzburg lat=47.81353 lon=13.04586 amt=4800
```

### Snippet 8 — `.logs/python/execute_0008.py`

```python

from collections import defaultdict

rows = state['rows']

# Check record invariants: duplicate IDs, zero amounts
print("=== HARD SWEEP 4: Record invariants ===")

# Check duplicate row_ids
row_ids = [r['row_id'] for r in rows]
dup_row_ids = [rid for rid in row_ids if row_ids.count(rid) > 1]
print(f"Duplicate row_ids: {dup_row_ids}")

# Check duplicate archive_payment_ids
pmt_ids = [r['archive_payment_id'] for r in rows]
dup_pmt_ids = [pid for pid in pmt_ids if pmt_ids.count(pid) > 1]
print(f"Duplicate archive_payment_ids: {dup_pmt_ids}")

# Check zero/negative amounts
zero_neg = [r for r in rows if int(r['amount_cents']) <= 0]
print(f"Zero/negative amounts: {[r['row_id'] for r in zero_neg]}")

# Check identical timestamps across customers (same time, different customer)
ts_to_custs = defaultdict(list)
for r in rows:
    ts_to_custs[r['created_at']].append(r)
dup_ts = {ts: rrs for ts, rrs in ts_to_custs.items() if len(rrs) > 1}
print(f"\nIdentical timestamps (different records):")
for ts, rrs in sorted(dup_ts.items()):
    custs = [r['customer_ref'] for r in rrs]
    row_ids_ts = [r['row_id'] for r in rrs]
    if len(set(custs)) > 1:
        print(f"  {ts}: rows={row_ids_ts} custs={custs}")

# Check same customer, same amount, very close times (duplicate payment pattern)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

print(f"\n=== All currencies ===")
currencies = set(r['currency'] for r in rows)
print(f"Currencies: {currencies}")
```

**stdout:**
```
=== HARD SWEEP 4: Record invariants ===
Duplicate row_ids: []
Duplicate archive_payment_ids: []
Zero/negative amounts: []

Identical timestamps (different records):

=== All currencies ===
Currencies: {'EUR'}
```

### Snippet 9 — `.logs/python/execute_0009.py`

```python

from datetime import datetime
from collections import defaultdict

rows = state['rows']

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

# Proper stationary burst: distinct_stores >= 4 AND observed_spread < 0.05
print("=== HARD SWEEP 3b: Stationary burst (proper: spread < 0.05, 5-min window) ===")
stationary_bursts = []
max_stores_low_spread = 0

for cust, cust_rows in by_customer.items():
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        in_window = []
        for other in cust_rows:
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) < 2:
            continue
        
        stores = set(r['store_ref'] for r in in_window)
        lats = [float(r['observed_lat']) for r in in_window]
        lons = [float(r['observed_lon']) for r in in_window]
        max_spread = max(
            l1_distance(lats[a], lons[a], lats[b], lons[b])
            for a in range(len(in_window))
            for b in range(len(in_window))
        )
        
        if max_spread < 0.05:
            if len(stores) > max_stores_low_spread:
                max_stores_low_spread = len(stores)
            if len(stores) >= 4:
                stationary_bursts.append({
                    'cust': cust, 'anchor_ts': anchor['created_at'],
                    'stores': len(stores), 'spread': max_spread,
                    'rows': [r['row_id'] for r in in_window],
                })

print(f"Stationary burst (spread<0.05, stores>=4) hits: {len(stationary_bursts)}")
if stationary_bursts:
    for b in stationary_bursts:
        print(f"  {b}")
print(f"Max distinct_stores with spread<0.05 (max-metric validation): {max_stores_low_spread}")

# Also find max spread for cases with distinct_stores >= 4 (regardless of spread)
print("\n--- Checking if any stationary burst exists at all (max_metric) ---")
best = []
for cust, cust_rows in by_customer.items():
    for i, anchor in enumerate(cust_rows):
        anchor_ts = parse_ts(anchor['created_at'])
        in_window = []
        for other in cust_rows:
            other_ts = parse_ts(other['created_at'])
            minutes = (other_ts - anchor_ts).total_seconds() / 60.0
            if 0 <= minutes <= 5:
                in_window.append(other)
        
        if len(in_window) < 2:
            continue
        
        stores = set(r['store_ref'] for r in in_window)
        lats = [float(r['observed_lat']) for r in in_window]
        lons = [float(r['observed_lon']) for r in in_window]
        max_spread = max(
            l1_distance(lats[a], lons[a], lats[b], lons[b])
            for a in range(len(in_window))
            for b in range(len(in_window))
        )
        best.append((len(stores), max_spread, cust, anchor['created_at']))

best.sort(key=lambda x: -x[0])
print("Top 5 windows by distinct_stores:")
for b in best[:5]:
    print(f"  stores={b[0]} spread={b[1]:.4f} cust={b[2]} anchor={b[3]}")
```

**stdout:**
```
=== HARD SWEEP 3b: Stationary burst (proper: spread < 0.05, 5-min window) ===
Stationary burst (spread<0.05, stores>=4) hits: 0
Max distinct_stores with spread<0.05 (max-metric validation): 0

--- Checking if any stationary burst exists at all (max_metric) ---
Top 5 windows by distinct_stores:
  stores=8 spread=7.1507 cust=arch_cust_065 anchor=2023-10-26T10:00:18Z
  stores=8 spread=7.1507 cust=arch_cust_065 anchor=2023-10-26T10:00:32Z
  stores=8 spread=5.2419 cust=arch_cust_011 anchor=2023-10-27T10:00:18Z
  stores=7 spread=7.1507 cust=arch_cust_065 anchor=2023-10-26T10:00:50Z
  stores=7 spread=7.1507 cust=arch_cust_065 anchor=2023-10-26T10:01:21Z
```

### Snippet 10 — `.logs/python/execute_0010.py`

```python

from collections import defaultdict
from datetime import datetime

rows = state['rows']
row_map = {r['row_id']: r for r in rows}

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Compile fraud cohort
fraud_rows = set()
fraud_evidence = {}

# ===== HARD SIGNAL 1: Cross-actor DFP sharing =====
shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']
for dfp in shared_dfps:
    dfp_rows = [r for r in rows if r['device_fingerprint'] == dfp]
    for r in dfp_rows:
        fraud_rows.add(r['row_id'])
        fraud_evidence[r['row_id']] = f"DFP sharing: {dfp}"

print(f"After DFP sharing: {len(fraud_rows)} rows")

# ===== HARD SIGNAL 2: Impossible observed travel =====
# Collect all unique row_ids involved in impossible travel pairs (0-15 min, L1 > 2.0)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)

for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    for i in range(1, len(cust_rows)):
        prev = cust_rows[i-1]
        curr = cust_rows[i]
        
        prev_lat = float(prev['observed_lat'])
        prev_lon = float(prev['observed_lon'])
        curr_lat = float(curr['observed_lat'])
        curr_lon = float(curr['observed_lon'])
        
        prev_ts = parse_ts(prev['created_at'])
        curr_ts = parse_ts(curr['created_at'])
        
        minutes = (curr_ts - prev_ts).total_seconds() / 60.0
        l1 = l1_distance(prev_lat, prev_lon, curr_lat, curr_lon)
        
        if 0 <= minutes <= 15 and l1 > 2.0:
            fraud_rows.add(prev['row_id'])
            fraud_rows.add(curr['row_id'])
            travel_desc = f"impossible travel: {prev['store_city']}->{curr['store_city']} in {minutes:.1f}min L1={l1:.3f}"
            if prev['row_id'] not in fraud_evidence:
                fraud_evidence[prev['row_id']] = travel_desc
            if curr['row_id'] not in fraud_evidence:
                fraud_evidence[curr['row_id']] = travel_desc

print(f"After impossible travel: {len(fraud_rows)} rows")

# Print all fraud rows with evidence
print("\nFraud cohort:")
total_cents = 0
for row_id in sorted(fraud_rows):
    r = row_map[row_id]
    cents = int(r['amount_cents'])
    total_cents += cents
    print(f"  {row_id} cust={r['customer_ref']} {r['created_at']} {r['store_city']} amt={cents} evidence={fraud_evidence[row_id]}")

print(f"\nTotal rows: {len(fraud_rows)}")
print(f"Total amount: {total_cents} cents = EUR {total_cents // 100}.{total_cents % 100:02d}")
```

**stdout:**
```
After DFP sharing: 12 rows
After impossible travel: 60 rows

Fraud cohort:
  AR-3apJaL cust=arch_cust_065 2023-10-26T10:03:58Z Innsbruck amt=7900 evidence=impossible travel: Graz->Innsbruck in 0.8min L1=4.221
  AR-3pNGua cust=arch_cust_078 2023-11-23T06:07:42Z Graz amt=48000 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-4bvBaW cust=arch_cust_086 2023-11-24T06:04:06Z Innsbruck amt=65300 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-7DnJeE cust=arch_cust_057 2023-11-23T05:56:54Z Linz amt=22700 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-7JpJje cust=arch_cust_011 2023-10-27T10:00:41Z Linz amt=1000 evidence=impossible travel: Graz->Linz in 0.4min L1=2.374
  AR-7SVeiD cust=arch_cust_028 2023-10-08T04:33:18Z Vienna amt=4400 evidence=impossible travel: Vienna->Salzburg in 2.4min L1=3.752
  AR-7xrWuM cust=arch_cust_011 2023-10-27T10:03:14Z Graz amt=2800 evidence=impossible travel: Vienna->Graz in 0.1min L1=2.103
  AR-82WAxz cust=arch_cust_065 2023-10-26T10:04:18Z Bratislava amt=5200 evidence=impossible travel: Innsbruck->Bratislava in 0.3min L1=6.606
  AR-8Bi5dr cust=arch_cust_072 2023-10-08T02:53:18Z Vienna amt=2800 evidence=impossible travel: Vienna->Salzburg in 7.8min L1=3.752
  AR-9Y7TRZ cust=arch_cust_065 2023-10-26T10:00:18Z Salzburg amt=2000 evidence=impossible travel: Salzburg->Vienna in 0.2min L1=3.651
  AR-A8K2Md cust=arch_cust_021 2023-10-09T02:56:18Z Ljubljana amt=6200 evidence=impossible travel: Linz->Ljubljana in 3.0min L1=2.474
  AR-CGxJeC cust=arch_cust_052 2023-12-05T01:11:00Z Innsbruck amt=69900 evidence=impossible travel: Ljubljana->Innsbruck in 9.9min L1=4.323
  AR-CkpJTq cust=arch_cust_011 2023-10-27T10:02:42Z Vienna amt=9100 evidence=impossible travel: Ljubljana->Vienna in 0.2min L1=3.954
  AR-Cz72c2 cust=arch_cust_052 2023-12-05T01:32:59Z Graz amt=48000 evidence=impossible travel: Vienna->Graz in 2.3min L1=2.103
  AR-EAeuiL cust=arch_cust_065 2023-10-26T10:03:13Z Graz amt=2000 evidence=impossible travel: Bratislava->Graz in 0.5min L1=2.754
  AR-EWjHjK cust=arch_cust_011 2023-10-27T10:01:24Z Linz amt=9600 evidence=impossible travel: Linz->Ljubljana in 0.3min L1=2.475
  AR-FHgLUN cust=arch_cust_065 2023-10-26T10:06:22Z Linz amt=7900 evidence=impossible travel: Brno->Linz in 1.5min L1=3.205
  AR-FZK91x cust=arch_cust_080 2023-10-09T03:28:18Z Innsbruck amt=1000 evidence=impossible travel: Innsbruck->Graz in 7.0min L1=4.222
  AR-FbqUUD cust=arch_cust_077 2023-10-08T03:10:18Z Brno amt=12400 evidence=impossible travel: Brno->Ljubljana in 5.1min L1=5.242
  AR-Fceajx cust=arch_cust_021 2023-10-09T02:53:18Z Linz amt=2400 evidence=impossible travel: Linz->Ljubljana in 3.0min L1=2.474
  AR-FfgYrP cust=arch_cust_076 2023-10-20T02:02:04Z Brno amt=214100 evidence=impossible travel: Brno->Ljubljana in 3.0min L1=5.242
  AR-Fhuqmw cust=arch_cust_052 2023-12-05T01:12:41Z Brno amt=50400 evidence=impossible travel: Innsbruck->Brno in 1.7min L1=7.150
  AR-GFxdWw cust=arch_cust_011 2023-10-27T10:01:00Z Brno amt=14000 evidence=impossible travel: Linz->Brno in 0.3min L1=3.205
  AR-HMazkN cust=arch_cust_076 2023-10-20T02:33:28Z Graz amt=183000 evidence=impossible travel: Vienna->Graz in 12.2min L1=2.011
  AR-KJXqwy cust=arch_cust_028 2023-10-08T04:35:44Z Salzburg amt=247000 evidence=impossible travel: Vienna->Salzburg in 2.4min L1=3.752
  AR-KzKRkf cust=arch_cust_059 2023-10-08T04:05:18Z Brno amt=4000 evidence=impossible travel: Brno->Innsbruck in 2.6min L1=7.150
  AR-KzPiH3 cust=arch_cust_077 2023-10-08T03:15:26Z Ljubljana amt=9600 evidence=impossible travel: Brno->Ljubljana in 5.1min L1=5.242
  AR-MEbLC9 cust=arch_cust_011 2023-10-08T03:53:18Z Vienna amt=8800 evidence=impossible travel: Vienna->Innsbruck in 7.5min L1=5.963
  AR-NJPjX8 cust=arch_cust_065 2023-10-26T10:01:48Z Bratislava amt=6500 evidence=impossible travel: Bratislava->Linz in 0.4min L1=2.987
  AR-Nmiezi cust=arch_cust_011 2023-10-27T10:02:31Z Ljubljana amt=4300 evidence=impossible travel: Ljubljana->Vienna in 0.2min L1=3.954
  AR-P853L2 cust=arch_cust_076 2023-10-20T02:21:17Z Vienna amt=214100 evidence=impossible travel: Vienna->Graz in 12.2min L1=2.011
  AR-R2rGdH cust=arch_cust_052 2023-12-05T01:30:42Z Vienna amt=57900 evidence=impossible travel: Vienna->Graz in 2.3min L1=2.103
  AR-SPFS5k cust=arch_cust_065 2023-10-26T10:00:32Z Vienna amt=8400 evidence=impossible travel: Salzburg->Vienna in 0.2min L1=3.651
  AR-TLvcQE cust=arch_cust_052 2023-12-05T01:01:04Z Ljubljana amt=69900 evidence=impossible travel: Ljubljana->Innsbruck in 9.9min L1=4.323
  AR-Tbv2Dc cust=arch_cust_065 2023-10-26T10:01:43Z Vienna amt=2400 evidence=impossible travel: Salzburg->Vienna in 0.4min L1=3.753
  AR-TukfPA cust=arch_cust_011 2023-10-27T10:00:18Z Graz amt=1600 evidence=impossible travel: Graz->Linz in 0.4min L1=2.374
  AR-UYgiDA cust=arch_cust_071 2023-11-23T06:04:06Z Linz amt=21600 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-UyBZ7e cust=arch_cust_065 2023-10-26T10:02:42Z Bratislava amt=500 evidence=impossible travel: Salzburg->Bratislava in 0.1min L1=4.395
  AR-VLnGku cust=arch_cust_065 2023-10-26T10:02:10Z Linz amt=7900 evidence=impossible travel: Bratislava->Linz in 0.4min L1=2.987
  AR-Vz1Yp6 cust=arch_cust_065 2023-10-26T10:00:50Z Bratislava amt=2500 evidence=impossible travel: Bratislava->Salzburg in 0.5min L1=4.394
  AR-XrKRJF cust=arch_cust_097 2023-11-24T06:07:42Z Brno amt=27600 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-YVmNNJ cust=arch_cust_064 2023-11-23T06:00:30Z Graz amt=65300 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-YiGah2 cust=arch_cust_085 2023-11-23T06:11:18Z Brno amt=26400 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-ZVRtcq cust=arch_cust_080 2023-10-09T03:35:18Z Graz amt=14000 evidence=impossible travel: Innsbruck->Graz in 7.0min L1=4.222
  AR-a8inLV cust=arch_cust_072 2023-10-08T03:01:03Z Salzburg amt=4800 evidence=impossible travel: Vienna->Salzburg in 7.8min L1=3.752
  AR-apeKg7 cust=arch_cust_011 2023-10-08T04:00:46Z Innsbruck amt=2000 evidence=impossible travel: Vienna->Innsbruck in 7.5min L1=5.963
  AR-b3JUxG cust=arch_cust_076 2023-10-20T02:05:03Z Ljubljana amt=69900 evidence=impossible travel: Brno->Ljubljana in 3.0min L1=5.242
  AR-bGvr7H cust=arch_cust_065 2023-10-26T10:01:21Z Salzburg amt=3300 evidence=impossible travel: Bratislava->Salzburg in 0.5min L1=4.394
  AR-bNbJbT cust=arch_cust_075 2023-11-24T06:00:30Z Bratislava amt=22700 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-boP9yJ cust=arch_cust_008 2023-11-24T06:11:18Z Innsbruck amt=34200 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-c54YzR cust=arch_cust_059 2023-10-08T04:07:57Z Innsbruck amt=18200 evidence=impossible travel: Brno->Innsbruck in 2.6min L1=7.150
  AR-d3nqzP cust=arch_cust_050 2023-11-23T05:53:18Z Linz amt=50400 evidence=DFP sharing: dev_arch_HiZesFhREbYh
  AR-dJUm2U cust=arch_cust_011 2023-10-27T10:01:06Z Linz amt=700 evidence=impossible travel: Brno->Linz in 0.1min L1=3.205
  AR-e4jREQ cust=arch_cust_053 2023-11-24T05:53:18Z Vienna amt=57900 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-eanseK cust=arch_cust_011 2023-10-27T10:03:06Z Vienna amt=6200 evidence=impossible travel: Vienna->Graz in 0.1min L1=2.103
  AR-ek3T33 cust=arch_cust_064 2023-11-24T05:56:54Z Linz amt=183000 evidence=DFP sharing: dev_arch_JWYVrTPvoW7V
  AR-fGXvXQ cust=arch_cust_065 2023-10-26T10:04:54Z Brno amt=5700 evidence=impossible travel: Brno->Linz in 1.5min L1=3.205
  AR-heFEta cust=arch_cust_011 2023-10-27T10:01:43Z Ljubljana amt=9200 evidence=impossible travel: Linz->Ljubljana in 0.3min L1=2.475
  AR-hv9gFT cust=arch_cust_011 2023-10-27T10:03:27Z Vienna amt=7900 evidence=impossible travel: Graz->Vienna in 0.2min L1=2.002
  AR-jKd1oY cust=arch_cust_065 2023-10-26T10:02:34Z Salzburg amt=800 evidence=impossible travel: Salzburg->Bratislava in 0.1min L1=4.395

Total rows: 60
Total amount: 2069300 cents = EUR 20693.00
```

### Snippet 11 — `.logs/python/execute_0011.py`

```python

from collections import defaultdict
from datetime import datetime

rows = state['rows']
row_map = {r['row_id']: r for r in rows}

def parse_ts(ts):
    return datetime.fromisoformat(ts.replace('Z', '+00:00'))

def l1_distance(lat1, lon1, lat2, lon2):
    return abs(lat1 - lat2) + abs(lon1 - lon2)

# Build final fraud cohort
fraud_rows = set()
fraud_evidence = {}

# HARD SIGNAL 1: Cross-actor DFP sharing
shared_dfps = ['dev_arch_HiZesFhREbYh', 'dev_arch_JWYVrTPvoW7V']
for dfp in shared_dfps:
    for r in rows:
        if r['device_fingerprint'] == dfp:
            fraud_rows.add(r['row_id'])
            fraud_evidence[r['row_id']] = f"cross-actor DFP sharing ({dfp})"

# HARD SIGNAL 2: Impossible observed travel (0-15 min window, L1 > 2.0)
by_customer = defaultdict(list)
for r in rows:
    by_customer[r['customer_ref']].append(r)
for cust, cust_rows in by_customer.items():
    cust_rows = sorted(cust_rows, key=lambda x: x['created_at'])
    for i in range(1, len(cust_rows)):
        prev, curr = cust_rows[i-1], cust_rows[i]
        l1 = l1_distance(float(prev['observed_lat']), float(prev['observed_lon']),
                         float(curr['observed_lat']), float(curr['observed_lon']))
        mins = (parse_ts(curr['created_at']) - parse_ts(prev['created_at'])).total_seconds() / 60.0
        if 0 <= mins <= 15 and l1 > 2.0:
            for rid, r in [(prev['row_id'], prev), (curr['row_id'], curr)]:
                fraud_rows.add(rid)
                if rid not in fraud_evidence:
                    fraud_evidence[rid] = f"impossible travel: {prev['store_city']}->{curr['store_city']} in {mins:.1f}min L1={l1:.3f}"

# Compute total
total_cents = sum(int(row_map[rid]['amount_cents']) for rid in fraud_rows)
total_euros = total_cents // 100
total_cents_rem = total_cents % 100
print(f"Total fraud rows: {len(fraud_rows)}")
print(f"Total: EUR {total_euros}.{total_cents_rem:02d}")

# Build refs list (row refs as required by task)
ARCHIVE_PATH = "/archive/payment_batch_export_DpD8iQtr2j.tsv"
refs = sorted([f"{ARCHIVE_PATH}#row={rid}" for rid in fraud_rows])
print(f"\nRefs count: {len(refs)}")

# Update scratchpad with sweep ledger
scratchpad["hard_sweep_ledger"] = {
    "scope": "all rows in /archive/payment_batch_export_DpD8iQtr2j.tsv (208 rows)",
    "universe_size": 208,
    "columns_considered": ["row_id","archive_payment_id","created_at","customer_ref","store_ref","store_city","amount_cents","currency","payment_method_fingerprint","device_fingerprint","observed_lat","observed_lon","sku_summary","archive_channel"],
    "PMF_cross_actor": {"result": "zero", "max_metric": "no duplicates"},
    "DFP_cross_actor": {"result": "hard hit", "count": 2, "dfps": shared_dfps, "rows": 12},
    "workflow_state": {"result": "not applicable", "reason": "no payment_status or 3DS columns in export"},
    "record_invariants": {"result": "zero", "max_metric": "no dup row_ids, no dup payment_ids, no zero amounts"},
    "impossible_observed_travel": {"result": "hard hit", "pairs_found": 28, "rows_flagged_cumulative": len(fraud_rows) - 12},
    "stationary_single_actor_burst": {"result": "zero", "max_metric": "max distinct_stores with spread<0.05 = 0"},
}
scratchpad["business_process"] = {
    "primary": "fraud_risk_review.md",
    "reason": "Archived payment export review to identify fraud rows via hard sweep"
}
scratchpad["answer"] = f"EUR {total_euros}.{total_cents_rem:02d}"
scratchpad["fraud_row_count"] = len(fraud_rows)
scratchpad["total_cents"] = total_cents
scratchpad["refs"] = refs
print("Scratchpad updated.")
```

**stdout:**
```
Total fraud rows: 60
Total: EUR 20693.00

Refs count: 60
Scratchpad updated.
```

### Snippet 12 — `.logs/python/execute_0012.py`

```python

# Final submission
ARCHIVE_PATH = "/archive/payment_batch_export_DpD8iQtr2j.tsv"
refs = scratchpad["refs"]  # already built and stored

message = f"EUR 20693.00"

submit_and_exit(
    message=message,
    outcome="OUTCOME_OK",
    refs=refs
)
```

**Inner tool calls** (in order):
- `answer outcome=OUTCOME_OK refs=['/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3apJaL', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3pNGua', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-4bvBaW', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7DnJeE', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7JpJje', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7SVeiD', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7xrWuM', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-82WAxz', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-8Bi5dr', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-9Y7TRZ', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-A8K2Md', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CGxJeC', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CkpJTq', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Cz72c2', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EAeuiL', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EWjHjK', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FHgLUN', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FZK91x', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FbqUUD', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fceajx', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FfgYrP', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fhuqmw', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-GFxdWw', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-HMazkN', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KJXqwy', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzKRkf', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzPiH3', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-MEbLC9', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-NJPjX8', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Nmiezi', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-P853L2', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-R2rGdH', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-SPFS5k', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TLvcQE', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Tbv2Dc', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TukfPA', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UYgiDA', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UyBZ7e', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-VLnGku', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Vz1Yp6', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-XrKRJF', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YVmNNJ', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YiGah2', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ZVRtcq', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-a8inLV', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-apeKg7', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-b3JUxG', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bGvr7H', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bNbJbT', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-boP9yJ', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-c54YzR', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-d3nqzP', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-dJUm2U', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-e4jREQ', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-eanseK', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ek3T33', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-fGXvXQ', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-heFEta', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-hv9gFT', '/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-jKd1oY']`

_(no stdout / stderr)_

## Final scratchpad

```json
{
  "refs": [
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3apJaL",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-3pNGua",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-4bvBaW",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7DnJeE",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7JpJje",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7SVeiD",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-7xrWuM",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-82WAxz",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-8Bi5dr",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-9Y7TRZ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-A8K2Md",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CGxJeC",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-CkpJTq",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Cz72c2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EAeuiL",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-EWjHjK",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FHgLUN",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FZK91x",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FbqUUD",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fceajx",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-FfgYrP",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Fhuqmw",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-GFxdWw",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-HMazkN",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KJXqwy",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzKRkf",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-KzPiH3",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-MEbLC9",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-NJPjX8",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Nmiezi",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-P853L2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-R2rGdH",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-SPFS5k",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TLvcQE",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Tbv2Dc",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-TukfPA",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UYgiDA",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-UyBZ7e",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-VLnGku",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-Vz1Yp6",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-XrKRJF",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YVmNNJ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-YiGah2",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ZVRtcq",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-a8inLV",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-apeKg7",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-b3JUxG",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bGvr7H",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-bNbJbT",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-boP9yJ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-c54YzR",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-d3nqzP",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-dJUm2U",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-e4jREQ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-eanseK",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-ek3T33",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-fGXvXQ",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-heFEta",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-hv9gFT",
    "/archive/payment_batch_export_DpD8iQtr2j.tsv#row=AR-jKd1oY"
  ],
  "hard_sweep_ledger": {
    "scope": "all rows in /archive/payment_batch_export_DpD8iQtr2j.tsv (208 rows)",
    "universe_size": 208,
    "columns_considered": [
      "row_id",
      "archive_payment_id",
      "created_at",
      "customer_ref",
      "store_ref",
      "store_city",
      "amount_cents",
      "currency",
      "payment_method_fingerprint",
      "device_fingerprint",
      "observed_lat",
      "observed_lon",
      "sku_summary",
      "archive_channel"
    ],
    "PMF_cross_actor": {
      "result": "zero",
      "max_metric": "no duplicates"
    },
    "DFP_cross_actor": {
      "result": "hard hit",
      "count": 2,
      "dfps": [
        "dev_arch_HiZesFhREbYh",
        "dev_arch_JWYVrTPvoW7V"
      ],
      "rows": 12
    },
    "workflow_state": {
      "result": "not applicable",
      "reason": "no payment_status or 3DS columns in export"
    },
    "record_invariants": {
      "result": "zero",
      "max_metric": "no dup row_ids, no dup payment_ids, no zero amounts"
    },
    "impossible_observed_travel": {
      "result": "hard hit",
      "pairs_found": 28,
      "rows_flagged_cumulative": 48
    },
    "stationary_single_actor_burst": {
      "result": "zero",
      "max_metric": "max distinct_stores with spread<0.05 = 0"
    }
  },
  "business_process": {
    "primary": "fraud_risk_review.md",
    "reason": "Archived payment export review to identify fraud rows via hard sweep"
  },
  "answer": "EUR 20693.00",
  "fraud_row_count": 60,
  "total_cents": 2069300,
  "message": "EUR 20693.00",
  "outcome": "OUTCOME_OK"
}
```

## Final state

```json
{
  "rows": [
    {
      "row_id": "AR-NRV4JK",
      "archive_payment_id": "ap_KSrnEvcZ6j",
      "created_at": "2023-09-24T16:53:18Z",
      "customer_ref": "arch_cust_044",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3R4eVPfEmq1e",
      "device_fingerprint": "dev_arch_XosPJfG3jwDF",
      "observed_lat": "46.05088",
      "observed_lon": "14.50511",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Rvrr8H",
      "archive_payment_id": "ap_D5Zn77vdgF",
      "created_at": "2023-09-24T18:43:18Z",
      "customer_ref": "arch_cust_058",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "15600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_pp5iZve7GBpJ",
      "device_fingerprint": "dev_arch_UDFBzLPcKpHY",
      "observed_lat": "48.14418",
      "observed_lon": "17.11001",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-iREC5w",
      "archive_payment_id": "ap_44NJ9JzWgq",
      "created_at": "2023-09-24T19:08:18Z",
      "customer_ref": "arch_cust_084",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "41400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_6H4UsPs62oAk",
      "device_fingerprint": "dev_arch_BezF59zEt1pn",
      "observed_lat": "48.14419",
      "observed_lon": "17.10992",
      "sku_summary": "Festool Modular CTL XPW-76I",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-cnhppm",
      "archive_payment_id": "ap_DihEu4Jg6S",
      "created_at": "2023-09-24T20:03:18Z",
      "customer_ref": "arch_cust_009",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "19800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Bu9BySMuG9gf",
      "device_fingerprint": "dev_arch_Luy5nVXFTiiu",
      "observed_lat": "49.20466",
      "observed_lon": "16.59351",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-YJVjDE",
      "archive_payment_id": "ap_46XYz3ST7o",
      "created_at": "2023-09-24T20:37:18Z",
      "customer_ref": "arch_cust_062",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "7300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Jy7rJx7vZ2wM",
      "device_fingerprint": "dev_arch_5BNSdSa5KNvX",
      "observed_lat": "49.20494",
      "observed_lon": "16.59386",
      "sku_summary": "Bahco Workshop BAH 3VZ-SPH",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-7tt9cV",
      "archive_payment_id": "ap_AGUiA5G2mo",
      "created_at": "2023-09-25T02:23:18Z",
      "customer_ref": "arch_cust_067",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "5600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SHRz65JV8GSG",
      "device_fingerprint": "dev_arch_NYvFYah2oQBb",
      "observed_lat": "47.06567",
      "observed_lon": "15.44277",
      "sku_summary": "Gorilla Crystal Grip 2ZQ-D83",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Pxxr9y",
      "archive_payment_id": "ap_5evamVN3cq",
      "created_at": "2023-09-25T02:38:18Z",
      "customer_ref": "arch_cust_007",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "4800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_YAdeMq2uacce",
      "device_fingerprint": "dev_arch_2NQ14Cr8CJhn",
      "observed_lat": "49.20483",
      "observed_lon": "16.59381",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-RHzdfU",
      "archive_payment_id": "ap_DAbWvWQVUf",
      "created_at": "2023-09-25T03:18:18Z",
      "customer_ref": "arch_cust_055",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_ARPL5rSztyX5",
      "device_fingerprint": "dev_arch_ETdaKwaTyqiC",
      "observed_lat": "48.30714",
      "observed_lon": "14.28553",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-VwoMW9",
      "archive_payment_id": "ap_HHTJhHzams",
      "created_at": "2023-09-25T04:05:18Z",
      "customer_ref": "arch_cust_063",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "31600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_EJkevjUuRXj7",
      "device_fingerprint": "dev_arch_8KNFUtgA5yWs",
      "observed_lat": "47.06547",
      "observed_lon": "15.44292",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-FK9ujx",
      "archive_payment_id": "ap_4seMCJhs3T",
      "created_at": "2023-09-25T05:17:18Z",
      "customer_ref": "arch_cust_077",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "4700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_V3YMiABsyBPv",
      "device_fingerprint": "dev_arch_Xxr4gRJv2wiD",
      "observed_lat": "48.17479",
      "observed_lon": "16.33528",
      "sku_summary": "Festool Modular CTL XPW-76I",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-3251wn",
      "archive_payment_id": "ap_C8CUqr9sE9",
      "created_at": "2023-09-25T08:38:18Z",
      "customer_ref": "arch_cust_019",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "2200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_6ErfSL6ZV5qZ",
      "device_fingerprint": "dev_arch_NGxnksi47EFP",
      "observed_lat": "46.05111",
      "observed_lon": "14.50480",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-9Rx44H",
      "archive_payment_id": "ap_LuDud4Mtid",
      "created_at": "2023-09-25T09:23:18Z",
      "customer_ref": "arch_cust_008",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "1400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_U3HTwkC4dBgD",
      "device_fingerprint": "dev_arch_K8mgXo2cfFB8",
      "observed_lat": "49.20444",
      "observed_lon": "16.59347",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-TCZB6S",
      "archive_payment_id": "ap_R8rEKy5RGp",
      "created_at": "2023-09-25T10:51:18Z",
      "customer_ref": "arch_cust_070",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "9300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DvL8G87Rg6WL",
      "device_fingerprint": "dev_arch_NvWAAoqgvseS",
      "observed_lat": "47.06581",
      "observed_lon": "15.44307",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-YE7rXk",
      "archive_payment_id": "ap_DrPj5yCEf9",
      "created_at": "2023-09-25T11:11:18Z",
      "customer_ref": "arch_cust_073",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "1400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PYmEGurzJBQc",
      "device_fingerprint": "dev_arch_Y2Ge4LVUK2cv",
      "observed_lat": "47.06571",
      "observed_lon": "15.44311",
      "sku_summary": "Bahco Workshop BAH 3VZ-SPH",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4kUmNk",
      "archive_payment_id": "ap_Fd25DmdyvG",
      "created_at": "2023-09-25T12:43:18Z",
      "customer_ref": "arch_cust_031",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "1600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9ts1pb8Fq1Ng",
      "device_fingerprint": "dev_arch_LsKW4g1WUqaL",
      "observed_lat": "49.20483",
      "observed_lon": "16.59355",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-ZSDgPs",
      "archive_payment_id": "ap_4xg6LwDmeX",
      "created_at": "2023-09-25T12:50:18Z",
      "customer_ref": "arch_cust_045",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "30200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UFT1NUjQxYrZ",
      "device_fingerprint": "dev_arch_A7tbq5ZJAWrA",
      "observed_lat": "48.30678",
      "observed_lon": "14.28597",
      "sku_summary": "Ryobi Precision RLM 2KQ-R4C",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-Dgpy7z",
      "archive_payment_id": "ap_GMEcRyA64a",
      "created_at": "2023-09-25T14:31:18Z",
      "customer_ref": "arch_cust_091",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "11400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SJ6NLKRKCRUK",
      "device_fingerprint": "dev_arch_8YT6x1N7TTjo",
      "observed_lat": "48.30723",
      "observed_lon": "14.28576",
      "sku_summary": "Philips Professional Hue 3JS-MSN",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-D29Fgk",
      "archive_payment_id": "ap_Pzc4R7mkk7",
      "created_at": "2023-09-25T17:23:18Z",
      "customer_ref": "arch_cust_100",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_NZ4y3WXJzbBR",
      "device_fingerprint": "dev_arch_HCenKmjyfArt",
      "observed_lat": "47.06530",
      "observed_lon": "15.44293",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-e7wKmY",
      "archive_payment_id": "ap_PD4Dt51QDh",
      "created_at": "2023-09-25T18:33:18Z",
      "customer_ref": "arch_cust_035",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "26400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HLTsFpPBrmCa",
      "device_fingerprint": "dev_arch_7tGsYYzW3mHW",
      "observed_lat": "47.06516",
      "observed_lon": "15.44313",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-Q9A5wW",
      "archive_payment_id": "ap_JVxZUMyn9A",
      "created_at": "2023-09-25T20:47:18Z",
      "customer_ref": "arch_cust_043",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "100800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_JvLg1kvDFseq",
      "device_fingerprint": "dev_arch_X2GHyDDLqnM9",
      "observed_lat": "48.30665",
      "observed_lon": "14.28547",
      "sku_summary": "Ryobi Precision RLM 2KQ-R4C",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-d5wRH6",
      "archive_payment_id": "ap_HV3dtZGKPA",
      "created_at": "2023-09-25T22:39:18Z",
      "customer_ref": "arch_cust_078",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "15100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_15T6EFdF5djG",
      "device_fingerprint": "dev_arch_GHw9k1PtZhLN",
      "observed_lat": "48.30680",
      "observed_lon": "14.28591",
      "sku_summary": "Ryobi Precision RLM 2KQ-R4C",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-JY1NAg",
      "archive_payment_id": "ap_GmiGz622mT",
      "created_at": "2023-09-26T00:05:18Z",
      "customer_ref": "arch_cust_080",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "36000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CzWAXasb7zr1",
      "device_fingerprint": "dev_arch_SFM3mKsLF3Rv",
      "observed_lat": "48.17524",
      "observed_lon": "16.33557",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-b9rVWJ",
      "archive_payment_id": "ap_Ey8x5b9c6V",
      "created_at": "2023-09-26T00:57:18Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "1600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LYbMcvv5kknq",
      "device_fingerprint": "dev_arch_HBumcv529yY2",
      "observed_lat": "47.25841",
      "observed_lon": "11.38914",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-HgZ7tX",
      "archive_payment_id": "ap_Vg7ACGzpg8",
      "created_at": "2023-09-26T02:02:18Z",
      "customer_ref": "arch_cust_030",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "52800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FaULui3c5iof",
      "device_fingerprint": "dev_arch_UR5ZVyasSJPD",
      "observed_lat": "47.07380",
      "observed_lon": "15.42613",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-3XmYfZ",
      "archive_payment_id": "ap_QwBSJU3GH9",
      "created_at": "2023-09-26T04:35:18Z",
      "customer_ref": "arch_cust_022",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "18000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9xLTnV3RB19i",
      "device_fingerprint": "dev_arch_XPcPEqqjFVma",
      "observed_lat": "47.25837",
      "observed_lon": "11.38921",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Kpfmu6",
      "archive_payment_id": "ap_2PNqCAkFAu",
      "created_at": "2023-09-26T06:35:18Z",
      "customer_ref": "arch_cust_059",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "15600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Twcrh4gmz33f",
      "device_fingerprint": "dev_arch_BVscGjbXHJa8",
      "observed_lat": "47.81296",
      "observed_lon": "13.04578",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-ZSSRo1",
      "archive_payment_id": "ap_EaLd3mK5N4",
      "created_at": "2023-09-26T15:33:18Z",
      "customer_ref": "arch_cust_081",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "2400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Cyu58VkQ9wd7",
      "device_fingerprint": "dev_arch_SuHSMjtoRdH7",
      "observed_lat": "47.25821",
      "observed_lon": "11.38906",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-9oDBzj",
      "archive_payment_id": "ap_9HhSAsJHsb",
      "created_at": "2023-09-26T16:25:18Z",
      "customer_ref": "arch_cust_033",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "2000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PZXNsFhoLURA",
      "device_fingerprint": "dev_arch_PUaPTkYgPBYh",
      "observed_lat": "47.81316",
      "observed_lon": "13.04602",
      "sku_summary": "Helios Professional Helios 29A-FTE",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-hEaKq5",
      "archive_payment_id": "ap_9AWhtVTLCV",
      "created_at": "2023-09-26T18:23:18Z",
      "customer_ref": "arch_cust_086",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "247000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_AYoHN8iNtC8Y",
      "device_fingerprint": "dev_arch_5b9t4bfcdCgY",
      "observed_lat": "47.81285",
      "observed_lon": "13.04587",
      "sku_summary": "Makita Workshop DDF OIE-YYP",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-CeYrNf",
      "archive_payment_id": "ap_Kkniqd9UVg",
      "created_at": "2023-09-26T19:17:18Z",
      "customer_ref": "arch_cust_060",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "11200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_8trs7eUxQvKo",
      "device_fingerprint": "dev_arch_5qa9gV6eN2Lg",
      "observed_lat": "48.14401",
      "observed_lon": "17.10944",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-2x5zo9",
      "archive_payment_id": "ap_ZSDf8DRme9",
      "created_at": "2023-09-26T21:23:18Z",
      "customer_ref": "arch_cust_026",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "11700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_XsEbPe4AYsQy",
      "device_fingerprint": "dev_arch_9XwcdMLswK8f",
      "observed_lat": "48.21902",
      "observed_lon": "16.39262",
      "sku_summary": "Schneider Electric Heavy Duty Merten 214-ZHY",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-RSKRVm",
      "archive_payment_id": "ap_F7vh6NPCm4",
      "created_at": "2023-09-27T00:57:18Z",
      "customer_ref": "arch_cust_008",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Dd4rgWYTsJMG",
      "device_fingerprint": "dev_arch_K8mgXo2cfFB8",
      "observed_lat": "47.25837",
      "observed_lon": "11.38923",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-44VQHK",
      "archive_payment_id": "ap_9Bn1KXfGa8",
      "created_at": "2023-09-27T01:57:18Z",
      "customer_ref": "arch_cust_082",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "1700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vj28WUeTUhD3",
      "device_fingerprint": "dev_arch_E1DCK8GfQ347",
      "observed_lat": "48.14362",
      "observed_lon": "17.10964",
      "sku_summary": "Portwest PW3 DX 3TU-ST2",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-sj7DPz",
      "archive_payment_id": "ap_Ugcb82bNSi",
      "created_at": "2023-09-27T02:57:18Z",
      "customer_ref": "arch_cust_061",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "2400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_GdB8s2dVhQUt",
      "device_fingerprint": "dev_arch_NaMEpwGQgu6D",
      "observed_lat": "48.21898",
      "observed_lon": "16.39249",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-UmNg2h",
      "archive_payment_id": "ap_9Zz5oq7orp",
      "created_at": "2023-09-27T04:20:18Z",
      "customer_ref": "arch_cust_004",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "4300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HYr3i4iWDNUw",
      "device_fingerprint": "dev_arch_3PT3yX6zWjdK",
      "observed_lat": "49.20433",
      "observed_lon": "16.59387",
      "sku_summary": "Philips Professional Hue 3JS-MSN",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-iRq2Ux",
      "archive_payment_id": "ap_TRzbird1aU",
      "created_at": "2023-09-27T04:29:18Z",
      "customer_ref": "arch_cust_023",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "14000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_QNPE7YQAGV8L",
      "device_fingerprint": "dev_arch_8riZYssQZK6n",
      "observed_lat": "48.30693",
      "observed_lon": "14.28548",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4WRN9w",
      "archive_payment_id": "ap_XAv53zXssU",
      "created_at": "2023-09-27T05:01:18Z",
      "customer_ref": "arch_cust_041",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "1200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_U6s3qPtDaWRb",
      "device_fingerprint": "dev_arch_WmVB68vSbqGQ",
      "observed_lat": "47.81343",
      "observed_lon": "13.04593",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-7zJZas",
      "archive_payment_id": "ap_AvmeMgf3Mf",
      "created_at": "2023-09-27T06:05:18Z",
      "customer_ref": "arch_cust_095",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "9200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_5sPq7CWKujxY",
      "device_fingerprint": "dev_arch_UVJAxm1xL9Fb",
      "observed_lat": "48.14373",
      "observed_lon": "17.11001",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-FAVy5n",
      "archive_payment_id": "ap_CnoYpXQXs8",
      "created_at": "2023-09-27T07:48:18Z",
      "customer_ref": "arch_cust_047",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "9000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4C2VxWrYaZdi",
      "device_fingerprint": "dev_arch_C7SRNL6srwin",
      "observed_lat": "48.21868",
      "observed_lon": "16.39238",
      "sku_summary": "Viega Professional Sanpress 2OG-ENN",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-P9v6cv",
      "archive_payment_id": "ap_7HMg94hEk3",
      "created_at": "2023-09-27T07:53:18Z",
      "customer_ref": "arch_cust_021",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "12400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Re88qR4G9ng2",
      "device_fingerprint": "dev_arch_PQNWAD4LknsB",
      "observed_lat": "49.20495",
      "observed_lon": "16.59328",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-ExTNgj",
      "archive_payment_id": "ap_KKtM7iZfaQ",
      "created_at": "2023-09-27T09:17:18Z",
      "customer_ref": "arch_cust_090",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UJ8iq9RoQL22",
      "device_fingerprint": "dev_arch_B8Z5pJhbjYRu",
      "observed_lat": "47.81352",
      "observed_lon": "13.04581",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-3iNEYB",
      "archive_payment_id": "ap_EYvoEWDr3c",
      "created_at": "2023-09-27T10:32:18Z",
      "customer_ref": "arch_cust_075",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "7800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9XjhwYy5fNoU",
      "device_fingerprint": "dev_arch_L5EY8fTdNsYS",
      "observed_lat": "48.30688",
      "observed_lon": "14.28564",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-huoKEq",
      "archive_payment_id": "ap_Mw6UQuucwJ",
      "created_at": "2023-09-27T12:02:18Z",
      "customer_ref": "arch_cust_083",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "27900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_TfdcEmJdGWUh",
      "device_fingerprint": "dev_arch_AfSZCZZhE4eV",
      "observed_lat": "48.17471",
      "observed_lon": "16.33547",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-61932v",
      "archive_payment_id": "ap_Q5mnpzVMYQ",
      "created_at": "2023-09-27T13:43:18Z",
      "customer_ref": "arch_cust_023",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "26400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PmoTwh7fxaff",
      "device_fingerprint": "dev_arch_E4HACHKVBNrz",
      "observed_lat": "48.30701",
      "observed_lon": "14.28595",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4QLB4D",
      "archive_payment_id": "ap_5PDQWkXneF",
      "created_at": "2023-09-27T15:28:18Z",
      "customer_ref": "arch_cust_002",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "1100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_77GLqe8CvfKx",
      "device_fingerprint": "dev_arch_AEuw9LwxfRV2",
      "observed_lat": "48.30699",
      "observed_lon": "14.28602",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-JeNG1B",
      "archive_payment_id": "ap_2FfAKhJcUc",
      "created_at": "2023-09-27T15:43:18Z",
      "customer_ref": "arch_cust_013",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "13200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DbWpAxNNt2MH",
      "device_fingerprint": "dev_arch_Uhf12ZMTQ8yg",
      "observed_lat": "47.25835",
      "observed_lon": "11.38949",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-UH3oRr",
      "archive_payment_id": "ap_PvJtm9KscS",
      "created_at": "2023-09-27T16:25:18Z",
      "customer_ref": "arch_cust_062",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HNwhZMYgkoSq",
      "device_fingerprint": "dev_arch_5BNSdSa5KNvX",
      "observed_lat": "48.14367",
      "observed_lon": "17.10997",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-fqbeEQ",
      "archive_payment_id": "ap_VJfndkd6eQ",
      "created_at": "2023-09-27T16:45:18Z",
      "customer_ref": "arch_cust_097",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "9100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_D7rbVzuUA435",
      "device_fingerprint": "dev_arch_YX25TREegPRH",
      "observed_lat": "47.25796",
      "observed_lon": "11.38925",
      "sku_summary": "Keter Deep Stack 2OO-VJU",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-BKUajL",
      "archive_payment_id": "ap_35tLm99ovj",
      "created_at": "2023-09-27T16:57:18Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "2000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_TT2ECvBy1isW",
      "device_fingerprint": "dev_arch_LgKRfVBd3t79",
      "observed_lat": "48.21918",
      "observed_lon": "16.39287",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4hhBwg",
      "archive_payment_id": "ap_QKYjBMGNYa",
      "created_at": "2023-09-27T20:29:18Z",
      "customer_ref": "arch_cust_077",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "34800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_V3YMiABsyBPv",
      "device_fingerprint": "dev_arch_Xxr4gRJv2wiD",
      "observed_lat": "48.14404",
      "observed_lon": "17.10974",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-aT86mm",
      "archive_payment_id": "ap_KevxPUkiFE",
      "created_at": "2023-09-27T20:47:18Z",
      "customer_ref": "arch_cust_096",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "31600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_BbiagRckQgJm",
      "device_fingerprint": "dev_arch_KWpt4rctRjMk",
      "observed_lat": "48.17526",
      "observed_lon": "16.33560",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-2xdYMq",
      "archive_payment_id": "ap_MUA3hMiBXF",
      "created_at": "2023-09-27T21:32:18Z",
      "customer_ref": "arch_cust_081",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "18400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_BV2x3UUmde3i",
      "device_fingerprint": "dev_arch_SuHSMjtoRdH7",
      "observed_lat": "48.17501",
      "observed_lon": "16.33529",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-DihdZG",
      "archive_payment_id": "ap_ErebAsntAi",
      "created_at": "2023-09-27T23:59:18Z",
      "customer_ref": "arch_cust_009",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_XgWgoRdvYYsp",
      "device_fingerprint": "dev_arch_TJUnW7xXowy9",
      "observed_lat": "46.05145",
      "observed_lon": "14.50533",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4S4557",
      "archive_payment_id": "ap_NGymk7vE69",
      "created_at": "2023-09-28T00:47:18Z",
      "customer_ref": "arch_cust_058",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "12400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4vyz7z8HXZRX",
      "device_fingerprint": "dev_arch_UDFBzLPcKpHY",
      "observed_lat": "46.05079",
      "observed_lon": "14.50500",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Y6bL8r",
      "archive_payment_id": "ap_FMoZhVYBjZ",
      "created_at": "2023-09-28T01:29:18Z",
      "customer_ref": "arch_cust_009",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_XgWgoRdvYYsp",
      "device_fingerprint": "dev_arch_Luy5nVXFTiiu",
      "observed_lat": "48.14361",
      "observed_lon": "17.10998",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-51gAsW",
      "archive_payment_id": "ap_QYWKGMnLKe",
      "created_at": "2023-09-28T01:41:18Z",
      "customer_ref": "arch_cust_023",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "4800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PmoTwh7fxaff",
      "device_fingerprint": "dev_arch_E4HACHKVBNrz",
      "observed_lat": "47.07326",
      "observed_lon": "15.42628",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-j5MTaD",
      "archive_payment_id": "ap_Kf4o7kebUS",
      "created_at": "2023-09-28T02:21:18Z",
      "customer_ref": "arch_cust_072",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "9400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HJpwZiHEpGMi",
      "device_fingerprint": "dev_arch_SfnQ5dgBxmSy",
      "observed_lat": "48.14417",
      "observed_lon": "17.10996",
      "sku_summary": "Festool Modular CTL XPW-76I",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-bdo1gq",
      "archive_payment_id": "ap_CjrXED2NZV",
      "created_at": "2023-09-28T03:23:18Z",
      "customer_ref": "arch_cust_096",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "10500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_BbiagRckQgJm",
      "device_fingerprint": "dev_arch_V1z5jtqSMxmy",
      "observed_lat": "48.17500",
      "observed_lon": "16.33565",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-LbPaFz",
      "archive_payment_id": "ap_P9BUycvNmP",
      "created_at": "2023-09-28T03:33:18Z",
      "customer_ref": "arch_cust_004",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "9100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBFwJhFPWWRd",
      "device_fingerprint": "dev_arch_Ee8JXBMHiFgt",
      "observed_lat": "46.05119",
      "observed_lon": "14.50493",
      "sku_summary": "Keter Deep Stack 2OO-VJU",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-595FNh",
      "archive_payment_id": "ap_TuPP3YPNNQ",
      "created_at": "2023-09-28T03:53:18Z",
      "customer_ref": "arch_cust_005",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "28000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_6ZcViyN9XB58",
      "device_fingerprint": "dev_arch_2282QLgsKMmj",
      "observed_lat": "49.20440",
      "observed_lon": "16.59377",
      "sku_summary": "Schneider Electric Heavy Duty Merten 214-ZHY",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-GE8mCN",
      "archive_payment_id": "ap_6Dbzr4jUC1",
      "created_at": "2023-09-28T05:35:18Z",
      "customer_ref": "arch_cust_041",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "2200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FbgnsTdDSGAQ",
      "device_fingerprint": "dev_arch_WmVB68vSbqGQ",
      "observed_lat": "48.17490",
      "observed_lon": "16.33549",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-6JHxu1",
      "archive_payment_id": "ap_M1fSVMRNyi",
      "created_at": "2023-09-28T08:21:18Z",
      "customer_ref": "arch_cust_004",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HYr3i4iWDNUw",
      "device_fingerprint": "dev_arch_3PT3yX6zWjdK",
      "observed_lat": "47.07374",
      "observed_lon": "15.42568",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-A9DqJ7",
      "archive_payment_id": "ap_FfHwf5eAzR",
      "created_at": "2023-09-28T08:53:18Z",
      "customer_ref": "arch_cust_013",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "6200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DbWpAxNNt2MH",
      "device_fingerprint": "dev_arch_RdWWY2erUYDd",
      "observed_lat": "47.25849",
      "observed_lon": "11.38972",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4ZcSuy",
      "archive_payment_id": "ap_PnnBdViMKz",
      "created_at": "2023-09-28T11:05:18Z",
      "customer_ref": "arch_cust_066",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "13200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DaAmHyxxu9s5",
      "device_fingerprint": "dev_arch_MyxmJ1AyuEM4",
      "observed_lat": "48.21930",
      "observed_lon": "16.39251",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-JRMGoL",
      "archive_payment_id": "ap_P9msYXeoCS",
      "created_at": "2023-09-28T11:27:18Z",
      "customer_ref": "arch_cust_043",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "7000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_RQGP5zsdWYHb",
      "device_fingerprint": "dev_arch_96eg6Dx676qC",
      "observed_lat": "49.20492",
      "observed_lon": "16.59338",
      "sku_summary": "3M Ventilated SecureFit 2CE-B35",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-JMJCic",
      "archive_payment_id": "ap_5mcPLMJzQo",
      "created_at": "2023-09-28T11:49:18Z",
      "customer_ref": "arch_cust_088",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "60800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_WkDyiv74j8LM",
      "device_fingerprint": "dev_arch_VEELjBCfXo8D",
      "observed_lat": "47.06584",
      "observed_lon": "15.44321",
      "sku_summary": "Makita Workshop DDF OIE-YYP",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-ZwFoNE",
      "archive_payment_id": "ap_YbjaRWhKEs",
      "created_at": "2023-09-28T13:03:18Z",
      "customer_ref": "arch_cust_037",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "5400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PtNyp5staTmi",
      "device_fingerprint": "dev_arch_JhBXHqkzqSEg",
      "observed_lat": "47.06540",
      "observed_lon": "15.44312",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-3Dfhey",
      "archive_payment_id": "ap_BRLFY8XBKx",
      "created_at": "2023-09-28T13:35:18Z",
      "customer_ref": "arch_cust_070",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "1200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DvL8G87Rg6WL",
      "device_fingerprint": "dev_arch_NvWAAoqgvseS",
      "observed_lat": "47.25815",
      "observed_lon": "11.38960",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-3GTGMk",
      "archive_payment_id": "ap_S81K7dAaqS",
      "created_at": "2023-09-28T14:29:18Z",
      "customer_ref": "arch_cust_020",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_WKg8rP91zGS4",
      "device_fingerprint": "dev_arch_3opjjpt2v1Cc",
      "observed_lat": "47.06526",
      "observed_lon": "15.44297",
      "sku_summary": "3M Ventilated SecureFit 2CE-B35",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Dq3Ghg",
      "archive_payment_id": "ap_92DqmPew5p",
      "created_at": "2023-09-28T15:53:18Z",
      "customer_ref": "arch_cust_046",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "27900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Src9Juni2HH4",
      "device_fingerprint": "dev_arch_9btLcLpfqxef",
      "observed_lat": "47.25830",
      "observed_lon": "11.38956",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-hvRcJZ",
      "archive_payment_id": "ap_839uv55G7v",
      "created_at": "2023-09-28T18:13:18Z",
      "customer_ref": "arch_cust_100",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "2500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_X1SBgopfRBMF",
      "device_fingerprint": "dev_arch_HCenKmjyfArt",
      "observed_lat": "48.17530",
      "observed_lon": "16.33562",
      "sku_summary": "Portwest PW3 DX 3TU-ST2",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-KJsZ6s",
      "archive_payment_id": "ap_2x9ZsLyyNd",
      "created_at": "2023-09-28T20:53:18Z",
      "customer_ref": "arch_cust_039",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "6600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_MMHWG7JscWfX",
      "device_fingerprint": "dev_arch_4fzb1TXrCt2Q",
      "observed_lat": "47.07334",
      "observed_lon": "15.42604",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-FY3NXr",
      "archive_payment_id": "ap_CuknJ1tFYV",
      "created_at": "2023-09-29T00:05:18Z",
      "customer_ref": "arch_cust_087",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "2200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_C1eeDnceDS2M",
      "device_fingerprint": "dev_arch_75FvWayms4dK",
      "observed_lat": "49.20490",
      "observed_lon": "16.59328",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-VjLt1N",
      "archive_payment_id": "ap_43yXQq79hJ",
      "created_at": "2023-09-29T01:53:18Z",
      "customer_ref": "arch_cust_042",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "72000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PC6Nnjhi456v",
      "device_fingerprint": "dev_arch_34ZxgmLBHFBp",
      "observed_lat": "47.25856",
      "observed_lon": "11.38917",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Mydua5",
      "archive_payment_id": "ap_Tq3AeWWgNc",
      "created_at": "2023-09-29T06:05:18Z",
      "customer_ref": "arch_cust_009",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Bu9BySMuG9gf",
      "device_fingerprint": "dev_arch_Luy5nVXFTiiu",
      "observed_lat": "48.17527",
      "observed_lon": "16.33515",
      "sku_summary": "3M Ventilated SecureFit 2CE-B35",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-CwaehX",
      "archive_payment_id": "ap_8mMKbGCVMH",
      "created_at": "2023-09-29T06:23:18Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "17200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UP7B6nBg4VdX",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "47.25823",
      "observed_lon": "11.38923",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-HJGQTA",
      "archive_payment_id": "ap_9tLiR2jxTq",
      "created_at": "2023-09-29T10:11:18Z",
      "customer_ref": "arch_cust_098",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "27900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_GTj3VNwdFkJw",
      "device_fingerprint": "dev_arch_RnL6wxD1RbiW",
      "observed_lat": "47.06581",
      "observed_lon": "15.44303",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-YCZJkD",
      "archive_payment_id": "ap_QsSontu2M2",
      "created_at": "2023-09-29T10:53:18Z",
      "customer_ref": "arch_cust_040",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "8400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_G2R6GDPuycsf",
      "device_fingerprint": "dev_arch_FhrB72kNbx62",
      "observed_lat": "46.05113",
      "observed_lon": "14.50511",
      "sku_summary": "Mobil All Season Super 1ZE-TCR",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-Hn1rJs",
      "archive_payment_id": "ap_Q28StbciyE",
      "created_at": "2023-09-29T12:29:18Z",
      "customer_ref": "arch_cust_041",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "39600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_U6s3qPtDaWRb",
      "device_fingerprint": "dev_arch_M4h5Zxwgj2Rk",
      "observed_lat": "47.25843",
      "observed_lon": "11.38937",
      "sku_summary": "Holzmann Compact D 327-RR0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-7aXe65",
      "archive_payment_id": "ap_B8cHucsmHM",
      "created_at": "2023-09-29T12:48:18Z",
      "customer_ref": "arch_cust_055",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "8800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_ARPL5rSztyX5",
      "device_fingerprint": "dev_arch_ETdaKwaTyqiC",
      "observed_lat": "48.30680",
      "observed_lon": "14.28561",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-51JfT4",
      "archive_payment_id": "ap_6mpfyskLyj",
      "created_at": "2023-09-29T12:51:18Z",
      "customer_ref": "arch_cust_049",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "18200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3zQRgM9vRAr5",
      "device_fingerprint": "dev_arch_V8NrLaPjLqoY",
      "observed_lat": "48.17467",
      "observed_lon": "16.33544",
      "sku_summary": "Keter Deep Stack 2OO-VJU",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-H3rv9S",
      "archive_payment_id": "ap_FsPnztiC5E",
      "created_at": "2023-09-29T13:01:18Z",
      "customer_ref": "arch_cust_095",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_5sPq7CWKujxY",
      "device_fingerprint": "dev_arch_UVJAxm1xL9Fb",
      "observed_lat": "46.05080",
      "observed_lon": "14.50480",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-4yXLcd",
      "archive_payment_id": "ap_Adf63zyrat",
      "created_at": "2023-09-29T15:08:18Z",
      "customer_ref": "arch_cust_038",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "12000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HHgoUpE5Qd97",
      "device_fingerprint": "dev_arch_5bsH9Q9JN9Sh",
      "observed_lat": "48.30683",
      "observed_lon": "14.28561",
      "sku_summary": "Gorilla Crystal Grip 2ZQ-D83",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-gpgyGN",
      "archive_payment_id": "ap_HVx5G12tUb",
      "created_at": "2023-09-29T15:25:18Z",
      "customer_ref": "arch_cust_095",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "10500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_5sPq7CWKujxY",
      "device_fingerprint": "dev_arch_UVJAxm1xL9Fb",
      "observed_lat": "48.17485",
      "observed_lon": "16.33566",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-LSxS2h",
      "archive_payment_id": "ap_5gKiSZNr2c",
      "created_at": "2023-09-29T20:38:18Z",
      "customer_ref": "arch_cust_002",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "16800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_77GLqe8CvfKx",
      "device_fingerprint": "dev_arch_7RphsRGKJgRa",
      "observed_lat": "47.81293",
      "observed_lon": "13.04562",
      "sku_summary": "Mobil All Season Super 1ZE-TCR",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-3CHkbL",
      "archive_payment_id": "ap_LsGLGyWf2a",
      "created_at": "2023-09-29T22:53:18Z",
      "customer_ref": "arch_cust_014",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "19800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_YDUSxEdVrta8",
      "device_fingerprint": "dev_arch_EQTZH6pZYgmw",
      "observed_lat": "48.14420",
      "observed_lon": "17.10986",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-D2Z7bR",
      "archive_payment_id": "ap_AYXad6gjmJ",
      "created_at": "2023-09-29T23:49:18Z",
      "customer_ref": "arch_cust_061",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "5200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_GdB8s2dVhQUt",
      "device_fingerprint": "dev_arch_NaMEpwGQgu6D",
      "observed_lat": "48.30713",
      "observed_lon": "14.28580",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-BETBvK",
      "archive_payment_id": "ap_VyNsAmusmk",
      "created_at": "2023-09-30T01:52:18Z",
      "customer_ref": "arch_cust_023",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "1400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PmoTwh7fxaff",
      "device_fingerprint": "dev_arch_8riZYssQZK6n",
      "observed_lat": "47.06549",
      "observed_lon": "15.44299",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-deLU2A",
      "archive_payment_id": "ap_XmznJaS4Ra",
      "created_at": "2023-09-30T02:02:18Z",
      "customer_ref": "arch_cust_080",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "68400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Qx63X7QUvERz",
      "device_fingerprint": "dev_arch_SFM3mKsLF3Rv",
      "observed_lat": "48.30680",
      "observed_lon": "14.28546",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-JpZrDT",
      "archive_payment_id": "ap_PGRvxRf67a",
      "created_at": "2023-09-30T06:49:18Z",
      "customer_ref": "arch_cust_041",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "21600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FbgnsTdDSGAQ",
      "device_fingerprint": "dev_arch_M4h5Zxwgj2Rk",
      "observed_lat": "48.21912",
      "observed_lon": "16.39262",
      "sku_summary": "Viega Professional Sanpress 2OG-ENN",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-Hmoc7y",
      "archive_payment_id": "ap_LoKxBGRpVW",
      "created_at": "2023-09-30T10:50:18Z",
      "customer_ref": "arch_cust_025",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "29400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_GhaJ5HoK2h6p",
      "device_fingerprint": "dev_arch_KyRGvesLzmKp",
      "observed_lat": "49.20436",
      "observed_lon": "16.59381",
      "sku_summary": "Festool Modular CTL XPW-76I",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-QMWoGN",
      "archive_payment_id": "ap_H671CpEUhd",
      "created_at": "2023-09-30T12:27:18Z",
      "customer_ref": "arch_cust_018",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "4400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DsE6dLbdwbVK",
      "device_fingerprint": "dev_arch_Xq8ZbfqEzyjs",
      "observed_lat": "46.05086",
      "observed_lon": "14.50495",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-J4ixRQ",
      "archive_payment_id": "ap_SNSTDPsTUL",
      "created_at": "2023-09-30T14:12:18Z",
      "customer_ref": "arch_cust_062",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "5500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HNwhZMYgkoSq",
      "device_fingerprint": "dev_arch_PYb5p8ZieZ1U",
      "observed_lat": "47.06539",
      "observed_lon": "15.44323",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-NFtz2Q",
      "archive_payment_id": "ap_F98k6ga7UQ",
      "created_at": "2023-09-30T19:11:18Z",
      "customer_ref": "arch_cust_048",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "19200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FJbhxTSPrUpW",
      "device_fingerprint": "dev_arch_AsTnfn7cNiPM",
      "observed_lat": "47.25841",
      "observed_lon": "11.38957",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-bDcFFW",
      "archive_payment_id": "ap_HVkMj261jc",
      "created_at": "2023-09-30T20:08:18Z",
      "customer_ref": "arch_cust_030",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "4000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FaULui3c5iof",
      "device_fingerprint": "dev_arch_UR5ZVyasSJPD",
      "observed_lat": "48.14360",
      "observed_lon": "17.10988",
      "sku_summary": "Viega Professional Sanpress 2OG-ENN",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-RFAJ47",
      "archive_payment_id": "ap_8VuJmgX2CH",
      "created_at": "2023-10-01T00:47:18Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "96000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBa69CfYiRvE",
      "device_fingerprint": "dev_arch_HBumcv529yY2",
      "observed_lat": "48.21878",
      "observed_lon": "16.39285",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-DfS1Kn",
      "archive_payment_id": "ap_rZbUEjLEWV",
      "created_at": "2023-10-01T05:06:18Z",
      "customer_ref": "arch_cust_022",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9xLTnV3RB19i",
      "device_fingerprint": "dev_arch_PM2A7EwbYXk4",
      "observed_lat": "48.30697",
      "observed_lon": "14.28559",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-KLuWDj",
      "archive_payment_id": "ap_L7aDVYEYDe",
      "created_at": "2023-10-01T06:07:18Z",
      "customer_ref": "arch_cust_046",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "18200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_64RPiAemfN2x",
      "device_fingerprint": "dev_arch_9btLcLpfqxef",
      "observed_lat": "48.17471",
      "observed_lon": "16.33579",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-JAKywr",
      "archive_payment_id": "ap_9F2DZJKNJC",
      "created_at": "2023-10-01T13:13:18Z",
      "customer_ref": "arch_cust_058",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "4200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4vyz7z8HXZRX",
      "device_fingerprint": "dev_arch_UDFBzLPcKpHY",
      "observed_lat": "47.25817",
      "observed_lon": "11.38942",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-FZMpHF",
      "archive_payment_id": "ap_5P3EnxkikB",
      "created_at": "2023-10-01T18:18:18Z",
      "customer_ref": "arch_cust_068",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "9000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_43Sqb4C1wMV7",
      "device_fingerprint": "dev_arch_685Jk4W3GbUX",
      "observed_lat": "47.07350",
      "observed_lon": "15.42593",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-Z6yguc",
      "archive_payment_id": "ap_RYqgQjx9n4",
      "created_at": "2023-10-01T19:44:18Z",
      "customer_ref": "arch_cust_022",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9xLTnV3RB19i",
      "device_fingerprint": "dev_arch_PM2A7EwbYXk4",
      "observed_lat": "48.30697",
      "observed_lon": "14.28567",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-gqUxyT",
      "archive_payment_id": "ap_QtNPXVgsMV",
      "created_at": "2023-10-01T20:53:18Z",
      "customer_ref": "arch_cust_042",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "69900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CXG78ypJYWTt",
      "device_fingerprint": "dev_arch_TyutCGfax9hu",
      "observed_lat": "47.06521",
      "observed_lon": "15.44309",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Wi885d",
      "archive_payment_id": "ap_UjriMeYEsf",
      "created_at": "2023-10-01T21:33:18Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "7600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBa69CfYiRvE",
      "device_fingerprint": "dev_arch_HBumcv529yY2",
      "observed_lat": "48.17509",
      "observed_lon": "16.33537",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-jeW3Fn",
      "archive_payment_id": "ap_4Z1nLGnLVK",
      "created_at": "2023-10-01T21:47:18Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBa69CfYiRvE",
      "device_fingerprint": "dev_arch_HBumcv529yY2",
      "observed_lat": "49.20432",
      "observed_lon": "16.59344",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-bnW4BG",
      "archive_payment_id": "ap_PUGkQCixCL",
      "created_at": "2023-10-02T07:29:18Z",
      "customer_ref": "arch_cust_007",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "8000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_YAdeMq2uacce",
      "device_fingerprint": "dev_arch_WxCi9Vd56WGs",
      "observed_lat": "48.30702",
      "observed_lon": "14.28591",
      "sku_summary": "Bahco Workshop BAH 3VZ-SPH",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-AxHSJ7",
      "archive_payment_id": "ap_Xt6MTzg4ni",
      "created_at": "2023-10-02T11:51:18Z",
      "customer_ref": "arch_cust_033",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "4400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_PZXNsFhoLURA",
      "device_fingerprint": "dev_arch_PUaPTkYgPBYh",
      "observed_lat": "47.81335",
      "observed_lon": "13.04611",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-2Gd8Rf",
      "archive_payment_id": "ap_NqMLTSxhRe",
      "created_at": "2023-10-02T12:25:18Z",
      "customer_ref": "arch_cust_027",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "9300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Eu9M8rGj1P4x",
      "device_fingerprint": "dev_arch_SPcfNFpgy4Yi",
      "observed_lat": "47.25795",
      "observed_lon": "11.38919",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-UkR2QU",
      "archive_payment_id": "ap_W9vtTf41AT",
      "created_at": "2023-10-02T14:38:18Z",
      "customer_ref": "arch_cust_075",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "9500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9XjhwYy5fNoU",
      "device_fingerprint": "dev_arch_23xtqP7kN4Tz",
      "observed_lat": "48.14355",
      "observed_lon": "17.11004",
      "sku_summary": "Mobil All Season Super 1ZE-TCR",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-TYziUQ",
      "archive_payment_id": "ap_KDUemBuPm7",
      "created_at": "2023-10-02T15:47:18Z",
      "customer_ref": "arch_cust_051",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "57900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HCfmq8xgbEDB",
      "device_fingerprint": "dev_arch_YBjF8WwLU6Zc",
      "observed_lat": "47.07377",
      "observed_lon": "15.42629",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-jNehEF",
      "archive_payment_id": "ap_VvrvjXSsRF",
      "created_at": "2023-10-03T00:23:18Z",
      "customer_ref": "arch_cust_069",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "27900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_BdaKZ2Doap5q",
      "device_fingerprint": "dev_arch_7A2uNtu5JKCA",
      "observed_lat": "47.07375",
      "observed_lon": "15.42571",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-bgfZJo",
      "archive_payment_id": "ap_KoPK9V8L4F",
      "created_at": "2023-10-03T01:01:18Z",
      "customer_ref": "arch_cust_012",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CaSshFDM6Ztt",
      "device_fingerprint": "dev_arch_Pwg6TzyF798p",
      "observed_lat": "48.14389",
      "observed_lon": "17.10993",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-jKSju9",
      "archive_payment_id": "ap_WV87WS1rEQ",
      "created_at": "2023-10-03T03:28:18Z",
      "customer_ref": "arch_cust_037",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "48000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Ch1b94sHbiDL",
      "device_fingerprint": "dev_arch_PXmRZRxrde7j",
      "observed_lat": "47.07341",
      "observed_lon": "15.42606",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-c3ayq2",
      "archive_payment_id": "ap_5aLNzcWaSX",
      "created_at": "2023-10-03T08:47:18Z",
      "customer_ref": "arch_cust_017",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "7000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CVja1xEZhLS4",
      "device_fingerprint": "dev_arch_Ajb5hXLa4bJ6",
      "observed_lat": "47.06569",
      "observed_lon": "15.44342",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-gvp9eq",
      "archive_payment_id": "ap_JkNuB3oM5M",
      "created_at": "2023-10-03T12:38:18Z",
      "customer_ref": "arch_cust_069",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "241400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_BdaKZ2Doap5q",
      "device_fingerprint": "dev_arch_UWjCMf87MrNU",
      "observed_lat": "48.14380",
      "observed_lon": "17.10987",
      "sku_summary": "Bosch Bench IXO 3JP-JOU",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-eTKE6Z",
      "archive_payment_id": "ap_VjzcqJHCHy",
      "created_at": "2023-10-03T16:49:18Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "15800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "46.05135",
      "observed_lon": "14.50487",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-jNjL5J",
      "archive_payment_id": "ap_EDvgkm1gbg",
      "created_at": "2023-10-03T17:20:18Z",
      "customer_ref": "arch_cust_061",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "19800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SdLTi7mczi3o",
      "device_fingerprint": "dev_arch_NaMEpwGQgu6D",
      "observed_lat": "46.05140",
      "observed_lon": "14.50536",
      "sku_summary": "Holzmann Compact D 327-RR0",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-C4bPJg",
      "archive_payment_id": "ap_HPf3KHEfoZ",
      "created_at": "2023-10-03T19:03:18Z",
      "customer_ref": "arch_cust_039",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "26400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_EoRfcwEmCwX4",
      "device_fingerprint": "dev_arch_4fzb1TXrCt2Q",
      "observed_lat": "47.06551",
      "observed_lon": "15.44299",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-VpK5RG",
      "archive_payment_id": "ap_RsDwXtaCGP",
      "created_at": "2023-10-04T04:37:18Z",
      "customer_ref": "arch_cust_027",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "6600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_RPGvMN3E8uZ7",
      "device_fingerprint": "dev_arch_N4N6m54HdJFU",
      "observed_lat": "49.20482",
      "observed_lon": "16.59369",
      "sku_summary": "Mascot Advanced ACC 35W-IIS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Nr22Ap",
      "archive_payment_id": "ap_8qJ6WK3JP5",
      "created_at": "2023-10-04T05:21:18Z",
      "customer_ref": "arch_cust_044",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3R4eVPfEmq1e",
      "device_fingerprint": "dev_arch_XosPJfG3jwDF",
      "observed_lat": "47.06526",
      "observed_lon": "15.44341",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-cDufEs",
      "archive_payment_id": "ap_RESpCa4muK",
      "created_at": "2023-10-04T08:57:18Z",
      "customer_ref": "arch_cust_055",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "36000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3Kek8TcJjw21",
      "device_fingerprint": "dev_arch_ETdaKwaTyqiC",
      "observed_lat": "49.20483",
      "observed_lon": "16.59331",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-TzQVYS",
      "archive_payment_id": "ap_SGM3i6yc2W",
      "created_at": "2023-10-04T16:38:18Z",
      "customer_ref": "arch_cust_084",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "6600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_6H4UsPs62oAk",
      "device_fingerprint": "dev_arch_BezF59zEt1pn",
      "observed_lat": "46.05082",
      "observed_lon": "14.50500",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-XeKeNz",
      "archive_payment_id": "ap_Nyd72dcRov",
      "created_at": "2023-10-05T04:29:18Z",
      "customer_ref": "arch_cust_085",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_68i87hNadVRZ",
      "device_fingerprint": "dev_arch_Br8qE7EXDFvJ",
      "observed_lat": "48.14411",
      "observed_lon": "17.10984",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-E74eH3",
      "archive_payment_id": "ap_G6EoFNCLhV",
      "created_at": "2023-10-06T07:44:18Z",
      "customer_ref": "arch_cust_015",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "52800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_WcURV3jQESWA",
      "device_fingerprint": "dev_arch_VRbGfosS4wnQ",
      "observed_lat": "47.06572",
      "observed_lon": "15.44308",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-PYcbFo",
      "archive_payment_id": "ap_GsTCwodYfe",
      "created_at": "2023-10-07T05:33:18Z",
      "customer_ref": "arch_cust_020",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "2700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_WKg8rP91zGS4",
      "device_fingerprint": "dev_arch_3opjjpt2v1Cc",
      "observed_lat": "47.25832",
      "observed_lon": "11.38932",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-8Bi5dr",
      "archive_payment_id": "ap_RsthNaW6WM",
      "created_at": "2023-10-08T02:53:18Z",
      "customer_ref": "arch_cust_072",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "2800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HJpwZiHEpGMi",
      "device_fingerprint": "dev_arch_Jy5hVRoUuPNS",
      "observed_lat": "48.21919",
      "observed_lon": "16.39255",
      "sku_summary": "Gorilla Crystal Grip 2ZQ-D83",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-a8inLV",
      "archive_payment_id": "ap_14wrmVL4mX",
      "created_at": "2023-10-08T03:01:03Z",
      "customer_ref": "arch_cust_072",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "4800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HJpwZiHEpGMi",
      "device_fingerprint": "dev_arch_WaW5Ee6uyBt4",
      "observed_lat": "47.81353",
      "observed_lon": "13.04586",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-FbqUUD",
      "archive_payment_id": "ap_JVRcq7e8qF",
      "created_at": "2023-10-08T03:10:18Z",
      "customer_ref": "arch_cust_077",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "12400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_V3YMiABsyBPv",
      "device_fingerprint": "dev_arch_HBXhVGCaxFb5",
      "observed_lat": "49.20492",
      "observed_lon": "16.59338",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-KzPiH3",
      "archive_payment_id": "ap_FMig84fJn9",
      "created_at": "2023-10-08T03:15:26Z",
      "customer_ref": "arch_cust_077",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "9600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_V3YMiABsyBPv",
      "device_fingerprint": "dev_arch_DvpNBNxsVWjv",
      "observed_lat": "46.05116",
      "observed_lon": "14.50510",
      "sku_summary": "Geberit Mapress Silent IC5-GU6",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-MEbLC9",
      "archive_payment_id": "ap_RMpKrJGDZM",
      "created_at": "2023-10-08T03:53:18Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "8800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3B85cUTffYiw",
      "device_fingerprint": "dev_arch_CCJUWDMnQENB",
      "observed_lat": "48.21876",
      "observed_lon": "16.39230",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-apeKg7",
      "archive_payment_id": "ap_4BHDcG39R2",
      "created_at": "2023-10-08T04:00:46Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "2000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_3B85cUTffYiw",
      "device_fingerprint": "dev_arch_QZatxcMpQDtV",
      "observed_lat": "47.25827",
      "observed_lon": "11.38975",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-KzKRkf",
      "archive_payment_id": "ap_2VD8AuGQCE",
      "created_at": "2023-10-08T04:05:18Z",
      "customer_ref": "arch_cust_059",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "4000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Twcrh4gmz33f",
      "device_fingerprint": "dev_arch_H9W19c7rvBAL",
      "observed_lat": "49.20454",
      "observed_lon": "16.59352",
      "sku_summary": "Helios Professional Helios 29A-FTE",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-c54YzR",
      "archive_payment_id": "ap_SPhsF8yLCn",
      "created_at": "2023-10-08T04:07:57Z",
      "customer_ref": "arch_cust_059",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "18200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Twcrh4gmz33f",
      "device_fingerprint": "dev_arch_WwW94rB1eHGN",
      "observed_lat": "47.25837",
      "observed_lon": "11.38931",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-7SVeiD",
      "archive_payment_id": "ap_Ke5WPDBULR",
      "created_at": "2023-10-08T04:33:18Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "4400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBa69CfYiRvE",
      "device_fingerprint": "dev_arch_qCZM55gkn8ff",
      "observed_lat": "48.21871",
      "observed_lon": "16.39237",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-KJXqwy",
      "archive_payment_id": "ap_JucSfpZDWz",
      "created_at": "2023-10-08T04:35:44Z",
      "customer_ref": "arch_cust_028",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "247000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HBa69CfYiRvE",
      "device_fingerprint": "dev_arch_3JefViWRrXEk",
      "observed_lat": "47.81321",
      "observed_lon": "13.04606",
      "sku_summary": "Makita Workshop DDF OIE-YYP",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-8XxvxB",
      "archive_payment_id": "ap_P3w2ybqnAr",
      "created_at": "2023-10-08T07:58:18Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "2600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "48.14373",
      "observed_lon": "17.11002",
      "sku_summary": "Portwest PW3 DX 3TU-ST2",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-Bhpawx",
      "archive_payment_id": "ap_5eb3qSgWTo",
      "created_at": "2023-10-08T12:19:18Z",
      "customer_ref": "arch_cust_009",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "57900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Bu9BySMuG9gf",
      "device_fingerprint": "dev_arch_Luy5nVXFTiiu",
      "observed_lat": "47.81305",
      "observed_lon": "13.04581",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Fceajx",
      "archive_payment_id": "ap_F9T2ejwPZs",
      "created_at": "2023-10-09T02:53:18Z",
      "customer_ref": "arch_cust_021",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "2400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_85h2Y2PVokbL",
      "device_fingerprint": "dev_arch_RtBE5VxP1qmi",
      "observed_lat": "48.30657",
      "observed_lon": "14.28580",
      "sku_summary": "Fischer SX SX 7UY-G03",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-A8K2Md",
      "archive_payment_id": "ap_G5vB5BiHnL",
      "created_at": "2023-10-09T02:56:18Z",
      "customer_ref": "arch_cust_021",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "6200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_85h2Y2PVokbL",
      "device_fingerprint": "dev_arch_RtBE5VxP1qmi",
      "observed_lat": "46.05145",
      "observed_lon": "14.50482",
      "sku_summary": "Engelbert Strauss e.s.vision e.s. 150-ZC6",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-FZK91x",
      "archive_payment_id": "ap_PZQrEpBjeH",
      "created_at": "2023-10-09T03:28:18Z",
      "customer_ref": "arch_cust_080",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CzWAXasb7zr1",
      "device_fingerprint": "dev_arch_25Q9GCWjJ7Dq",
      "observed_lat": "47.25849",
      "observed_lon": "11.38913",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-ZVRtcq",
      "archive_payment_id": "ap_XDL4uTsrqu",
      "created_at": "2023-10-09T03:35:18Z",
      "customer_ref": "arch_cust_080",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "14000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CzWAXasb7zr1",
      "device_fingerprint": "dev_arch_25Q9GCWjJ7Dq",
      "observed_lat": "47.07323",
      "observed_lon": "15.42628",
      "sku_summary": "Schneider Electric Heavy Duty Merten 214-ZHY",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-CmJyGH",
      "archive_payment_id": "ap_XZaw1ecmgJ",
      "created_at": "2023-10-10T15:48:35Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "46.05089",
      "observed_lon": "14.50493",
      "sku_summary": "Bahco Workshop BAH 3VZ-SPH",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-U39bcx",
      "archive_payment_id": "ap_WswpwC3h4D",
      "created_at": "2023-10-11T15:58:02Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "8400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "46.05091",
      "observed_lon": "14.50505",
      "sku_summary": "Mobil All Season Super 1ZE-TCR",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-JQZFM6",
      "archive_payment_id": "ap_4GCmJ6dhBG",
      "created_at": "2023-10-12T12:07:28Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "49.20426",
      "observed_lon": "16.59358",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-skhb8G",
      "archive_payment_id": "ap_DxeehTfCWe",
      "created_at": "2023-10-13T15:25:55Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "9000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "47.25800",
      "observed_lon": "11.38915",
      "sku_summary": "Viega Professional Sanpress 2OG-ENN",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-Cq9nm4",
      "archive_payment_id": "ap_95Res48yaW",
      "created_at": "2023-10-14T16:56:39Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "1400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "47.06571",
      "observed_lon": "15.44275",
      "sku_summary": "Sonax Premium Gloss 304-ZK0",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-EAqgQU",
      "archive_payment_id": "ap_7BePVsAy2b",
      "created_at": "2023-10-15T15:08:06Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "17200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "48.30656",
      "observed_lon": "14.28586",
      "sku_summary": "Bosch Compact PKS 375-EOK",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-cAMKFG",
      "archive_payment_id": "ap_WWcx6fULT8",
      "created_at": "2023-10-16T11:09:21Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "9000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "48.14422",
      "observed_lon": "17.10945",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-9Q6QKP",
      "archive_payment_id": "ap_5v3dd7ttce",
      "created_at": "2023-10-17T12:11:40Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "57900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "49.20474",
      "observed_lon": "16.59379",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-NApA6X",
      "archive_payment_id": "ap_FCgEwhcWi3",
      "created_at": "2023-10-18T14:19:57Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "55200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_FCVwMYPWk6gF",
      "observed_lat": "47.81323",
      "observed_lon": "13.04570",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-fc7dH1",
      "archive_payment_id": "ap_N4WoYYVLqx",
      "created_at": "2023-10-19T13:14:34Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "21000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_SX9tUAQoqfwj",
      "device_fingerprint": "dev_arch_X9tCGsQ4kABh",
      "observed_lat": "46.05077",
      "observed_lon": "14.50508",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-6DAx76",
      "archive_payment_id": "ap_UXD89hCmeC",
      "created_at": "2023-10-20T01:45:29Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "48000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_7uNoAXL1pcoQ",
      "observed_lat": "48.14356",
      "observed_lon": "17.10966",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-FfgYrP",
      "archive_payment_id": "ap_7B5xGqX4GY",
      "created_at": "2023-10-20T02:02:04Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "214100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_7uNoAXL1pcoQ",
      "observed_lat": "49.20443",
      "observed_lon": "16.59331",
      "sku_summary": "Makita Workshop DDF OIE-YYP",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-b3JUxG",
      "archive_payment_id": "ap_CKSsCfErfr",
      "created_at": "2023-10-20T02:05:03Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "69900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_7uNoAXL1pcoQ",
      "observed_lat": "46.05115",
      "observed_lon": "14.50477",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-P853L2",
      "archive_payment_id": "ap_8RMZqDb7sW",
      "created_at": "2023-10-20T02:21:17Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "214100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_7uNoAXL1pcoQ",
      "observed_lat": "48.17469",
      "observed_lon": "16.33530",
      "sku_summary": "Makita Workshop DDF OIE-YYP",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-HMazkN",
      "archive_payment_id": "ap_JgiPkCyRx7",
      "created_at": "2023-10-20T02:33:28Z",
      "customer_ref": "arch_cust_076",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "183000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_UR6gvkP4fREz",
      "device_fingerprint": "dev_arch_7uNoAXL1pcoQ",
      "observed_lat": "47.07355",
      "observed_lon": "15.42591",
      "sku_summary": "Holzmann Compact D 327-RR0",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-9Y7TRZ",
      "archive_payment_id": "ap_8AJmN2Sb98",
      "created_at": "2023-10-26T10:00:18Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "2000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "47.81353",
      "observed_lon": "13.04575",
      "sku_summary": "Helios Professional Helios 29A-FTE",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-SPFS5k",
      "archive_payment_id": "ap_38c4KRCQKj",
      "created_at": "2023-10-26T10:00:32Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "8400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "48.17516",
      "observed_lon": "16.33520",
      "sku_summary": "Mobil All Season Super 1ZE-TCR",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-Vz1Yp6",
      "archive_payment_id": "ap_BketjxyjD4",
      "created_at": "2023-10-26T10:00:50Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "2500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "48.14371",
      "observed_lon": "17.10952",
      "sku_summary": "Portwest PW3 DX 3TU-ST2",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-bGvr7H",
      "archive_payment_id": "ap_xf5nAuSf4n",
      "created_at": "2023-10-26T10:01:21Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "3300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "47.81317",
      "observed_lon": "13.04574",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-Tbv2Dc",
      "archive_payment_id": "ap_BtxkAL79ot",
      "created_at": "2023-10-26T10:01:43Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "2400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "48.21901",
      "observed_lon": "16.39275",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-NJPjX8",
      "archive_payment_id": "ap_ESXykY9yDE",
      "created_at": "2023-10-26T10:01:48Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "6500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "48.14396",
      "observed_lon": "17.11004",
      "sku_summary": "Keter Deep Stack 2OO-VJU",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-VLnGku",
      "archive_payment_id": "ap_Rrc9KG1rcs",
      "created_at": "2023-10-26T10:02:10Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "7900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "48.30684",
      "observed_lon": "14.28611",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-jKd1oY",
      "archive_payment_id": "ap_3jskQ43Tfo",
      "created_at": "2023-10-26T10:02:34Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "47.81313",
      "observed_lon": "13.04583",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-UyBZ7e",
      "archive_payment_id": "ap_JdY3wVLq1d",
      "created_at": "2023-10-26T10:02:42Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "48.14419",
      "observed_lon": "17.10965",
      "sku_summary": "3M Ventilated SecureFit 2CE-B35",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-EAeuiL",
      "archive_payment_id": "ap_H8xhBbHPrT",
      "created_at": "2023-10-26T10:03:13Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "2000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "47.07381",
      "observed_lon": "15.42614",
      "sku_summary": "Heco Unix HECO 2VD-VNA",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-3apJaL",
      "archive_payment_id": "ap_2g5EgmUSe9",
      "created_at": "2023-10-26T10:03:58Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "7900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "47.25814",
      "observed_lon": "11.38950",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-82WAxz",
      "archive_payment_id": "ap_WLGPWt4F5c",
      "created_at": "2023-10-26T10:04:18Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "5200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "48.14406",
      "observed_lon": "17.10990",
      "sku_summary": "Engelbert Strauss Classic e.s. 37H-N9K",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-fGXvXQ",
      "archive_payment_id": "ap_5H7HwJUFXn",
      "created_at": "2023-10-26T10:04:54Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "5700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Vn5UUv8w8CS9",
      "device_fingerprint": "dev_arch_K9H7YJNVRSPS",
      "observed_lat": "49.20436",
      "observed_lon": "16.59393",
      "sku_summary": "Philips Professional Hue 3JS-MSN",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-FHgLUN",
      "archive_payment_id": "ap_JjsFAFgDWP",
      "created_at": "2023-10-26T10:06:22Z",
      "customer_ref": "arch_cust_065",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "7900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_LxXyJEB27FT1",
      "device_fingerprint": "dev_arch_P6gsaBB3jkVz",
      "observed_lat": "48.30715",
      "observed_lon": "14.28583",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-TukfPA",
      "archive_payment_id": "ap_DWJrdjYws2",
      "created_at": "2023-10-27T10:00:18Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "1600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_9UFWqNRkSK54",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "47.07342",
      "observed_lon": "15.42582",
      "sku_summary": "Geberit Mapress Silent IC5-GU6",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-7JpJje",
      "archive_payment_id": "ap_BA45i7qLkZ",
      "created_at": "2023-10-27T10:00:41Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "1000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_XoxzXFtBGLs7",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.30724",
      "observed_lon": "14.28551",
      "sku_summary": "Mellerud Bio MEL 233-MOB",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-GFxdWw",
      "archive_payment_id": "ap_CMitZDRZ8Q",
      "created_at": "2023-10-27T10:01:00Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "14000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_VcDcv1yyxB5M",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "49.20465",
      "observed_lon": "16.59338",
      "sku_summary": "Schneider Electric Heavy Duty Merten 214-ZHY",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-dJUm2U",
      "archive_payment_id": "ap_P2owx4zFMk",
      "created_at": "2023-10-27T10:01:06Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_CfyCGmU8n9uz",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.30673",
      "observed_lon": "14.28612",
      "sku_summary": "Bahco Workshop BAH 3VZ-SPH",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-EWjHjK",
      "archive_payment_id": "ap_WLvH8a6dEk",
      "created_at": "2023-10-27T10:01:24Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "9600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_RFkqqX3Kpnfn",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.30695",
      "observed_lon": "14.28589",
      "sku_summary": "Geberit Mapress Silent IC5-GU6",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-heFEta",
      "archive_payment_id": "ap_TK12h4vnUx",
      "created_at": "2023-10-27T10:01:43Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "9200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_ScoHNmFNfdQN",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "46.05093",
      "observed_lon": "14.50522",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-Nmiezi",
      "archive_payment_id": "ap_XW4eazkP8G",
      "created_at": "2023-10-27T10:02:31Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "4300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_8zDWttTrKmRz",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "46.05128",
      "observed_lon": "14.50536",
      "sku_summary": "Philips Professional Hue 3JS-MSN",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-CkpJTq",
      "archive_payment_id": "ap_RUn7oWs62i",
      "created_at": "2023-10-27T10:02:42Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "9100",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_F2MeMUutzS8B",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.17497",
      "observed_lon": "16.33524",
      "sku_summary": "Keter Deep Stack 2OO-VJU",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-J3rrFv",
      "archive_payment_id": "ap_D2ZXMUxsje",
      "created_at": "2023-10-27T10:02:54Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "7000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_5AmW6AhZf3SR",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.17500",
      "observed_lon": "16.33582",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-eanseK",
      "archive_payment_id": "ap_UkSaNBwXSc",
      "created_at": "2023-10-27T10:03:06Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "6200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_8VFEBvAXqyEU",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.21887",
      "observed_lon": "16.39276",
      "sku_summary": "Gardena Smart PowerMax 280-5FI",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-7xrWuM",
      "archive_payment_id": "ap_wWJXMxEYQa",
      "created_at": "2023-10-27T10:03:14Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "2800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_MhqzNEgund3M",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "47.06565",
      "observed_lon": "15.44313",
      "sku_summary": "Gorilla Crystal Grip 2ZQ-D83",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-hv9gFT",
      "archive_payment_id": "ap_CpiQnGVsWz",
      "created_at": "2023-10-27T10:03:27Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "7900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_QQR8vzPocPvK",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.17532",
      "observed_lon": "16.33561",
      "sku_summary": "Wiha VDE VDE 13X-B49",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-Hh28US",
      "archive_payment_id": "ap_4rnbS8GzN3",
      "created_at": "2023-10-27T10:03:38Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "11000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_AZWVbQkegVJG",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "48.14362",
      "observed_lon": "17.10937",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-ci2BfW",
      "archive_payment_id": "ap_YLmUnPskXy",
      "created_at": "2023-10-27T10:04:30Z",
      "customer_ref": "arch_cust_011",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "9600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4qKQAXgqMLKp",
      "device_fingerprint": "dev_arch_MWwf8xKMLpxL",
      "observed_lat": "49.20425",
      "observed_lon": "16.59329",
      "sku_summary": "Sonax Workshop XTREME 218-FC5",
      "archive_channel": "service_desk"
    },
    {
      "row_id": "AR-d3nqzP",
      "archive_payment_id": "ap_4wZs7GNFNw",
      "created_at": "2023-11-23T05:53:18Z",
      "customer_ref": "arch_cust_050",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "50400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_HsJorVUj9qi5",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "48.30705",
      "observed_lon": "14.28611",
      "sku_summary": "Ryobi Precision RLM 2KQ-R4C",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-7DnJeE",
      "archive_payment_id": "ap_QzCCXBzbxw",
      "created_at": "2023-11-23T05:56:54Z",
      "customer_ref": "arch_cust_057",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "22700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Sa7VYFi1WYAy",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "48.30690",
      "observed_lon": "14.28567",
      "sku_summary": "Geberit Mapress Silent IC5-GU6",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-YVmNNJ",
      "archive_payment_id": "ap_vkWQveL8cx",
      "created_at": "2023-11-23T06:00:30Z",
      "customer_ref": "arch_cust_064",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "65300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_G4C49gzfQkCy",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "47.07334",
      "observed_lon": "15.42586",
      "sku_summary": "Bosch Bench IXO 3JP-JOU",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-UYgiDA",
      "archive_payment_id": "ap_4Q3QQ6d6ux",
      "created_at": "2023-11-23T06:04:06Z",
      "customer_ref": "arch_cust_071",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "21600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_TEMDFmYeuhHL",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "48.30697",
      "observed_lon": "14.28575",
      "sku_summary": "Viega Professional Sanpress 2OG-ENN",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-3pNGua",
      "archive_payment_id": "ap_MqZp1coxBi",
      "created_at": "2023-11-23T06:07:42Z",
      "customer_ref": "arch_cust_078",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "48000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_QKoq1J5NQbX2",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "47.06544",
      "observed_lon": "15.44325",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-YiGah2",
      "archive_payment_id": "ap_6FVFYFT6Li",
      "created_at": "2023-11-23T06:11:18Z",
      "customer_ref": "arch_cust_085",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "26400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_7DnhCdZtTEDb",
      "device_fingerprint": "dev_arch_HiZesFhREbYh",
      "observed_lat": "49.20441",
      "observed_lon": "16.59356",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-e4jREQ",
      "archive_payment_id": "ap_8f5kPcDXf5",
      "created_at": "2023-11-24T05:53:18Z",
      "customer_ref": "arch_cust_053",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "57900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Q4Fzbca3YzFw",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "48.21880",
      "observed_lon": "16.39291",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-ek3T33",
      "archive_payment_id": "ap_LWAaKiZtZw",
      "created_at": "2023-11-24T05:56:54Z",
      "customer_ref": "arch_cust_064",
      "store_ref": "arch_store_linz_hauptplatz",
      "store_city": "Linz",
      "amount_cents": "183000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_V8oFqzpepNt6",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "48.30706",
      "observed_lon": "14.28568",
      "sku_summary": "Holzmann Compact D 327-RR0",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-bNbJbT",
      "archive_payment_id": "ap_3pKdVoqYuD",
      "created_at": "2023-11-24T06:00:30Z",
      "customer_ref": "arch_cust_075",
      "store_ref": "arch_store_bratislava_stare_mesto",
      "store_city": "Bratislava",
      "amount_cents": "22700",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_Wh8J4UtYSv71",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "48.14372",
      "observed_lon": "17.10971",
      "sku_summary": "Geberit Mapress Silent IC5-GU6",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-4bvBaW",
      "archive_payment_id": "ap_TzCy4p47Kn",
      "created_at": "2023-11-24T06:04:06Z",
      "customer_ref": "arch_cust_086",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "65300",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_7HAFr8XkPH1j",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "47.25856",
      "observed_lon": "11.38958",
      "sku_summary": "Bosch Bench IXO 3JP-JOU",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-XrKRJF",
      "archive_payment_id": "ap_FZ25zua3Cc",
      "created_at": "2023-11-24T06:07:42Z",
      "customer_ref": "arch_cust_097",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "27600",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_TbstMeHBYwws",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "49.20494",
      "observed_lon": "16.59372",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-boP9yJ",
      "archive_payment_id": "ap_zxcUsnjA9f",
      "created_at": "2023-11-24T06:11:18Z",
      "customer_ref": "arch_cust_008",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "34200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_DJT1er8G3oyQ",
      "device_fingerprint": "dev_arch_JWYVrTPvoW7V",
      "observed_lat": "47.25836",
      "observed_lon": "11.38906",
      "sku_summary": "Raaco Professional CarryLite 3CS-7A9",
      "archive_channel": "store_kiosk"
    },
    {
      "row_id": "AR-TZ8VZ9",
      "archive_payment_id": "ap_MGFhBB9RhU",
      "created_at": "2023-11-27T18:50:45Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "11000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_L5UJevi9rMnB",
      "observed_lat": "48.17485",
      "observed_lon": "16.33521",
      "sku_summary": "Sika Professional Sika 28T-UV8",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-VQp2ja",
      "archive_payment_id": "ap_Npek5u3E1j",
      "created_at": "2023-11-28T10:57:52Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "800",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_vVLmB1RVrs6k",
      "device_fingerprint": "dev_arch_L5UJevi9rMnB",
      "observed_lat": "47.07377",
      "observed_lon": "15.42575",
      "sku_summary": "Dresselhaus Outdoor Pro 1VG-P5G",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-FyF1KT",
      "archive_payment_id": "ap_Ssx9AUS6hR",
      "created_at": "2023-11-29T14:31:51Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "72000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_L5UJevi9rMnB",
      "observed_lat": "47.07316",
      "observed_lon": "15.42576",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-h5BpEF",
      "archive_payment_id": "ap_Hp1w36aoHf",
      "created_at": "2023-11-30T17:30:20Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_vienna_meidling",
      "store_city": "Vienna",
      "amount_cents": "3500",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_vVLmB1RVrs6k",
      "device_fingerprint": "dev_arch_U1zMagzCtX7J",
      "observed_lat": "48.17505",
      "observed_lon": "16.33527",
      "sku_summary": "3M Ventilated SecureFit 2CE-B35",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-3Q7pNR",
      "archive_payment_id": "ap_Du4QD8956R",
      "created_at": "2023-12-01T11:34:16Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_salzburg_elisabeth_vorstadt",
      "store_city": "Salzburg",
      "amount_cents": "18400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_U1zMagzCtX7J",
      "observed_lat": "47.81325",
      "observed_lon": "13.04598",
      "sku_summary": "Bondex Garden Classic 106-TS1",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-MMYoKy",
      "archive_payment_id": "ap_2C5Jh8FKdq",
      "created_at": "2023-12-02T10:27:37Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "9900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_vVLmB1RVrs6k",
      "device_fingerprint": "dev_arch_U1zMagzCtX7J",
      "observed_lat": "47.06568",
      "observed_lon": "15.44309",
      "sku_summary": "Bahco Comfort Grip BE 1ZR-PGS",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-A8y2rA",
      "archive_payment_id": "ap_ADc4jEKYnD",
      "created_at": "2023-12-03T16:10:23Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "6200",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_L5UJevi9rMnB",
      "observed_lat": "46.05138",
      "observed_lon": "14.50518",
      "sku_summary": "Engelbert Strauss e.s.vision e.s. 150-ZC6",
      "archive_channel": "web"
    },
    {
      "row_id": "AR-YXkXE9",
      "archive_payment_id": "ap_UYXh5tkcJp",
      "created_at": "2023-12-04T18:14:58Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_graz_lend",
      "store_city": "Graz",
      "amount_cents": "1400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_vVLmB1RVrs6k",
      "device_fingerprint": "dev_arch_L5UJevi9rMnB",
      "observed_lat": "47.07357",
      "observed_lon": "15.42634",
      "sku_summary": "Philips Professional Hue 3JS-MSN",
      "archive_channel": "store_terminal"
    },
    {
      "row_id": "AR-TLvcQE",
      "archive_payment_id": "ap_TarrbNTDoC",
      "created_at": "2023-12-05T01:01:04Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_ljubljana_center",
      "store_city": "Ljubljana",
      "amount_cents": "69900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_VyP7P72AZnS3",
      "observed_lat": "46.05101",
      "observed_lon": "14.50480",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-CGxJeC",
      "archive_payment_id": "ap_GHQNdNdqXC",
      "created_at": "2023-12-05T01:11:00Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_innsbruck_wilten",
      "store_city": "Innsbruck",
      "amount_cents": "69900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_VyP7P72AZnS3",
      "observed_lat": "47.25829",
      "observed_lon": "11.38934",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-Fhuqmw",
      "archive_payment_id": "ap_NC5ZKJsAvQ",
      "created_at": "2023-12-05T01:12:41Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_brno_veveri",
      "store_city": "Brno",
      "amount_cents": "50400",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4mYCGBCwvWb2",
      "device_fingerprint": "dev_arch_VyP7P72AZnS3",
      "observed_lat": "49.20453",
      "observed_lon": "16.59345",
      "sku_summary": "Ryobi Precision RLM 2KQ-R4C",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-R2rGdH",
      "archive_payment_id": "ap_DzuQAaJE9y",
      "created_at": "2023-12-05T01:30:42Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_vienna_praterstern",
      "store_city": "Vienna",
      "amount_cents": "57900",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_4mYCGBCwvWb2",
      "device_fingerprint": "dev_arch_VyP7P72AZnS3",
      "observed_lat": "48.21922",
      "observed_lon": "16.39231",
      "sku_summary": "Fiskars Battery X 1CD-A3X",
      "archive_channel": "mobile_app"
    },
    {
      "row_id": "AR-Cz72c2",
      "archive_payment_id": "ap_SrnRP1LoHS",
      "created_at": "2023-12-05T01:32:59Z",
      "customer_ref": "arch_cust_052",
      "store_ref": "arch_store_graz_jakomini",
      "store_city": "Graz",
      "amount_cents": "48000",
      "currency": "EUR",
      "payment_method_fingerprint": "pm_arch_FZTtVWgQgrrZ",
      "device_fingerprint": "dev_arch_VyP7P72AZnS3",
      "observed_lat": "47.06515",
      "observed_lon": "15.44313",
      "sku_summary": "Metabo Brushless BS 1OW-IK5",
      "archive_channel": "mobile_app"
    }
  ]
}
```
