# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Final submission - yes/no question → <YES> token
submit_and_exit(
    message="<YES>",
    outcome="OUTCOME_OK",
    refs=["/proc/catalog/FST-23VT61XO.json"]
)
