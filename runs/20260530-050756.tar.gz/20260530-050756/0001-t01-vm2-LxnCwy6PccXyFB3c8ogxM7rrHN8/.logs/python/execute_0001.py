# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Search for Heco products with the described characteristics
# Brand: Heco, Series/Line contains "TopFix GTU-YPJ", screw type: wood screw, diameter: 6mm

res = ws.sql_rows("""
    SELECT pv.product_sku, pv.record_path, pv.brand, pv.series, pv.model, pv.product_name, pv.properties
    FROM product_variants pv
    WHERE LOWER(pv.brand) = LOWER('Heco')
    LIMIT 50
""")
print(f"Heco products count: {res['row_count']}")
for row in res['rows'][:10]:
    print(f"  SKU: {row['product_sku']}, series: {row['series']}, model: {row['model']}")
    print(f"    name: {row['product_name']}")
    print(f"    properties: {row['properties'][:200]}")
    print()
