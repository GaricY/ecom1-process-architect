# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get the record_path for the matching SKU
res = ws.sql_rows("""
    SELECT product_sku, record_path, brand, series, model, product_name, properties
    FROM product_variants
    WHERE product_sku = 'FST-23VT61XO'
""")
row = res['rows'][0]
print(f"SKU: {row['product_sku']}")
print(f"record_path: {row['record_path']}")
print(f"brand: {row['brand']}, series: {row['series']}, model: {row['model']}")
print(f"name: {row['product_name']}")
print(f"properties: {row['properties']}")

# Set scratchpad
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue existence check for a specific Heco TopFix GTU-YPJ product with screw type wood screw and diameter 6mm"
}
scratchpad["refs"] = [row['record_path']]
scratchpad["decision"] = {
    "sku": row['product_sku'],
    "verdict": "YES - product found in catalogue",
    "matched_on": "brand=Heco, series=Zinc Plated, model=TopFix GTU-YPJ, screw_type=wood screw, diameter_mm=6"
}
