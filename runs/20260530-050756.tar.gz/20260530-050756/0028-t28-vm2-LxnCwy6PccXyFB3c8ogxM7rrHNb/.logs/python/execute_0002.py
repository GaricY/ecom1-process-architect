# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Discover /docs tree for policy updates
docs_tree = ws.tree(root="/docs", level=2)
print("docs tree:", json.dumps(docs_tree, indent=2))
