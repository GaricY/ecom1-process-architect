# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Check identity (already known: cust_013, customer)
# Step 2: Read basket_005 to check ownership and store_id
# Step 3: Discover /docs tree for policy updates
# Step 4: Get store record

# Check basket_005
basket = ws.read("/proc/baskets/basket_005.json")
basket_data = json.loads(basket["content"])
print("basket_005:", json.dumps(basket_data, indent=2))
