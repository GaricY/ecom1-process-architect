# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get store record for store_brno_veveri (public record, required in refs since request names the store)
store = ws.read("/proc/stores/store_brno_veveri.json")
store_data = json.loads(store["content"])
print("store record:", json.dumps(store_data, indent=2))
