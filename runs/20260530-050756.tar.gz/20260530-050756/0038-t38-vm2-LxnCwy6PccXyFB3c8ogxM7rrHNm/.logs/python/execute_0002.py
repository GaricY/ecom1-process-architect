# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Hard sweep family 1: Cross-actor exact identifier collisions
# Check shared payment_method_fingerprint across different customers
res_pmf = ws.sql_rows("""
SELECT payment_method_fingerprint, COUNT(DISTINCT customer_id) as cust_count, 
       COUNT(*) as payment_count,
       GROUP_CONCAT(DISTINCT customer_id) as customers
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY payment_method_fingerprint
HAVING cust_count > 1
ORDER BY cust_count DESC, payment_count DESC
""")
print("Shared PMF (cross-customer):", res_pmf["rows"][:20])
print("Count:", res_pmf["row_count"])

# Check shared device_fingerprint across different customers
res_dfp = ws.sql_rows("""
SELECT device_fingerprint, COUNT(DISTINCT customer_id) as cust_count,
       COUNT(*) as payment_count,
       GROUP_CONCAT(DISTINCT customer_id) as customers
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY device_fingerprint
HAVING cust_count > 1
ORDER BY cust_count DESC, payment_count DESC
""")
print("\nShared DFP (cross-customer):", res_dfp["rows"][:20])
print("Count:", res_dfp["row_count"])
