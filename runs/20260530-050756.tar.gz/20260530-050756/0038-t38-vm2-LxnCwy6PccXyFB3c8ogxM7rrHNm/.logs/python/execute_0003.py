# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Record max-metric for zero results on identifier collision family
# Find PMF/DFP with highest count per single customer to validate the zero
res_pmf_max = ws.sql_rows("""
SELECT payment_method_fingerprint, COUNT(DISTINCT customer_id) as cust_count, COUNT(*) as payment_count
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY payment_method_fingerprint
ORDER BY cust_count DESC, payment_count DESC
LIMIT 5
""")
print("Top PMF sharing:", res_pmf_max["rows"])

res_dfp_max = ws.sql_rows("""
SELECT device_fingerprint, COUNT(DISTINCT customer_id) as cust_count, COUNT(*) as payment_count
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY device_fingerprint
ORDER BY cust_count DESC, payment_count DESC
LIMIT 5
""")
print("Top DFP sharing:", res_dfp_max["rows"])

# Also check for duplicate baskets (same basket_id in multiple payment records)
res_dup_basket = ws.sql_rows("""
SELECT basket_id, COUNT(*) as cnt, GROUP_CONCAT(DISTINCT customer_id) as customers
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY basket_id
HAVING cnt > 1
ORDER BY cnt DESC
LIMIT 10
""")
print("Duplicate basket payments:", res_dup_basket["rows"])

# Check for identical timestamps
res_dup_ts = ws.sql_rows("""
SELECT payment_created_at, COUNT(DISTINCT customer_id) as cust_count, COUNT(*) as cnt
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY payment_created_at
HAVING cust_count > 1
ORDER BY cnt DESC
LIMIT 10
""")
print("Shared exact timestamps cross-customer:", res_dup_ts["rows"][:10])
