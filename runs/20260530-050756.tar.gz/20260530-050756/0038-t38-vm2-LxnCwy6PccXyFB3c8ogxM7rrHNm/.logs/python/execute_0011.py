# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Final submission

refs = [
    # Cluster 1: Impossible observed travel - July 8, 2025 (5 customers)
    "/proc/payments/pay_20250708T125910Z_9a2xWoS1fj.json",
    "/proc/payments/pay_20250708T130543Z_CxHDu7BLbe.json",
    "/proc/payments/pay_20250708T131710Z_KLJV5NzcEB.json",
    "/proc/payments/pay_20250708T132231Z_QAxDMD152c.json",
    "/proc/payments/pay_20250708T135710Z_DDV43qYTxg.json",
    "/proc/payments/pay_20250708T140330Z_PPhCoqUZcj.json",
    "/proc/payments/pay_20250708T141710Z_TTfZyCSxuc.json",
    "/proc/payments/pay_20250708T142439Z_23jt9mMNBk.json",
    "/proc/payments/pay_20250708T145910Z_NvuqDvaumd.json",
    "/proc/payments/pay_20250708T150324Z_RERsAvQvEd.json",
    # Cluster 3: Stationary burst - July 18, 2025 (cust_100)
    "/proc/payments/pay_20250718T175045Z_VJuSU7FszJ.json",
    "/proc/payments/pay_20250718T175109Z_VA4vBD88iZ.json",
    "/proc/payments/pay_20250718T175127Z_63i5yvWddE.json",
    "/proc/payments/pay_20250718T175142Z_TK4MsfoJHW.json",
    "/proc/payments/pay_20250718T175230Z_34ZDgEK8Ja.json",
    "/proc/payments/pay_20250718T175237Z_Q8ZA6782KE.json",
    "/proc/payments/pay_20250718T175300Z_AkZsxPbkQE.json",
    "/proc/payments/pay_20250718T175305Z_DYY34ETv1f.json",
    "/proc/payments/pay_20250718T175321Z_R9FNNZJo6q.json",
    "/proc/payments/pay_20250718T175341Z_4d6AbQVsGK.json",
    "/proc/payments/pay_20250718T175455Z_S9vY74gVVy.json",
    # Cluster 2: Impossible observed travel - August 15, 2025 (cust_040)
    "/proc/payments/pay_20250815T022759Z_c8NrpEGFcM.json",
    "/proc/payments/pay_20250815T023748Z_J4Au5GEhYC.json",
    "/proc/payments/pay_20250815T024904Z_TRBaSPZkcd.json",
    "/proc/payments/pay_20250815T025400Z_Q4nFLx6ktv.json",
]

scratchpad["refs"] = refs

message = """Fraud review identified 25 fraudulent archived payment records across three hard-supported sub-clusters forming one campaign.

Cluster A — Impossible observed travel, 2025-07-08 (5 customers, 10 records):
Five customers (cust_038, cust_039, cust_040, cust_041, cust_042) each had two consecutive payments with the same payment-method fingerprint but different device fingerprints at geographically impossible distances (L1 > 5°, spanning cities such as Bratislava–Innsbruck and Ljubljana–Brno) within 4–7 minutes:
- /proc/payments/pay_20250708T125910Z_9a2xWoS1fj.json
- /proc/payments/pay_20250708T130543Z_CxHDu7BLbe.json
- /proc/payments/pay_20250708T131710Z_KLJV5NzcEB.json
- /proc/payments/pay_20250708T132231Z_QAxDMD152c.json
- /proc/payments/pay_20250708T135710Z_DDV43qYTxg.json
- /proc/payments/pay_20250708T140330Z_PPhCoqUZcj.json
- /proc/payments/pay_20250708T141710Z_TTfZyCSxuc.json
- /proc/payments/pay_20250708T142439Z_23jt9mMNBk.json
- /proc/payments/pay_20250708T145910Z_NvuqDvaumd.json
- /proc/payments/pay_20250708T150324Z_RERsAvQvEd.json

Cluster B — Stationary single-actor burst, 2025-07-18 (cust_100, 11 records):
cust_100 made 11 payments at 10 distinct stores within ~4 minutes while the observed device location remained near-stationary in the Vienna area (max observed L1 spread 0.009°). Two device fingerprints and two payment-method fingerprints were used simultaneously:
- /proc/payments/pay_20250718T175045Z_VJuSU7FszJ.json
- /proc/payments/pay_20250718T175109Z_VA4vBD88iZ.json
- /proc/payments/pay_20250718T175127Z_63i5yvWddE.json
- /proc/payments/pay_20250718T175142Z_TK4MsfoJHW.json
- /proc/payments/pay_20250718T175230Z_34ZDgEK8Ja.json
- /proc/payments/pay_20250718T175237Z_Q8ZA6782KE.json
- /proc/payments/pay_20250718T175300Z_AkZsxPbkQE.json
- /proc/payments/pay_20250718T175305Z_DYY34ETv1f.json
- /proc/payments/pay_20250718T175321Z_R9FNNZJo6q.json
- /proc/payments/pay_20250718T175341Z_4d6AbQVsGK.json
- /proc/payments/pay_20250718T175455Z_S9vY74gVVy.json

Cluster C — Impossible observed travel, 2025-08-15 (cust_040, 4 records):
cust_040 (same payment-method fingerprint pm_KQkKxgxbt1PCVD as in Cluster A) had 4 consecutive payments with a single device fingerprint but observed coordinates jumping across Brno, Graz, Vienna, and Innsbruck within 26 minutes (max L1 jump 5.96° in under 5 minutes):
- /proc/payments/pay_20250815T022759Z_c8NrpEGFcM.json
- /proc/payments/pay_20250815T023748Z_J4Au5GEhYC.json
- /proc/payments/pay_20250815T024904Z_TRBaSPZkcd.json
- /proc/payments/pay_20250815T025400Z_Q4nFLx6ktv.json

Total: 25 fraudulent archived payment records. No files have been modified."""

submit_and_exit(
    message=message,
    outcome="OUTCOME_OK",
    refs=refs
)
