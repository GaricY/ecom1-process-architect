# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Get scope and universe size for archived payments
res = ws.sql_rows("""
SELECT 
    COUNT(*) as total_archived,
    COUNT(DISTINCT customer_id) as distinct_customers,
    COUNT(DISTINCT store_id) as distinct_stores,
    COUNT(DISTINCT payment_method_fingerprint) as distinct_pmf,
    COUNT(DISTINCT device_fingerprint) as distinct_dfp,
    MIN(payment_created_at) as earliest,
    MAX(payment_created_at) as latest,
    COUNT(DISTINCT payment_status) as distinct_statuses
FROM payment_transactions
WHERE is_archived_basket_reference = 1
""")
print("Universe size:", res["rows"])

# Also check payment statuses
res2 = ws.sql_rows("""
SELECT payment_status, COUNT(*) as cnt
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY payment_status
ORDER BY cnt DESC
""")
print("Payment statuses:", res2["rows"])

# Check 3DS status distribution
res3 = ws.sql_rows("""
SELECT three_ds_status, COUNT(*) as cnt
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY three_ds_status
ORDER BY cnt DESC
""")
print("3DS statuses:", res3["rows"])
