# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Hard sweep family 4: Stationary single-actor multi-target burst
res_burst = ws.sql_rows("""
WITH pairs AS (
  SELECT a.customer_id,
         a.payment_created_at AS start_ts,
         b.record_path,
         b.payment_created_at,
         b.store_id,
         ABS(a.observed_latitude - b.observed_latitude) + ABS(a.observed_longitude - b.observed_longitude) AS observed_l1
  FROM payment_transactions a
  JOIN payment_transactions b
    ON a.customer_id = b.customer_id
   AND b.payment_created_at >= a.payment_created_at
   AND (julianday(b.payment_created_at) - julianday(a.payment_created_at)) * 24 * 60 BETWEEN 0 AND 5
  WHERE a.is_archived_basket_reference = 1
    AND b.is_archived_basket_reference = 1
),
windows AS (
  SELECT customer_id, start_ts,
         COUNT(*) AS payment_count,
         COUNT(DISTINCT store_id) AS distinct_stores,
         MAX(observed_l1) AS observed_spread_l1
  FROM pairs
  GROUP BY customer_id, start_ts
)
SELECT *
FROM windows
WHERE distinct_stores >= 4
  AND observed_spread_l1 < 0.05
ORDER BY distinct_stores DESC, payment_count DESC, start_ts
""")
print("Burst hits (>=4 distinct stores, spread <0.05):", res_burst["row_count"])
print("Rows:", res_burst["rows"])

# Also check lower threshold to see the max metrics
res_burst_max = ws.sql_rows("""
WITH pairs AS (
  SELECT a.customer_id,
         a.payment_created_at AS start_ts,
         b.record_path,
         b.payment_created_at,
         b.store_id,
         ABS(a.observed_latitude - b.observed_latitude) + ABS(a.observed_longitude - b.observed_longitude) AS observed_l1
  FROM payment_transactions a
  JOIN payment_transactions b
    ON a.customer_id = b.customer_id
   AND b.payment_created_at >= a.payment_created_at
   AND (julianday(b.payment_created_at) - julianday(a.payment_created_at)) * 24 * 60 BETWEEN 0 AND 5
  WHERE a.is_archived_basket_reference = 1
    AND b.is_archived_basket_reference = 1
),
windows AS (
  SELECT customer_id, start_ts,
         COUNT(*) AS payment_count,
         COUNT(DISTINCT store_id) AS distinct_stores,
         MAX(observed_l1) AS observed_spread_l1
  FROM pairs
  GROUP BY customer_id, start_ts
)
SELECT MAX(distinct_stores) AS max_distinct_stores, 
       MAX(payment_count) AS max_payment_count,
       MIN(observed_spread_l1) AS min_spread
FROM windows
""")
print("\nBurst max metrics:", res_burst_max["rows"])
