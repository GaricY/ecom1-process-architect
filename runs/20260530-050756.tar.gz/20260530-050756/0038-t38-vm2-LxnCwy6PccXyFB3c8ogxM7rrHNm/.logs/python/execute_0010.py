# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Save comprehensive scratchpad
scratchpad["scope"] = {
    "predicate": "is_archived_basket_reference = 1",
    "universe_size": 1025,
    "distinct_customers": 100,
    "distinct_stores": 10,
    "distinct_pmf": 169,
    "distinct_dfp": 196,
    "date_range": "2025-06-27 to 2025-09-02"
}

scratchpad["columns_considered"] = [
    "payment_id", "record_path", "basket_id", "is_archived_basket_reference",
    "customer_id", "store_id", "payment_amount_cents", "payment_currency",
    "payment_status", "payment_created_at", "payment_method_fingerprint",
    "device_fingerprint", "observed_latitude", "observed_longitude",
    "three_ds_status", "three_ds_failure_reason", "three_ds_attempts", "three_ds_max_attempts"
]

scratchpad["hard_sweep_ledger"] = {
    "cross_actor_identifier_collision": {
        "result": "zero",
        "scope": "all 1025 archived payments",
        "actor_axis": "customer_id",
        "signal": "shared payment_method_fingerprint or device_fingerprint across different customer_ids",
        "max_metric": "max cust_count per PMF = 1 (no sharing); max cust_count per DFP = 1 (no sharing)"
    },
    "workflow_state_invariants_3ds": {
        "result": "not_applicable",
        "reason": "All 1025 archived payments have payment_status=paid and three_ds_status=NULL. No 3DS flow present in this scope."
    },
    "record_table_invariants": {
        "result": "zero",
        "scope": "all 1025 archived payments",
        "checks": [
            "payment_amount_cents vs sum(item_unit_price_cents * purchased_quantity): 0 discrepancies",
            "duplicate basket payments: 0",
            "payments without line items: 0"
        ],
        "max_metric": "max amount discrepancy = 0"
    },
    "impossible_observed_travel": {
        "result": "hard_hit",
        "scope": "all 1025 archived payments",
        "actor_axis": "customer_id",
        "time_axis": "payment_created_at",
        "coordinate_axis": "observed_latitude / observed_longitude",
        "window": "0 to 15 minutes between consecutive events per actor",
        "threshold": "observed_l1 > 2.0 (Manhattan distance in degrees)",
        "hit_count": 8,
        "affected_customers": ["cust_038", "cust_039", "cust_040", "cust_041", "cust_042"],
        "record_count": 14
    },
    "stationary_single_actor_burst": {
        "result": "hard_hit",
        "scope": "all 1025 archived payments",
        "actor_axis": "customer_id",
        "time_axis": "payment_created_at",
        "target_axis": "store_id",
        "window": "5-minute rolling sub-window",
        "thresholds": "distinct_stores >= 4 AND observed_spread_l1 < 0.05",
        "hit_count": 8,
        "affected_customer": "cust_100",
        "max_distinct_stores": 10,
        "max_payment_count": 11,
        "observed_spread": "max L1 = 0.0086 (near-stationary in Vienna area)",
        "record_count": 11
    }
}

scratchpad["hard_supported_clusters"] = {
    "cluster_1_impossible_travel_july8": {
        "hard_signal": "impossible_observed_travel",
        "customers": ["cust_038", "cust_039", "cust_040", "cust_041", "cust_042"],
        "date": "2025-07-08",
        "description": "5 customers each had consecutive payments from geographically impossible locations (different European cities) within 5-7 minutes, using the same PMF but different device fingerprints",
        "records": [
            "/proc/payments/pay_20250708T125910Z_9a2xWoS1fj.json",
            "/proc/payments/pay_20250708T130543Z_CxHDu7BLbe.json",
            "/proc/payments/pay_20250708T131710Z_KLJV5NzcEB.json",
            "/proc/payments/pay_20250708T132231Z_QAxDMD152c.json",
            "/proc/payments/pay_20250708T135710Z_DDV43qYTxg.json",
            "/proc/payments/pay_20250708T140330Z_PPhCoqUZcj.json",
            "/proc/payments/pay_20250708T141710Z_TTfZyCSxuc.json",
            "/proc/payments/pay_20250708T142439Z_23jt9mMNBk.json",
            "/proc/payments/pay_20250708T145910Z_NvuqDvaumd.json",
            "/proc/payments/pay_20250708T150324Z_RERsAvQvEd.json"
        ]
    },
    "cluster_2_impossible_travel_aug15": {
        "hard_signal": "impossible_observed_travel",
        "customers": ["cust_040"],
        "date": "2025-08-15",
        "description": "cust_040 (same PMF pm_KQkKxgxbt1PCVD as July 8 attack) had 4 consecutive payments using same device (dev_7Uwmwp6ciMdDVu) but observed coordinates jumping across Brno/Graz/Vienna/Innsbruck in 26 minutes",
        "records": [
            "/proc/payments/pay_20250815T022759Z_c8NrpEGFcM.json",
            "/proc/payments/pay_20250815T023748Z_J4Au5GEhYC.json",
            "/proc/payments/pay_20250815T024904Z_TRBaSPZkcd.json",
            "/proc/payments/pay_20250815T025400Z_Q4nFLx6ktv.json"
        ]
    },
    "cluster_3_burst_july18": {
        "hard_signal": "stationary_single_actor_burst",
        "customers": ["cust_100"],
        "date": "2025-07-18",
        "description": "cust_100 made 11 payments at 10 different stores in 4 minutes while observed location remained stationary near Vienna (L1 spread < 0.009). Used 2 different devices and 2 PMFs.",
        "records": [
            "/proc/payments/pay_20250718T175045Z_VJuSU7FszJ.json",
            "/proc/payments/pay_20250718T175109Z_VA4vBD88iZ.json",
            "/proc/payments/pay_20250718T175127Z_63i5yvWddE.json",
            "/proc/payments/pay_20250718T175142Z_TK4MsfoJHW.json",
            "/proc/payments/pay_20250718T175230Z_34ZDgEK8Ja.json",
            "/proc/payments/pay_20250718T175237Z_Q8ZA6782KE.json",
            "/proc/payments/pay_20250718T175300Z_AkZsxPbkQE.json",
            "/proc/payments/pay_20250718T175305Z_DYY34ETv1f.json",
            "/proc/payments/pay_20250718T175321Z_R9FNNZJo6q.json",
            "/proc/payments/pay_20250718T175341Z_4d6AbQVsGK.json",
            "/proc/payments/pay_20250718T175455Z_S9vY74gVVy.json"
        ]
    }
}

scratchpad["total_cohort_size"] = 25
scratchpad["validated_zero_max_metrics"] = {
    "identifier_collision_max_cust_per_pmf": 1,
    "identifier_collision_max_cust_per_dfp": 1,
    "record_invariant_max_amount_discrepancy": 0
}

scratchpad["business_process"] = {
    "primary": "fraud_risk_review.md",
    "reason": "Task requests identification of fraudulent payment records from archived payments history"
}

print("Scratchpad saved")
print("Total cohort: 25 records")
print("  - Cluster 1 (impossible travel Jul 8): 10 records")
print("  - Cluster 2 (impossible travel Aug 15): 4 records")
print("  - Cluster 3 (burst Jul 18): 11 records")
