# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Examine the impossible travel hits more closely
# First, get the full details of all involved payments

# Collect all record_paths from the travel hits (both prev and current)
travel_paths = [
    '/proc/payments/pay_20250708T125910Z_9a2xWoS1fj.json',
    '/proc/payments/pay_20250708T130543Z_CxHDu7BLbe.json',
    '/proc/payments/pay_20250708T131710Z_KLJV5NzcEB.json',
    '/proc/payments/pay_20250708T132231Z_QAxDMD152c.json',
    '/proc/payments/pay_20250708T135710Z_DDV43qYTxg.json',
    '/proc/payments/pay_20250708T140330Z_PPhCoqUZcj.json',
    '/proc/payments/pay_20250815T022759Z_c8NrpEGFcM.json',
    '/proc/payments/pay_20250815T023748Z_J4Au5GEhYC.json',
    '/proc/payments/pay_20250815T024904Z_TRBaSPZkcd.json',
    '/proc/payments/pay_20250815T025400Z_Q4nFLx6ktv.json',
    '/proc/payments/pay_20250708T141710Z_TTfZyCSxuc.json',
    '/proc/payments/pay_20250708T142439Z_23jt9mMNBk.json',
    '/proc/payments/pay_20250708T145910Z_NvuqDvaumd.json',
    '/proc/payments/pay_20250708T150324Z_RERsAvQvEd.json',
]

# Query for these records
placeholders = ','.join([f"'{p}'" for p in travel_paths])
res_details = ws.sql_rows(f"""
SELECT payment_id, record_path, customer_id, store_id, payment_created_at,
       observed_latitude, observed_longitude, payment_amount_cents,
       payment_method_fingerprint, device_fingerprint
FROM payment_transactions
WHERE record_path IN ({placeholders})
ORDER BY customer_id, payment_created_at
""", limit=50)
print("Travel hit details:")
for r in res_details["rows"]:
    print(r)
