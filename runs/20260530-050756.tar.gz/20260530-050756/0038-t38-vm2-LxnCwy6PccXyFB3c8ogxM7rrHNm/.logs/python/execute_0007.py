# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get all payments for cust_100 in the burst window (expanded, no LIMIT)
res_burst_detail = ws.sql_rows("""
SELECT payment_id, record_path, customer_id, store_id, payment_created_at,
       observed_latitude, observed_longitude, payment_amount_cents,
       payment_method_fingerprint, device_fingerprint
FROM payment_transactions
WHERE customer_id = 'cust_100'
  AND is_archived_basket_reference = 1
  AND payment_created_at >= '2025-07-18T17:50:00Z'
  AND payment_created_at <= '2025-07-18T18:00:00Z'
ORDER BY payment_created_at
""", limit=200)
print("cust_100 burst window payments:", res_burst_detail["row_count"])
for r in res_burst_detail["rows"]:
    print(r)
