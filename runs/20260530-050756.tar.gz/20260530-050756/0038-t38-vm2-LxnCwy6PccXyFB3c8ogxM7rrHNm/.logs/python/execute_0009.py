# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Compile complete final cohort - all hard-supported records
# From impossible travel family: all records involved in impossible travel jumps
# From burst family: all records in cust_100's burst window

# Get all impossible travel records - expand the query to include all records in the jump pairs
res_travel_all = ws.sql_rows("""
WITH seq AS (
  SELECT p.*,
         LAG(record_path) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_path,
         LAG(payment_created_at) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_ts,
         LAG(observed_latitude) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_lat,
         LAG(observed_longitude) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_lon
  FROM payment_transactions p
  WHERE is_archived_basket_reference = 1
),
jumps AS (
  SELECT customer_id, prev_path, record_path AS curr_path, prev_ts, payment_created_at,
         (julianday(payment_created_at) - julianday(prev_ts)) * 24 * 60 AS minutes,
         ABS(observed_latitude - prev_lat) + ABS(observed_longitude - prev_lon) AS observed_l1
  FROM seq
  WHERE prev_path IS NOT NULL
    AND (julianday(payment_created_at) - julianday(prev_ts)) * 24 * 60 BETWEEN 0 AND 15
    AND ABS(observed_latitude - prev_lat) + ABS(observed_longitude - prev_lon) > 2.0
),
flagged_paths AS (
  SELECT prev_path AS record_path FROM jumps
  UNION
  SELECT curr_path AS record_path FROM jumps
)
SELECT DISTINCT pt.payment_id, pt.record_path, pt.customer_id, pt.store_id,
       pt.payment_created_at, pt.observed_latitude, pt.observed_longitude,
       pt.payment_method_fingerprint, pt.device_fingerprint
FROM payment_transactions pt
JOIN flagged_paths fp ON pt.record_path = fp.record_path
ORDER BY pt.customer_id, pt.payment_created_at
""", limit=200)
print("All impossible travel records:", res_travel_all["row_count"])
for r in res_travel_all["rows"]:
    print(f"  {r['customer_id']} | {r['payment_id']} | {r['store_id']} | {r['payment_created_at']}")

# cust_100 burst records (already verified - 11)
print("\ncust_100 burst: 11 records (already listed)")

print("\nTotal cohort size:", res_travel_all["row_count"] + 11)
