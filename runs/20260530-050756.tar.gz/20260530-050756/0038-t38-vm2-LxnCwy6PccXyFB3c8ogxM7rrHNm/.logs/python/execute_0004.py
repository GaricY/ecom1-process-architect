# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Hard sweep family 3: Impossible observed travel
# Check if same customer makes payments from very different locations in short time
res_travel = ws.sql_rows("""
WITH seq AS (
  SELECT p.*,
         LAG(record_path) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_path,
         LAG(payment_created_at) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_ts,
         LAG(observed_latitude) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_lat,
         LAG(observed_longitude) OVER(PARTITION BY customer_id ORDER BY payment_created_at, payment_id) AS prev_lon
  FROM payment_transactions p
  WHERE is_archived_basket_reference = 1
),
jumps AS (
  SELECT customer_id, prev_path, record_path, prev_ts, payment_created_at,
         (julianday(payment_created_at) - julianday(prev_ts)) * 24 * 60 AS minutes,
         ABS(observed_latitude - prev_lat) + ABS(observed_longitude - prev_lon) AS observed_l1
  FROM seq
  WHERE prev_path IS NOT NULL
)
SELECT customer_id, prev_path, record_path, prev_ts, payment_created_at,
       ROUND(minutes, 2) AS minutes, ROUND(observed_l1, 4) AS observed_l1
FROM jumps
WHERE minutes BETWEEN 0 AND 15
  AND observed_l1 > 2.0
ORDER BY customer_id, payment_created_at
""", limit=500)
print("Impossible observed travel hits:", res_travel["row_count"])
print("Rows:", res_travel["rows"][:20])
