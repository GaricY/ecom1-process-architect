# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Hard sweep family 2: Workflow-state invariants
# All are 'paid' with null 3DS - check if that's valid (3DS invariant check)
# Since all three_ds_status IS NULL, this means no 3DS flow was triggered - check if valid

# Hard sweep family 3: Record/table invariants
# Check if payment amounts match basket items (amount vs lines)
res_amt = ws.sql_rows("""
SELECT pt.payment_id, pt.record_path, pt.payment_amount_cents,
       SUM(pti.item_unit_price_cents * pti.purchased_quantity) AS calculated_total,
       pt.payment_amount_cents - SUM(pti.item_unit_price_cents * pti.purchased_quantity) AS discrepancy
FROM payment_transactions pt
JOIN payment_transaction_items pti ON pt.payment_id = pti.payment_id
WHERE pt.is_archived_basket_reference = 1
GROUP BY pt.payment_id
HAVING discrepancy != 0
ORDER BY ABS(discrepancy) DESC
LIMIT 20
""")
print("Amount vs line items discrepancy:", res_amt["row_count"])
if res_amt["row_count"] > 0:
    print(res_amt["rows"][:5])

# Check for duplicate payment_ids for same basket
res_dup_pay = ws.sql_rows("""
SELECT basket_id, COUNT(*) as cnt, GROUP_CONCAT(payment_id) as payment_ids
FROM payment_transactions
WHERE is_archived_basket_reference = 1
GROUP BY basket_id
HAVING cnt > 1
ORDER BY cnt DESC
LIMIT 10
""")
print("\nDuplicate payments for basket:", res_dup_pay["row_count"])
print(res_dup_pay["rows"][:5])

# Check payment_transactions records without corresponding payment_transaction_items
res_no_items = ws.sql_rows("""
SELECT pt.payment_id, pt.record_path, pt.payment_amount_cents
FROM payment_transactions pt
LEFT JOIN payment_transaction_items pti ON pt.payment_id = pti.payment_id
WHERE pt.is_archived_basket_reference = 1
  AND pti.payment_id IS NULL
ORDER BY pt.payment_created_at
LIMIT 20
""")
print("\nPayments with no line items:", res_no_items["row_count"])
