# BitGN ECOM trial

- benchmark: bitgn/ecom1-dev
- task_id: t18
- trial_id: vm2-LxnCwy6PccXyFB3c8ogxM7rrHNR

## Task instruction

<task-instruction>
I can visit any PowerTool branch in Graz today. Across every Graz branch, including branches with 0 availability, how many units of product (the Chainsaw from Fiskars in the Fiskars Battery X 1CD-A3X Chainsaw line that has power source battery) are available today? Answer exactly as "%d total" and cite every city store record plus the product record.
</task-instruction>

## How to work in this directory

The orchestrator prepared this folder with:

- `vault/` — fresh dump of live `/docs`, `/bin`, every `AGENTS.md` and `README.md`.
- `tree.md` — `tree -L 2 /` snapshot at trial start.
- `bin-help/` — `--help` output for every `/bin/<tool>` that exists.
- `CLAUDE.md` — executor role, scratchpad/state contract, refs/submission.
- `business_processes/` — short policy reminders.
- `runtime_prelude.py`, `workspace.py` — Python prelude loaded by every `execute_python` snippet.

Live workspace/policy always wins over the local snapshot. All runtime
reads, SQL queries, `/bin/*` actions, and final answer submission go
through the MCP tool `execute_python` — that is the only runtime
boundary. Do NOT use the host shell.

Read `CLAUDE.md` first, then this file, then call `execute_python`
with your first Python snippet.
