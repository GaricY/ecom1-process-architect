# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Set scratchpad and submit
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Store-scoped inventory sum for a specific product across all Graz branches."
}
scratchpad["decision"] = {
    "product_sku": "GRD-138CLG7H",
    "product_name": "Fiskars Battery X 1CD-A3X Chainsaw battery 20cm",
    "power_source": "battery",
    "graz_stores": [
        {"store_id": "store_graz_jakomini", "available_today_quantity": 7},
        {"store_id": "store_graz_lend", "available_today_quantity": 0}
    ],
    "total": 7,
    "policy_update_scan": "No dated update folders found in /docs. No matching updates for chainsaws or Graz. Used plain SQL sum.",
    "petrol_variant_sku": "GRD-1QO0KQ77",
    "petrol_variant_rejected": "power_source=petrol, not battery as requested"
}

refs = [
    "/proc/stores/store_graz_jakomini.json",
    "/proc/stores/store_graz_lend.json",
    "/proc/catalog/Fiskars/GRD-138CLG7H.json",
    "/docs/README.md"
]

submit_and_exit(
    message="7 total",
    outcome="OUTCOME_OK",
    refs=refs
)
