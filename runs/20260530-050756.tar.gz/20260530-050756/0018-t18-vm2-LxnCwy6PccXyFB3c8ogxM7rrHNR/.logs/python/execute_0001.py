# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find the product (Fiskars Chainsaw, battery power source, in Fiskars Battery X 1CD-A3X Chainsaw line)
res = ws.sql_rows("""
    SELECT pv.product_sku, pv.record_path, pv.brand, pv.series, pv.model, pv.product_name,
           pv.product_family_id, pv.product_kind_id, pv.properties
    FROM product_variants pv
    WHERE LOWER(pv.brand) LIKE '%fiskars%'
      AND LOWER(pv.series) LIKE '%1cd-a3x%'
""")
print("Products matching Fiskars + 1CD-A3X:")
for r in res["rows"]:
    print(r)

# Step 2: Find all Graz stores
res2 = ws.sql_rows("""
    SELECT store_id, record_path, store_name, city, is_open
    FROM stores
    WHERE LOWER(city) LIKE '%graz%'
""")
print("\nGraz stores:")
for r in res2["rows"]:
    print(r)
