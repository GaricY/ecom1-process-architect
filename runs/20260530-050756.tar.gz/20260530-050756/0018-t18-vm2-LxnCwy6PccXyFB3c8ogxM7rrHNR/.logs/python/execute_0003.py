# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Query inventory for the battery chainsaw across all Graz stores
# Using LEFT JOIN to include stores with 0 or no inventory
res = ws.sql_rows("""
    SELECT s.store_id, s.store_name, s.record_path AS store_record_path,
           COALESCE(si.available_today_quantity, 0) AS available_today_quantity
    FROM stores s
    LEFT JOIN store_inventory si ON si.store_id = s.store_id AND si.product_sku = 'GRD-138CLG7H'
    WHERE LOWER(s.city) LIKE '%graz%'
    ORDER BY s.store_id
""")
print(f"Inventory for GRD-138CLG7H across Graz stores:")
total = 0
for r in res["rows"]:
    print(r)
    total += r["available_today_quantity"]
print(f"\nTotal: {total}")

# Also get the product record path
prod = ws.sql_rows("SELECT product_sku, record_path FROM product_variants WHERE product_sku = 'GRD-138CLG7H'")
print(f"\nProduct record: {prod['rows'][0]}")
