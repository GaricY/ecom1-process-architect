# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Broader search for Fiskars chainsaw products
res = ws.sql_rows("""
    SELECT pv.product_sku, pv.record_path, pv.brand, pv.series, pv.model, pv.product_name,
           pv.product_family_id, pv.product_kind_id, pv.properties
    FROM product_variants pv
    WHERE LOWER(pv.brand) LIKE '%fiskars%'
""")
print(f"All Fiskars products ({res['row_count']} rows):")
for r in res["rows"]:
    print(r)
