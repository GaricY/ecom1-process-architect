# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Check docs tree for any relevant policy updates (per policy_update_scan.md)
tree = ws.tree("/docs", level=2)
import json
print(json.dumps(tree, indent=2))
