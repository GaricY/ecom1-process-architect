# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Check /docs/README.md for the catalogue reporting rule
res = ws.read("/docs/README.md")
print(res["content"])
