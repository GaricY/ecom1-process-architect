# Card Verification Hold Memo

Operating day: 2024-07-17
Payment under review: pay_002

This memo takes precedence over the standard 3DS recovery guide for the payment above. The bank challenge may be restarted only after 2024-07-18T14:49:48Z. Check the live clock with /bin/date before using payment recovery tooling. Before that timestamp, leave the payment unchanged and tell the customer when retry is available.
