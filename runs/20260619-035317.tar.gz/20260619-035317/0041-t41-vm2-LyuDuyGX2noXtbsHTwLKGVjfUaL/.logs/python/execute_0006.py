# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

agents_res = ws.read("/AGENTS.MD")
print("AGENTS:", agents_res["content"])
