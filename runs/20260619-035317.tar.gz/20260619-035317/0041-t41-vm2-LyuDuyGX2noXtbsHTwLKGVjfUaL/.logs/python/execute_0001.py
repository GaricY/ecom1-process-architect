# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Read basket_202 and find associated payment
basket_res = ws.read("/proc/baskets/basket_202.json")
print("BASKET:", basket_res["content"])

# Also list payments to find the one linked to basket_202
payments_list = ws.list("/proc/payments/")
print("PAYMENTS:", [e["name"] for e in payments_list["entries"]])
