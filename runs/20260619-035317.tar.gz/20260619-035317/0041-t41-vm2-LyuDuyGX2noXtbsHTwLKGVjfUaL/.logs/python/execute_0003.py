# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find payment for basket_202 with correct column names
res = ws.sql_rows(
    "SELECT record_path, payment_id, basket_id, customer_id, payment_status FROM payment_transactions WHERE basket_id = 'basket_202'"
)
print("PAYMENT rows:", res["rows"])

# Docs tree for policy update scan
import json
docs_tree = ws.tree(root="/docs", level=2)
print("DOCS tree:", json.dumps(docs_tree, indent=2))
