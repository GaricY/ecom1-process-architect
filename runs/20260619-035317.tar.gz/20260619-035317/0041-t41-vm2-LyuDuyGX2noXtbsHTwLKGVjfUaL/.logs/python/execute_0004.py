# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import json

# Read payment record
pay_res = ws.read("/proc/payments/pay_002.json")
print("PAYMENT:", pay_res["content"])

# Read policy update candidate
update_res = ws.read("/docs/payments/3ds-retry-window-2024-07-17.md")
print("POLICY UPDATE:", update_res["content"])

# Read 3ds.md
tds_res = ws.read("/docs/payments/3ds.md")
print("3DS:", tds_res["content"])
