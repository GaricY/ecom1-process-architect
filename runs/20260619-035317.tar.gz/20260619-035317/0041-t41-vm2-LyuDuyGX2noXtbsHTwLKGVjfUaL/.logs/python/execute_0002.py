# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find payment for basket_202 via SQL
res = ws.sql_rows(
    "SELECT record_path, id, basket_id, customer_id, status FROM payment_transactions WHERE basket_id = 'basket_202'"
)
print("PAYMENT rows:", res["rows"])

# Also do the docs tree discovery for policy updates
docs_tree = ws.tree(root="/docs", level=2)
import json
print("DOCS tree:", json.dumps(docs_tree, indent=2))
