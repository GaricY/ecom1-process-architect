# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read required prerequisite policies
checkout_res = ws.read("/docs/checkout.md")
print("CHECKOUT:", checkout_res["content"][:800])

security_res = ws.read("/docs/security.md")
print("SECURITY:", security_res["content"][:500])
