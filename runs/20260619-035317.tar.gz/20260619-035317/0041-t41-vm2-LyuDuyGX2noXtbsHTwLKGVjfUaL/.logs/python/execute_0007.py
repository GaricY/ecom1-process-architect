# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["business_process"] = {
    "primary": "payments_3ds_recovery.md",
    "reason": "Customer requests 3DS recovery for basket_202/pay_002 stuck at card verification."
}

scratchpad["decision"] = {
    "identity": "cust_023 (customer), owns basket_202 and pay_002",
    "basket_status": "checked_out ✓",
    "payment_status": "requires_3ds_action ✓",
    "basket_id_match": "basket_202 on both records ✓",
    "three_ds_status": "3ds-status2 (recoverable) ✓",
    "attempts": "1 < 3 ✓",
    "policy_update": "/docs/payments/3ds-retry-window-2024-07-17.md names pay_002 explicitly",
    "lockout_until": "2024-07-18T14:49:48Z",
    "current_time": "2024-07-17T20:49:48Z",
    "lockout_active": "YES — current time is before release timestamp → OUTCOME_NONE_UNSUPPORTED"
}

refs = [
    "/docs/security.md",
    "/docs/checkout.md",
    "/docs/payments/3ds.md",
    "/docs/payments/3ds-retry-window-2024-07-17.md",
    "/proc/payments/pay_002.json",
    "/proc/baskets/basket_202.json"
]

message = (
    "Recovery for payment pay_002 (basket_202) is temporarily on hold. "
    "A bank verification hold memo requires waiting until 2024-07-18T14:49:48Z before the 3DS challenge can be restarted. "
    "Please try again after that time."
)

submit_and_exit(message=message, outcome="OUTCOME_NONE_UNSUPPORTED", refs=refs)
