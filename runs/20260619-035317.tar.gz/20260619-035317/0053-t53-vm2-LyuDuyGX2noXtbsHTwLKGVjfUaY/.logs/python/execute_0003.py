# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 3: Look up current prices for the receipt SKUs
skus = ["GRD-138CLG7H", "WRK-3JV3G2YY", "STO-1IL9J3GJ", "WRK-2F0CSCUL"]
res = ws.sql_rows(
    f"""SELECT product_sku, product_name, price_cents, price_currency, record_path
        FROM product_variants
        WHERE product_sku IN ('GRD-138CLG7H','WRK-3JV3G2YY','STO-1IL9J3GJ','WRK-2F0CSCUL')"""
)
for row in res["rows"]:
    print(row)
