# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: List /uploads/ to find the receipt
uploads = ws.list("/uploads/")
print(uploads)
