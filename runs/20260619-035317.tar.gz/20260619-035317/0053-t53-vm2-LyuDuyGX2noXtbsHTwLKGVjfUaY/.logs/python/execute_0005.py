# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get full data for the matched Engelbert SKU
res_eng = ws.sql_rows(
    "SELECT product_sku, product_name, price_cents, price_currency, record_path FROM product_variants WHERE product_sku = 'WRK-2F0C5CUL'"
)
print(res_eng["rows"])

# Compute comparison
# Receipt data (all prices are excl. VAT per the receipt total logic)
receipt_items = [
    {"sku": "GRD-138CLG7H", "qty": 3, "old_unit_cents": 57899},  # 578.99 EUR
    {"sku": "WRK-3JV3G2YY", "qty": 1, "old_unit_cents": 7850},   # 78.50 EUR
    {"sku": "STO-1IL9J3GJ", "qty": 2, "old_unit_cents": 34199},   # 341.99 EUR
    {"sku": "WRK-2F0C5CUL", "qty": 2, "old_unit_cents": 3499},    # 34.99 EUR
]

# Current prices from SQL
current_prices = {
    "GRD-138CLG7H": 57900,  # 579.00 EUR
    "WRK-3JV3G2YY": 7800,   # 78.00 EUR
    "STO-1IL9J3GJ": 34200,  # 342.00 EUR
    "WRK-2F0C5CUL": 3500,   # 35.00 EUR
}

old_total_cents = sum(item["qty"] * item["old_unit_cents"] for item in receipt_items)
new_total_cents = sum(item["qty"] * current_prices[item["sku"]] for item in receipt_items)

print(f"Old total (excl. VAT): {old_total_cents/100:.2f} EUR")
print(f"New total (excl. VAT): {new_total_cents/100:.2f} EUR")
print(f"Difference: {abs(new_total_cents - old_total_cents)/100:.2f} EUR")
print(f"Within 2 EUR? {abs(new_total_cents - old_total_cents)/100 <= 2.00}")
