# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

submit_and_exit(
    message=(
        "<YES> Selling the same products today would result in a total price (excl. VAT) of 2569.00 EUR, "
        "compared to 2569.43 EUR on the old receipt — a difference of only 0.43 EUR, which is within the 2 EUR threshold.\n\n"
        "Item breakdown (excl. VAT):\n"
        "- GRD-138CLG7H Fiskars Battery X 1CD-A3X Chainsaw battery × 3: was 578.99 EUR/unit → now 579.00 EUR/unit (line: 1736.97 → 1737.00)\n"
        "- WRK-3JV3G2YY Mascot Advanced ACC 35W-IIS Work Jacket × 1: was 78.50 EUR → now 78.00 EUR\n"
        "- STO-1IL9J3GJ Raaco Professional CarryLite 3CS-7A9 Shelving unit × 2: was 341.99 EUR/unit → now 342.00 EUR/unit (line: 683.98 → 684.00)\n"
        "- WRK-2F0C5CUL Engelbert Strauss e.s.vision polo shirt × 2: was 34.99 EUR/unit → now 35.00 EUR/unit (line: 69.98 → 70.00)\n\n"
        "Old total (excl. VAT): 2569.43 EUR | New total (excl. VAT): 2569.00 EUR | Difference: 0.43 EUR"
    ),
    outcome="OUTCOME_OK",
    refs=[
        "/uploads/receipt_ocr_J6MV1XfT.txt",
        "/proc/catalog/Fiskars/GRD-138CLG7H.json",
        "/proc/catalog/Mascot/WRK-3JV3G2YY.json",
        "/proc/catalog/Raaco/STO-1IL9J3GJ.json",
        "/proc/catalog/Engelbert Strauss/WRK-2F0C5CUL.json",
    ]
)
