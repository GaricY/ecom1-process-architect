# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Check if WRK-2F0CSCUL exists (OCR might have garbled it)
res = ws.sql_rows("SELECT product_sku, product_name, price_cents FROM product_variants WHERE product_sku LIKE 'WRK-2F%'")
print("WRK-2F search:", res["rows"])

# Also try a broader search for Engelbert Strauss
res2 = ws.sql_rows("SELECT product_sku, product_name, price_cents FROM product_variants WHERE LOWER(product_name) LIKE '%engelbert%'")
print("Engelbert search:", res2["rows"])
