# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 2: Read the receipt
receipt = ws.read("/uploads/receipt_ocr_J6MV1XfT.txt")
print(receipt["content"])
