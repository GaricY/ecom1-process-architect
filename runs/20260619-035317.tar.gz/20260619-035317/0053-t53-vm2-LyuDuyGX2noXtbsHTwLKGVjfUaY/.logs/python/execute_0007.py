# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Save scratchpad audit
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Comparison of old receipt prices vs current catalogue prices (catalogue comparison-against-an-input task)"
}

scratchpad["evidence"] = {
    "receipt_path": "/uploads/receipt_ocr_J6MV1XfT.txt",
    "receipt_total_excl_vat_eur": 2569.43,
    "items": [
        {"sku": "GRD-138CLG7H", "qty": 3, "old_unit_eur": 578.99, "new_unit_eur": 579.00, "old_line": 1736.97, "new_line": 1737.00},
        {"sku": "WRK-3JV3G2YY", "qty": 1, "old_unit_eur": 78.50,  "new_unit_eur": 78.00,  "old_line": 78.50,   "new_line": 78.00},
        {"sku": "STO-1IL9J3GJ", "qty": 2, "old_unit_eur": 341.99, "new_unit_eur": 342.00, "old_line": 683.98,  "new_line": 684.00},
        {"sku": "WRK-2F0C5CUL", "qty": 2, "old_unit_eur": 34.99,  "new_unit_eur": 35.00,  "old_line": 69.98,   "new_line": 70.00},
    ],
    "ocr_correction": "Receipt shows WRK-2F0CSCUL; OCR-garbled; matched to WRK-2F0C5CUL (Engelbert Strauss polo shirt, price 35.00 vs 34.99)",
    "new_total_excl_vat_eur": 2569.00,
    "difference_eur": 0.43,
    "within_2_eur": True,
}

scratchpad["refs_must_include"] = [
    "/uploads/receipt_ocr_J6MV1XfT.txt",
    "/proc/catalog/Fiskars/GRD-138CLG7H.json",
    "/proc/catalog/Mascot/WRK-3JV3G2YY.json",
    "/proc/catalog/Raaco/STO-1IL9J3GJ.json",
    "/proc/catalog/Engelbert Strauss/WRK-2F0C5CUL.json",
]

print("Scratchpad saved.")
print("Old total excl. VAT: 2569.43 EUR")
print("New total excl. VAT: 2569.00 EUR")
print("Difference: 0.43 EUR — within 2 EUR → YES")
