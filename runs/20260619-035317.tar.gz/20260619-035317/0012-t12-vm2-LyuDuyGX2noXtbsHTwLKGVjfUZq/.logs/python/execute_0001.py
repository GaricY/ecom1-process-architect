# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find product_kind_id for "Wall Paint"
res = ws.sql_rows("SELECT product_kind_id, product_kind_name FROM product_kinds WHERE LOWER(product_kind_name) LIKE LOWER('%Wall Paint%')")
print("product_kinds:", res)

# Step 2: Also list /docs tree for policy_update_scan
docs_tree = ws.tree(root="/docs", level=2)
print("docs tree:", docs_tree)
