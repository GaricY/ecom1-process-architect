# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue product-count question for product kind 'Wall Paint'.",
}

scratchpad["decision"] = {
    "product_kind_id": "wall_paint",
    "product_kind_name": "Wall Paint",
    "count": 308,
    "policy_update_scan": {
        "candidate_found": "/docs/catalogue-addenda/2021-08-09-reporting-wall-paint.md",
        "operating_day": "2021-08-09",
        "matched_dimensions": ["product_kind_id=wall_paint", "operating_day=2021-08-09", "workflow=catalogue product-kind count questions"],
        "rule_applied": "Use normal catalogue COUNT(*) — count every SKU with product_kind_id='wall_paint' once; no inventory/display/family-hold filters.",
    },
    "refs_rationale": "Count question → cite /docs/README.md and matched update doc; no per-product record_paths.",
}

final_refs = [
    "/docs/README.md",
    "/docs/catalogue-addenda/2021-08-09-reporting-wall-paint.md",
]

submit_and_exit(
    message="<COUNT:308>",
    outcome="OUTCOME_OK",
    refs=final_refs,
)
