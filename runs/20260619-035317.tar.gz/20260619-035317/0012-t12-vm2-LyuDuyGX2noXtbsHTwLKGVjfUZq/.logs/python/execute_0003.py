# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Count Wall Paint products
res = ws.sql_rows("SELECT COUNT(*) as cnt FROM product_variants WHERE product_kind_id = 'wall_paint'")
print("Wall Paint count:", res)

# Also read /docs/README.md to check catalogue reporting rule
readme = ws.read("/docs/README.md")
print(readme["content"])
