# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read the matching policy update for wall_paint
res = ws.read("/docs/catalogue-addenda/2021-08-09-reporting-wall-paint.md")
print(res["content"])
