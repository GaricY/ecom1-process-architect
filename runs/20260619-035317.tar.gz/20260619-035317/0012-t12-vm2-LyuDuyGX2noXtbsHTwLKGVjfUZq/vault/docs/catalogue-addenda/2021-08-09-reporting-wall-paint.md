# Catalogue Count Reporting Update

Operating day: 2021-08-09
Workflow: catalogue product-kind count questions
Requested product kind: Wall Paint
Requested product_kind_id: wall_paint

For today's report, use the normal catalogue count: count every product record
whose product_kind_id matches the requested product kind. Count each SKU once. Do not
apply inventory, display, merchandising, or family-hold filters unless another
current update explicitly names them.
