# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read the basket file
basket = ws.read("/proc/baskets/basket_095.json")
import json
basket_data = json.loads(basket["content"])
print("Basket data:", json.dumps(basket_data, indent=2))
