# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find customer by email
cust_res = ws.sql_rows("""
    SELECT customer_id, record_path
    FROM customer_accounts
    WHERE customer_email = 'florian.barth+cust779@fastmail.com'
""")
print("Customer:", cust_res)

# Get my employee store
emp_res = ws.sql_rows("""
    SELECT employee_id, store_id, record_path
    FROM employee_accounts
    WHERE employee_id = 'emp_031'
""")
print("Employee:", emp_res)
