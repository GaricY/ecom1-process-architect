# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read /docs/discounts.md and the basket
disc_doc = ws.read("/docs/discounts.md")
print("=== DISCOUNTS DOC ===")
print(disc_doc["content"])
