# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Check inventory and compute subtotal
inv_res = ws.sql_rows("""
    SELECT si.available_today_quantity, pv.price_cents, pv.record_path as pv_record_path
    FROM store_inventory si
    JOIN product_variants pv ON si.product_sku = pv.product_sku
    WHERE si.store_id = 'store_innsbruck_wilten'
      AND si.product_sku = 'ELC-3W5BB5PN'
""")
print("Inventory:", inv_res)

# Also read checkout.md to get the line eligibility gate
checkout_doc = ws.read("/docs/checkout.md")
print("=== CHECKOUT DOC ===")
print(checkout_doc["content"])
