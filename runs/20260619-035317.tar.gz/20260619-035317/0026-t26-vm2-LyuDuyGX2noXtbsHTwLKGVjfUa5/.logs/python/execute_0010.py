# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Get store record path
store_res = ws.sql_rows("""
    SELECT store_id, record_path, store_name
    FROM stores
    WHERE store_id = 'store_innsbruck_wilten'
""")
print("Store:", store_res)
