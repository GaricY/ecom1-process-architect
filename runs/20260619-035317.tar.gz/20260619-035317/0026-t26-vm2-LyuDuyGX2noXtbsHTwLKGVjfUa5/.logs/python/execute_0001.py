# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find customer by email
res = ws.sql_rows("""
    SELECT customer_id, record_path, email
    FROM customer_accounts
    WHERE email = 'florian.barth+cust779@fastmail.com'
""")
print("Customer lookup:", res)

# Also get my employee info
emp_res = ws.sql_rows("""
    SELECT employee_id, store_id, record_path
    FROM employee_accounts
    WHERE employee_id = 'emp_031'
""")
print("Employee info:", emp_res)
