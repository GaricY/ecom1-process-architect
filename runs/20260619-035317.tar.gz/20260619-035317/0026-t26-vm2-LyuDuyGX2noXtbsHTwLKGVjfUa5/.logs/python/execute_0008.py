# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# All gates pass. Apply the discount.
# Subtotal: 2100 cents (1 × 2100), 5% is valid (1-5% for any subtotal)
# store match: store_innsbruck_wilten ✓
# checkout eligible: quantity 1 ≤ available_today 6 ✓
# reason_code: service_recovery ✓
# issuer_id: emp_031 ✓

result = ws.exec_tool("/bin/discount", args=["basket_095", "5", "service_recovery", "emp_031"])
print("Discount result:", result)
