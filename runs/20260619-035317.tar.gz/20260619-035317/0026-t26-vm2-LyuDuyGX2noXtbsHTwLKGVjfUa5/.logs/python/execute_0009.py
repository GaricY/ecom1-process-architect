# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Re-read basket to confirm post-state
basket_post = ws.read("/proc/baskets/basket_095.json")
import json
basket_post_data = json.loads(basket_post["content"])
print("Post-state basket:", json.dumps(basket_post_data, indent=2))
