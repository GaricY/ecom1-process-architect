# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Policy update scan - inspect /docs tree
docs_tree = ws.tree(root="/docs", level=2)
print("Docs tree:", docs_tree)
