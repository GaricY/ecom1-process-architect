# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import json

scratchpad["business_process"] = {
    "primary": "discount.md",
    "reason": "Request asks to apply a percent discount with reason code to a customer basket.",
}

scratchpad["decision"] = {
    "actor": "emp_031",
    "roles": ["discount_manager"],
    "basket_id": "basket_095",
    "customer_id": "cust_040",
    "store_match": "store_innsbruck_wilten == emp_031 store",
    "basket_status": "active",
    "existing_discount": None,
    "subtotal_cents": 2100,
    "percent_requested": 5,
    "percent_valid": "1-5% for any subtotal",
    "reason_code": "service_recovery",
    "line_eligible": "ELC-3W5BB5PN qty=1 <= available_today=6",
    "policy_update_scan": "No dated updates found in /docs",
    "mutation": "discount_applied basket_095 5 service_recovery emp_031",
    "post_state_confirmed": True,
}

submit_and_exit(
    message="Applied a 5% service_recovery discount to basket basket_095 (the last active, checkoutable basket for the customer in store PowerTool Innsbruck Wilten). Issuer: emp_031. Post-state confirmed: discount object present with percent=5, reason_code=service_recovery.",
    outcome="OUTCOME_OK",
    refs=[
        "/docs/security.md",
        "/docs/discounts.md",
        "/docs/checkout.md",
        "/proc/baskets/basket_095.json",
        "/proc/stores/store_innsbruck_wilten.json",
    ]
)
