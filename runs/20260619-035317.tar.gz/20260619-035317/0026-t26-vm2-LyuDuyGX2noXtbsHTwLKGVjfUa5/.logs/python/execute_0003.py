# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find active baskets of cust_040 in my store, ordered by creation date
baskets_res = ws.sql_rows("""
    SELECT basket_id, record_path, store_id, basket_status, basket_created_at,
           discount_percent, discount_reason_code
    FROM shopping_baskets
    WHERE customer_id = 'cust_040'
      AND basket_status = 'active'
      AND discount_percent IS NULL
    ORDER BY basket_created_at DESC
""")
print("Active baskets (no discount):", baskets_res)

# Also check all baskets just to understand the picture
all_baskets = ws.sql_rows("""
    SELECT basket_id, store_id, basket_status, basket_created_at,
           discount_percent
    FROM shopping_baskets
    WHERE customer_id = 'cust_040'
    ORDER BY basket_created_at DESC
    LIMIT 10
""")
print("All baskets:", all_baskets)
