## execute_0001  exit=1  [03:55:23]

```
Traceback (most recent call last):
  File "/home/garic/proj/bitgn/.runs/ecom/20260619-035317/0026-t26-vm2-LyuDuyGX2noXtbsHTwLKGVjfUa5/.logs/python/execute_0001.py", line 6, in <module>
    res = ws.sql_rows("""
        SELECT customer_id, record_path, email
        FROM customer_accounts
        WHERE email = 'florian.barth+cust779@fastmail.com'
    """)
  File "/home/garic/proj/bitgn/.runs/ecom/20260619-035317/0026-t26-vm2-LyuDuyGX2noXtbsHTwLKGVjfUa5/workspace.py", line 309, in sql_rows
    rows, page_cap = self._sql_page(stripped)
                     ~~~~~~~~~~~~~~^^^^^^^^^^
  File "/home/garic/proj/bitgn/.runs/ecom/20260619-035317/0026-t26-vm2-LyuDuyGX2noXtbsHTwLKGVjfUa5/workspace.py", line 258, in _sql_page
    raise RuntimeError(
    ...<2 lines>...
    )
RuntimeError: SQL logic error: no such column: email (1)
```

