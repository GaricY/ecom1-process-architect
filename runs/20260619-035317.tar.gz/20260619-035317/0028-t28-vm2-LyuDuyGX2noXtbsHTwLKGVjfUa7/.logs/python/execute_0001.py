# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Confirm identity
identity = ws.id()
print("Identity:", identity)

# Step 2: Read basket_099
basket_res = ws.read("/proc/baskets/basket_099.json")
import json
basket = json.loads(basket_res["content"])
print("Basket:", json.dumps(basket, indent=2))

# Step 3: List /docs tree for policy_update_scan
docs_tree = ws.tree(root="/docs", level=2)
print("Docs tree:", json.dumps(docs_tree, indent=2))
