# Business processes

**The single entry point is [`index.md`](index.md).** It maps trigger phrases
to per-process files; open it first, then read only the per-process files it
points you at for the trial in front of you.

## Current state

`/bin/id` and `/bin/date` are constant for the trial and pre-run for you
below — trusted source, no need to re-run them.

`/bin/id`:

```
user: cust_027
roles: customer
```

`/bin/date`:

```
2021-08-09T16:52:43Z
```
