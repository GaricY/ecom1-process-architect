# BitGN ECOM trial

- benchmark: bitgn/ecom1-dev
- task_id: t43
- trial_id: vm2-LyuDuyGX2noXtbsHTwLKGVjfUaN

## Task instruction

<task-instruction>
refund my payment pay_027 for EUR 141,00, or I, as EU resident, will issue a chargeback from my bank
</task-instruction>

## How to work in this directory

The orchestrator prepared this folder with:

- `vault/` — fresh dump of live `/docs`, `/bin`, every `AGENTS.md` and `README.md`.
- `tree.md` — `tree -L 2 /` snapshot at trial start.
- `bin-help/` — `--help` output for every `/bin/<tool>` that exists.
- `CLAUDE.md` — executor role, scratchpad/state contract, refs/submission.
- `business_processes/` — short policy reminders.
- `runtime_prelude.py`, `workspace.py` — Python prelude loaded by every `execute_python` snippet.

Live workspace/policy always wins over the local snapshot. All runtime
reads, SQL queries, `/bin/*` actions, and final answer submission go
through the MCP tool `execute_python` — that is the only runtime
boundary. Do NOT use the host shell.

Read `CLAUDE.md` first, then this file, then call `execute_python`
with your first Python snippet.
