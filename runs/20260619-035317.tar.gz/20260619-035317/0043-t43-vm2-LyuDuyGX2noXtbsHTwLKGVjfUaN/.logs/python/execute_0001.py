# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find return record linked to payment pay_027
# Search via SQL first
res = ws.sql_rows(
    "SELECT return_id, record_path, basket_id, customer_id, payment_id, return_status, return_created_at "
    "FROM return_requests WHERE payment_id = 'pay_027'"
)
print("Return records for pay_027:", res)

# Also read the payment record directly
pay = ws.read("/proc/payments/pay_027.json")
print("Payment pay_027:", pay["content"])
