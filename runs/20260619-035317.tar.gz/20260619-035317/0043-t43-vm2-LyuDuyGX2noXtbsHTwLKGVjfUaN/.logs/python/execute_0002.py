# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read the return record and basket to complete the gate evidence set
ret = ws.read("/proc/returns/ret_014.json")
print("Return ret_014:", ret["content"])

basket = ws.read("/proc/baskets/basket_227.json")
print("Basket basket_227:", basket["content"])
