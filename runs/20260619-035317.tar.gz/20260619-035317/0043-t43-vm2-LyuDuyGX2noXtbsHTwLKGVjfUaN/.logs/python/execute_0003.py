# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read AGENTS.MD for answer format guidance
agents_md = ws.read("/AGENTS.MD")
print(agents_md["content"][:2000])
