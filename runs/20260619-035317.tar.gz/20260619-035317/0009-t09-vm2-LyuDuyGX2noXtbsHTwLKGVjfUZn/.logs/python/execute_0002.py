# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read the policy update file
update = ws.read("/docs/current-updates/catalogue-counting-2025-06-22-wood-drywall-screws.md")
print("UPDATE FILE:\n", update["content"])

# Read /docs/README.md for the catalogue reporting rule
readme = ws.read("/docs/README.md")
print("\nREADME:\n", readme["content"])
