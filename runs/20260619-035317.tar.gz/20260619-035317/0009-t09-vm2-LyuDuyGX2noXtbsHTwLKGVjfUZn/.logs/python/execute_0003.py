# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Count products with product_kind_id = 'wood_drywall_screws'
res = ws.sql_rows("SELECT COUNT(*) as cnt FROM product_variants WHERE product_kind_id = 'wood_drywall_screws'")
count = res["rows"][0]["cnt"]
print("Count:", count)

# Update scratchpad
scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue count question for product kind Wood and Drywall Screw"
}
scratchpad["decision"] = {
    "product_kind_id": "wood_drywall_screws",
    "product_kind_name": "Wood and Drywall Screw",
    "count": count,
    "policy_update_applied": "/docs/current-updates/catalogue-counting-2025-06-22-wood-drywall-screws.md",
    "policy_update_scope": "operating day 2025-06-22, product kind wood_drywall_screws, normal count formula — no inventory/display/family filters",
    "catalogue_reporting_rule": "/docs/README.md"
}
print("Scratchpad updated")
