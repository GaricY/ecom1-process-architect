# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Final submission
# Refs: /docs/README.md (catalogue reporting rule) + matched update doc
refs = [
    "/docs/README.md",
    "/docs/current-updates/catalogue-counting-2025-06-22-wood-drywall-screws.md"
]

message = "<COUNT:3>"

submit_and_exit(
    message=message,
    outcome="OUTCOME_OK",
    refs=refs
)
