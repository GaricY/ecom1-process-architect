# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Step 1: Find product_kind_ids for Pliers and Wrenches
kinds_res = ws.sql_rows("""
    SELECT product_kind_id, product_kind_name
    FROM product_kinds
    WHERE LOWER(product_kind_name) IN ('pliers', 'wrenches')
""")
print("Product kinds:", kinds_res["rows"])

# Step 2: Check /docs tree for potential policy updates (catalogue count report)
docs_tree = ws.tree(root="/docs", level=2)
import json
print("Docs tree:", json.dumps(docs_tree, indent=2))
