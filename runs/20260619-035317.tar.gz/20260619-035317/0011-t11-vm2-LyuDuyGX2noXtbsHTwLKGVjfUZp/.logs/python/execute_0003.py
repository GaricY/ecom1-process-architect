# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find open stores in Graz
graz_stores = ws.sql_rows("""
    SELECT store_id, store_name, city, is_open, record_path
    FROM stores
    WHERE LOWER(city) = 'graz' AND is_open = 1
""")
print("Open Graz stores:", graz_stores["rows"])

# Count distinct SKUs of pliers_wrenches that have available_today_quantity > 0
# in at least one open Graz store
count_res = ws.sql_rows("""
    SELECT COUNT(DISTINCT pv.product_sku) AS count
    FROM product_variants pv
    JOIN store_inventory si ON si.product_sku = pv.product_sku
    JOIN stores s ON s.store_id = si.store_id
    WHERE pv.product_kind_id = 'pliers_wrenches'
      AND LOWER(s.city) = 'graz'
      AND s.is_open = 1
      AND si.available_today_quantity > 0
""")
print("Count:", count_res["rows"])
