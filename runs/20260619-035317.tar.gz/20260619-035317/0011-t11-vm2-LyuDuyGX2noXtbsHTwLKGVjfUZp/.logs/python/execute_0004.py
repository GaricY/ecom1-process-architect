# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["business_process"] = {
    "primary": "product_discovery.md",
    "reason": "Catalogue count question for Pliers and Wrenches product kind with a matching dated policy update"
}

scratchpad["decision"] = {
    "policy_update_applied": "/docs/policy-updates/2024-07-17-catalogue-reporting-pliers-wrenches-graz.md",
    "policy_update_rule": "Count only SKUs with available_today_quantity > 0 in at least one open PowerTool store in Graz; count each SKU once",
    "product_kind_id": "pliers_wrenches",
    "graz_open_stores": ["store_graz_jakomini", "store_graz_lend"],
    "count": 12,
    "operating_day_match": "2024-07-17 == /bin/date 2024-07-17"
}

refs = [
    "/docs/README.md",
    "/docs/policy-updates/2024-07-17-catalogue-reporting-pliers-wrenches-graz.md"
]

submit_and_exit(
    message="<COUNT:12>",
    outcome="OUTCOME_OK",
    refs=refs
)
