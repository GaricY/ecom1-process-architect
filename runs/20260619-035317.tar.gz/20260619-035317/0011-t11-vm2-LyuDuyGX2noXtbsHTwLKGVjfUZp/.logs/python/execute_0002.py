# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Read the policy update file - it's about catalogue reporting for pliers/wrenches
policy_update = ws.read("/docs/policy-updates/2024-07-17-catalogue-reporting-pliers-wrenches-graz.md")
print("POLICY UPDATE:")
print(policy_update["content"])

# Also list all product kinds to find exact names
all_kinds = ws.sql_rows("SELECT product_kind_id, product_kind_name FROM product_kinds ORDER BY product_kind_name")
print("\nAll product kinds:")
for k in all_kinds["rows"]:
    print(k)

# Also read /docs/README.md for catalogue reporting rule
readme = ws.read("/docs/README.md")
print("\nDOCS README:")
print(readme["content"])
