# Business processes

Short, MVP-grade reminders that apply to every task. They are not a
substitute for the live `/docs/*.md` active policies — they are the
process discipline you must follow regardless of which task you draw.

- [bp_general.md](bp_general.md) — orientation, source-of-truth ladder,
  mutation preflight.
- [bp_refs_and_submission.md](bp_refs_and_submission.md) — refs hygiene
  and `submit_and_exit` discipline.
