# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

ident = ws.id()
print("ID:", ident)
print("---")
# Find store
print("stores tree:")
print(ws.list("/proc/stores"))
print("---")
rows = ws.sql("SELECT path, store_id, name FROM stores WHERE name LIKE '%Graz%' OR name LIKE '%PowerTool%' LIMIT 20")
print("stores match:", rows)
print("---")
# Check security doc head
print(ws.read("/docs/security.md", end_line=80))
