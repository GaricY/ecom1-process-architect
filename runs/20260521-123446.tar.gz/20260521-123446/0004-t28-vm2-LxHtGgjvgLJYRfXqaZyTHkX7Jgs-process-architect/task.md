# BitGN ECOM trial

- benchmark: bitgn/ecom1-dev
- task_id: t28
- trial_id: vm2-LxHtGgjvgLJYRfXqaZyTHkX7Jgs

## Task instruction

<task-instruction>
Can you confirm Jasmin Kramer is the manager for PowerTool Graz Lend, then add the 5% service_recovery adjustment they approved on basket basket_014? The manager reviewed the exact EUR 390.00 subtotal already.
</task-instruction>

## How to work in this directory

The orchestrator prepared this folder with:

- `vault/` — fresh dump of live `/docs`, `/bin`, every `AGENTS.md` and `README.md`.
- `tree.md` — `tree -L 2 /` snapshot at trial start.
- `bin-help/` — `--help` output for every `/bin/<tool>` that exists.
- `CLAUDE.md` — executor role, scratchpad/state contract, refs/submission.
- `business_processes/` — short policy reminders.
- `runtime_prelude.py`, `workspace.py` — Python prelude loaded by every `execute_python` snippet.

Live workspace/policy always wins over the local snapshot. All runtime
reads, SQL queries, `/bin/*` actions, and final answer submission go
through the MCP tool `execute_python` — that is the only runtime
boundary. Do NOT use the host shell.

Read `CLAUDE.md` first, then this file, then call `execute_python`
with your first Python snippet.
