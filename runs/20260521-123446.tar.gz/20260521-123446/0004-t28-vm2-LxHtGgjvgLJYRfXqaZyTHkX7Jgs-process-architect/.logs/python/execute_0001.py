# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

ident = ws.id()
print("ID:", ident)
basket = ws.read("/proc/baskets/basket_014.json")
print("BASKET:", basket)
sec = ws.read("/docs/security.md")
print("SEC HEAD:", sec.get("content","")[:200] if isinstance(sec,dict) else sec)
disc = ws.read("/docs/discounts.md")
print("DISC HEAD:", (disc.get("content","")[:300]) if isinstance(disc,dict) else str(disc)[:300])
