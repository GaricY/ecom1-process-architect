# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

submit_and_exit(message="Applied 10% service_recovery discount to basket_037.", outcome="OUTCOME_OK", refs=["/docs/security.md", "/docs/discounts.md", "/proc/baskets/basket_037.json"])
