# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# First: identity, find customer, baskets
me = ws.id()
print("ID:", me)
print()
today = ws.date()
print("DATE:", today)
