# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["decision"] = "Applied 10% service_recovery discount on basket_037 (last active basket of cust_071 in emp_011's store store_graz_jakomini). Subtotal 7*6100=42700 cents >= 15000 → max tier 10%. Line eligible (quantity 7 <= available_today 7)."
scratchpad["refs"] = ["/docs/security.md", "/docs/discounts.md", "/proc/baskets/basket_037.json"]
submit_and_exit(message="Applied 10% service_recovery discount to basket_037.", outcome=OUTCOME_OK, refs=scratchpad["refs"])
