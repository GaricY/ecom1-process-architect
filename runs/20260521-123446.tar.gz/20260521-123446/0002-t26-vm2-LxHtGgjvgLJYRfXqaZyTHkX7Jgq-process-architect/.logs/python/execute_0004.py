# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# basket_037 in store_graz_jakomini
b = ws.read("/proc/baskets/basket_037.json")
print(b)
lines = ws.sql("SELECT bl.line_no, bl.sku, bl.quantity, p.price_cents, inv.available_today FROM basket_lines bl LEFT JOIN products p ON p.sku=bl.sku LEFT JOIN inventory inv ON inv.sku=bl.sku AND inv.store_id='store_graz_jakomini' WHERE bl.basket_id='basket_037' ORDER BY bl.line_no")
print(lines)
