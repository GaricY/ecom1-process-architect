# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Subtotal 7*6100=42700 >= 15000 → max 10%
# Apply discount
r = ws.exec_tool("/bin/discount", args=["basket_037", "10", "service_recovery", "emp_011"])
print("DISCOUNT:", r)
b2 = ws.read("/proc/baskets/basket_037.json")
print("POST:", b2)
