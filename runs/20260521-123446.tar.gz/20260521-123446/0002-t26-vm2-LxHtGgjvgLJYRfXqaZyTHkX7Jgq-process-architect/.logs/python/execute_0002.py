# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

emp = ws.read("/proc/employees/emp_011.json")
print(emp)
# Find customer
rows = ws.sql("SELECT id, email FROM customers WHERE email='paul.weber+cust545@fastmail.com'")
print("CUST:", rows)
