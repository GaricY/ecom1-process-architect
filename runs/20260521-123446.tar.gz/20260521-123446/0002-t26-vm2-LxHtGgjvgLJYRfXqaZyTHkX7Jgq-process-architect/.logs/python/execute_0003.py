# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

# Find baskets of cust_071 in store_graz_jakomini that are active (checkoutable)
rows = ws.sql("SELECT id, customer_id, store_id, status, created_at, discount_percent, discount_reason_code FROM baskets WHERE customer_id='cust_071' ORDER BY created_at DESC")
print(rows)
