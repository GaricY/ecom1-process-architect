# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

ident = ws.id()
print("ID:", ident)
basket = ws.read("/proc/baskets/basket_224.json")
print("BASKET:", basket)
payment = ws.read("/proc/payments/pay_024.json")
print("PAYMENT:", payment)
