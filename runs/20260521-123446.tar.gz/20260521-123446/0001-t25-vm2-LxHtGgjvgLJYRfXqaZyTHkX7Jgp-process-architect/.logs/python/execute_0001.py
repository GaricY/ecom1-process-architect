# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

print("ID:", ws.id())
print("---basket---")
print(ws.read("/proc/baskets/basket_054.json"))
