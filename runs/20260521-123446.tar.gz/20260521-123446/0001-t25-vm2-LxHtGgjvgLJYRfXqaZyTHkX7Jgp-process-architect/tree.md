tree l2 /
//
├── AGENTS.MD
├── bin/
│   ├── checkout
│   ├── date
│   ├── discount
│   ├── id
│   ├── payments
│   ├── README.md
│   └── sql
├── docs/
│   ├── checkout.md
│   ├── discounts.md
│   ├── merchant-continuity-and-critical-incidents.md
│   ├── payments/
│   ├── powertools-agentic-os-origin-story.md
│   ├── README.md
│   ├── security.md
│   ├── store-associate-exception-handbook.md
│   └── warehouse-systems-migration-runbook.md
├── proc/
│   ├── baskets/
│   ├── catalog/
│   ├── customers/
│   ├── employees/
│   ├── payments/
│   ├── README.md
│   ├── returns/
│   └── stores/
└── run/
    └── actions/
