"""Workspace client used by every `execute_python` snippet.

Wraps the BitGN ECOM runtime ConnectRPC client and exposes a single tidy
surface for the agent:

    ws.tree(...), ws.list(...), ws.read(...), ws.search(...), ws.find(...),
    ws.stat(...), ws.sql(...), ws.exec_tool(...), ws.date(), ws.id(),
    ws.answer(scratchpad, verify), ws.write(...), ws.delete(...)

`submit_and_exit(...)` is exposed at the prelude level on top of `ws.answer`
and is the preferred way to finish a task — it merges scratchpad fields,
writes `answer.json`, and exits the snippet with SystemExit(0).

The harness URL is taken from `RUNTIME_HARNESS_URL` in the subprocess
environment. The orchestrator's MCP server sets it just for the subprocess
that runs the snippet; the Claude CLI process and the task directory never
see it.
"""

from __future__ import annotations

import contextlib
import json
import os
import time
from pathlib import Path
from typing import Iterable

from bitgn.vm.ecom.ecom_connect import EcomRuntimeClientSync
from bitgn.vm.ecom.ecom_pb2 import (
    AnswerRequest,
    DeleteRequest,
    ExecRequest,
    FindRequest,
    ListRequest,
    NodeKind,
    Outcome,
    ReadRequest,
    SearchRequest,
    StatRequest,
    TreeRequest,
    WriteRequest,
)
from google.protobuf.json_format import MessageToDict

# Retry layer for every harness RPC. The runtime client has no built-in
# retries, so a transient blip would otherwise surface as an exception
# inside an `execute_python` snippet and burn an agent turn.
_VM_RETRY_ATTEMPTS = 5
_VM_RETRY_BACKOFF_SEC = 0.2


class _RetryingClient:
    """Proxy that retries every callable method on exception."""

    def __init__(self, inner) -> None:
        self._inner = inner

    def __getattr__(self, name: str):
        attr = getattr(self._inner, name)
        if not callable(attr):
            return attr

        def wrapped(*args, **kwargs):
            last_exc = None
            for attempt in range(_VM_RETRY_ATTEMPTS):
                try:
                    return attr(*args, **kwargs)
                except Exception as exc:
                    last_exc = exc
                    if attempt < _VM_RETRY_ATTEMPTS - 1:
                        time.sleep(_VM_RETRY_BACKOFF_SEC * (attempt + 1))
            assert last_exc is not None
            raise last_exc

        return wrapped


_ENV_HARNESS_URL = "RUNTIME_HARNESS_URL"
_ENV_ANSWER_PATH = "ECOM_ANSWER_PATH"
_ENV_TOOL_CALLS_PATH = "ECOM_TOOL_CALLS_PATH"

_KIND_MAP = {
    "all": NodeKind.NODE_KIND_UNSPECIFIED,
    "files": NodeKind.NODE_KIND_FILE,
    "dirs": NodeKind.NODE_KIND_DIR,
}

_OUTCOME_MAP = {
    "OUTCOME_OK": Outcome.OUTCOME_OK,
    "OUTCOME_DENIED_SECURITY": Outcome.OUTCOME_DENIED_SECURITY,
    "OUTCOME_NONE_CLARIFICATION": Outcome.OUTCOME_NONE_CLARIFICATION,
    "OUTCOME_NONE_UNSUPPORTED": Outcome.OUTCOME_NONE_UNSUPPORTED,
    "OUTCOME_ERR_INTERNAL": Outcome.OUTCOME_ERR_INTERNAL,
}


def _to_dict(msg) -> dict:
    return MessageToDict(msg, preserving_proto_field_name=True)


class Workspace:
    def __init__(
        self,
        harness_url: str | None = None,
        answer_path: str | None = None,
        tool_calls_path: str | None = None,
    ) -> None:
        url = harness_url or os.environ.get(_ENV_HARNESS_URL)
        if not url:
            raise RuntimeError(
                f"{_ENV_HARNESS_URL} is not set — Workspace can only be used "
                "inside an execute_python subprocess spawned by the MCP server."
            )
        self._answer_path = answer_path or os.environ.get(_ENV_ANSWER_PATH) or ""
        if not self._answer_path:
            raise RuntimeError(f"{_ENV_ANSWER_PATH} is not set")
        self._vm = _RetryingClient(EcomRuntimeClientSync(url))
        self._tool_calls_path = (
            tool_calls_path or os.environ.get(_ENV_TOOL_CALLS_PATH) or ""
        )

    # ── audit ─────────────────────────────────────────────────────────────
    def _audit(self, tool: str, payload: dict) -> None:
        if not self._tool_calls_path:
            return
        try:
            with open(self._tool_calls_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"tool": tool, **payload}) + "\n")
        except OSError:
            pass

    # ── filesystem reads ──────────────────────────────────────────────────
    def tree(self, root: str = "", level: int = 2) -> dict:
        self._audit("tree", {"root": root, "level": level})
        return _to_dict(self._vm.tree(TreeRequest(root=root, level=level)))

    def list(self, path: str = "/") -> dict:
        self._audit("list", {"path": path})
        return _to_dict(self._vm.list(ListRequest(path=path)))

    def find(
        self,
        root: str = "/",
        name: str = "",
        kind: str = "all",
        limit: int = 10,
    ) -> dict:
        self._audit("find", {"root": root, "name": name, "kind": kind, "limit": limit})
        return _to_dict(
            self._vm.find(
                FindRequest(root=root, name=name, kind=_KIND_MAP[kind], limit=limit)
            )
        )

    def search(self, root: str = "/", pattern: str = "", limit: int = 10) -> dict:
        self._audit("search", {"root": root, "pattern": pattern, "limit": limit})
        return _to_dict(
            self._vm.search(SearchRequest(root=root, pattern=pattern, limit=limit))
        )

    def stat(self, path: str) -> dict:
        self._audit("stat", {"path": path})
        return _to_dict(self._vm.stat(StatRequest(path=path)))

    def read(
        self,
        path: str,
        number: bool = False,
        start_line: int = 0,
        end_line: int = 0,
    ) -> dict:
        self._audit(
            "read",
            {"path": path, "number": number, "start_line": start_line, "end_line": end_line},
        )
        return _to_dict(
            self._vm.read(
                ReadRequest(
                    path=path,
                    number=number,
                    start_line=start_line,
                    end_line=end_line,
                )
            )
        )

    # ── filesystem mutations ──────────────────────────────────────────────
    def write(self, path: str, content: str, if_match_sha256: str = "") -> dict:
        self._audit("write", {"path": path, "bytes": len(content)})
        return _to_dict(
            self._vm.write(
                WriteRequest(path=path, content=content, if_match_sha256=if_match_sha256)
            )
        )

    def delete(self, path: str) -> dict:
        self._audit("delete", {"path": path})
        return _to_dict(self._vm.delete(DeleteRequest(path=path)))

    # ── /bin/* runtime tools ──────────────────────────────────────────────
    def exec_tool(
        self,
        path: str,
        args: Iterable[str] | None = None,
        stdin: str = "",
    ) -> dict:
        """argv-style invoke of a runtime tool, e.g. `/bin/checkout`."""
        argv = list(args) if args else []
        self._audit("exec", {"path": path, "args": argv, "stdin_bytes": len(stdin)})
        return _to_dict(
            self._vm.exec(ExecRequest(path=path, args=argv, stdin=stdin))
        )

    def sql(self, query: str, json_output: bool = True) -> dict:
        args = ["--json"] if json_output else []
        return self.exec_tool("/bin/sql", args=args, stdin=query)

    def date(self) -> dict:
        return self.exec_tool("/bin/date")

    def id(self) -> dict:
        return self.exec_tool("/bin/id")

    # ── terminal answer ───────────────────────────────────────────────────
    def answer(self, scratchpad: dict, verify) -> None:
        if not callable(verify):
            raise ValueError(
                "ws.answer: verify must be a callable that returns True/False."
            )
        try:
            ok = verify(scratchpad)
        except Exception as exc:
            raise ValueError(f"ws.answer: verify raised: {exc}") from exc
        if not ok:
            raise ValueError(
                "ws.answer: verify(scratchpad) returned False — fix scratchpad."
            )

        outcome = scratchpad.get("outcome", "OUTCOME_OK")
        if outcome not in _OUTCOME_MAP:
            raise ValueError(
                f"ws.answer: unknown outcome {outcome!r}; valid: {list(_OUTCOME_MAP)}"
            )
        message = scratchpad.get("answer", scratchpad.get("message", ""))
        refs_raw = scratchpad.get("refs") or []
        refs = [r for r in refs_raw if isinstance(r, str)]

        self._audit(
            "answer",
            {"outcome": outcome, "message_bytes": len(message), "refs": refs},
        )
        self._vm.answer(
            AnswerRequest(message=message, outcome=_OUTCOME_MAP[outcome], refs=refs)
        )

        payload = {"message": message, "outcome": outcome, "refs": refs}
        with contextlib.suppress(OSError):
            Path(self._answer_path).write_text(
                json.dumps(payload, indent=2), encoding="utf-8"
            )
