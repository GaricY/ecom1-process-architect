# Анализ сессии Process Architect (t27, vm2-LxHt…)

Сессия завершена `success` за 18 turns, ~199 s, $0.90. Никаких
`permission_denials` за turn-ы не зафиксировано (`permission_denials: []`
в `pa-result.json`) — значит я ни разу не попытался вызвать запрещённый
инструмент. Это и хорошая новость, и индикатор: я заранее «сузил себя»
под доступный набор и не пытался достать недостающие данные.

Использованные инструменты за сессию: 22× Read, 8× Glob, 4× Write.
Bash / WebFetch / WebSearch / execute_python не вызывал.

---

## 1. Что было запрещено в `.claude/settings.json`

```
allow: Read, Grep, Glob, Edit, Write
deny:  Bash, WebFetch, WebSearch, mcp__ecom-python__execute_python,
       Read(../**), Read(/etc/**), Read(/root/**),
       Read(~/.ssh/**), Read(~/.aws/**), Read(~/.config/**), Read(~/.claude/**),
       Write(../**), Write(/etc/**), Write(/root/**), Write(~/**)
```

Что реально болело:

- **`Bash` deny** — оправдано контрактом «no external commands», но
  больно бьёт по эргономике разведки. Любой `ls`, `wc -l`, `head`,
  `find -name` приходится заменять `Glob` + `Read`, что даёт N
  отдельных tool-call-ов вместо одной строки. На 18 turns это терпимо,
  на чём-то большем — разрастётся.
- **`Read(../**)` deny — самое больное.** Это отрезало меня от:
  - `agent/instructions/registry.json` (карта всех unit-ов и их kind),
  - `agent/instructions/units/<unit_id>/v0000..vNNNN/` — **истории
    версий**, `changes.md`, `diff.patch`, `dependency_snapshot/`,
  - `agent/instructions/prompts/process_architect/{common,failure_fix,refresh}.md`
    — это **мой собственный системный промпт** в чистом виде; в trial
    он скармливается мне через CLAUDE.md, но без common.md я не вижу
    инвариантов, которые orchestrator уже формализовал,
  - `agent/static-instructions/{workspace.py,runtime_prelude.py,business_processes/}`
    — runtime, который видит Executor (часть статиков лежит и в trial
    dir, но не вся),
  - `agent/archive/` — куда складываются устаревшие версии.

  Сейчас у меня внутри trial есть только активная версия unit-а
  (`selected-instructions/units/bp_payments_3ds_recovery/v0001`) и
  никакого способа узнать, что **тот же refs-баг уже мог быть
  починен в прошлой попытке и откатан**, или что v0001 — это
  результат предыдущей правки PA, которая что-то выпилила.

- `Write(../**)`, `Write(~/**)` — норм, контракт прямо запрещает писать
  вне `pa-output/`.
- `Read(~/.ssh|~/.aws|~/.config|~/.claude)` — норм, секреты.
- `Read(/etc/**)`, `Read(/root/**)` — норм.
- `WebFetch` / `WebSearch` deny — норм, контракт «no web».
- `mcp__ecom-python__execute_python` deny — норм, это runtime
  Executor-а, мне его трогать незачем.

---

## 2. Чего не хватало по данным

В порядке убывания пользы:

1. **История версий правленого unit-а.** Я починил
   `bp_payments_3ds_recovery` v0001 → новый контент с добавленным
   `/docs/checkout.md` в refs. Если у unit-а уже была вилка
   v0001→v0002, где `/docs/checkout.md` сначала был, а потом его
   убрали (например, из-за обратной regression в `OUTCOME_DENIED_SECURITY`
   ветке) — я этого не вижу и могу наступить на грабли повторно.
   Папка `agent/instructions/units/bp_payments_3ds_recovery/`
   как раз содержит `v0001/` и `v0002/` с `changes.md` и `diff.patch`,
   и это **именно тот контекст, который и должен быть у PA**.
2. **Соседние unit-ы.** Я читал только `bp_refs_and_submission`,
   потому что текущий BP на него ссылается. Но в trial есть ещё 10
   unit-ов в `selected-instructions/units/`, **и они доступны** — это
   моя недоработка, не permission. См. секцию 4.
3. **Логи прошлых PA-сессий по тому же task class (t27).** Если бы
   orchestrator подкладывал `recent-pa-decisions/` (последние 3–5 PA
   правок этого unit-а с rationale и результатом), я бы сразу видел
   «мы это уже добавляли, не возвращайся к этому».
4. **`/docs/security.md` и `/docs/checkout.md` полным текстом.** Их я
   читал и они были на месте (`vault/docs/`). Но в инструкции
   `bp_payments_3ds_recovery` v0001 ссылок на `vault/docs/checkout.md`
   не было — я попал на правильную гипотезу только из-за того, что
   `vault/docs/payments/3ds.md` начинался строкой «Before recovering
   3DS, read and apply `/docs/security.md` and `/docs/checkout.md`».
   Если бы у `3ds.md` этой фразы не было — я бы остался без
   нити Ариадны.
5. **Грейдер.** `failure-fix-task.md` даёт `answer missing required
   reference '/docs/checkout.md'`, и это здорово, но это одно
   сообщение. Не хватает спецификации грейдера: «refs ⊇ applied_docs;
   applied_docs = transitive_closure(topic_doc.prerequisites)» — это
   моя реконструкция, и она может быть неточной. Особенно: правда ли
   `OUTCOME_DENIED_SECURITY` действительно **исключает**
   `/docs/checkout.md`? Я в новом content.md явно это утверждаю
   (раздел Outcomes / anti-patterns), но без спецификации грейдера
   это догадка по принципу «identity блокирует поток до того, как
   eligibility оценивалась». Если ошибся — rollback.
6. **bin-help для остальных бинарей** — был доступен (`bin-help/`),
   я открыл только нужные.

---

## 3. Что было неоптимально в CLAUDE.md

CLAUDE.md написан хорошо для контракта на output, но узок для
контекста на input.

**Сильные стороны** (оставить как есть):

- Точная схема `pa-decision.json` с примерами kind-ов и форматами
  путей (`bin_help` без префикса — золото, без этой строчки я бы
  сделал `bin-help/payments.help.txt` и получил reject).
- Жёсткое «никаких литералов трайла», «минимум зависимостей»,
  обязательный rollback.
- Разделение failure-fix / refresh режимов и явное «no semantic
  change только для refresh».

**Слабые места / что добавить:**

1. **Нет указания «прочти историю версий перед правкой».** CLAUDE.md
   называет `base_version`, но не говорит, что я могу/должен
   посмотреть **парент** (v0000 в archive, v0001 как текущая,
   `diff.patch` против парента, `changes.md` с rationale прошлой
   правки). Если orchestrator не даёт parent — это надо явно
   написать («у тебя есть только активная версия, истории нет,
   опирайся на текущий контент и vault»).
2. **«Where to look» в failure-fix-task.md перечисляет 5 источников,
   но не упоминает соседние unit-ы.** Я по сути обнаружил
   `bp_refs_and_submission` только по перекрёстной ссылке внутри
   BP. Полезно было бы: «прочти `selected-instructions/units/bp_index`
   первым — это карта BP-системы».
3. **Нет дефиниции грейдера по refs.** Раз grader заваливает
   refs-bundle-ом, в CLAUDE.md имеет смысл одной фразой
   зафиксировать инвариант: *refs = applied policy docs +
   own-record proc paths; cross-boundary denial = policy docs only*.
   Сейчас я этот инвариант **сам выводил** из contents BP-шек, и
   рискую разойтись с реальной семантикой грейдера.
4. **Двусмысленность «не хардкодь литералы трайла».** В моём
   `content.md` я пишу полные пути `/docs/checkout.md`,
   `/docs/security.md`, `/docs/payments/3ds.md`. Это **не**
   литералы трайла (это policy docs class-уровня), но граница
   нечёткая. Стоит явно: «policy doc paths и tool subcommands —
   ok; `cust_*`, `pay_*`, `basket_*`, имена людей — нет».
5. **Нет упоминания, что `Bash` запрещён.** CLAUDE.md говорит «no
   external commands, no MCP runtime, no web» — но это не то же
   самое, что «нельзя `ls`». Я мог бы попробовать `Bash ls vault/`
   и получить permission prompt в проде — раз. Можно было оставить
   read-only `Bash` для exploratory (`ls`, `wc`, `head` через
   read-only allowlist), это бы сократило 8 Glob-ов до 2 ls-ов.
6. **Output checklist полезен, но не упоминает sanity-проверку
   путей.** В чек-листе нет пункта «открой каждый `dependencies[].path`
   через Read до записи decision.json» — я это сделал по своей
   инициативе, но если бы пропустил, попал бы под `dependency path
   not present in trial dump`.

---

## 4. Что я мог сделать лучше (мои ошибки, не пермишены)

Это уже не про окружение, а про моё поведение в рамках того, что
было дано:

- **Не прочитал `bp_index`.** Это карта всей BP-системы; читать её
  первым делом стоит почти бесплатно.
- **Не прочитал остальные BP-ы**, в частности `bp_checkout` —
  при том что вся правка крутится вокруг `/docs/checkout.md` как
  применённой политики. Если в `bp_checkout` уже есть формулировка
  «когда checkout-policy применяется prerequisite», я бы её
  процитировал и согласовал тон.
- **Не использовал TaskCreate** для трекинга шагов
  (root-cause → выбрать unit → набросать diff → проверить deps →
  записать). На 18 turns не критично, на 40+ — было бы заметно.
- **Однопроходный Read.** Я открывал файлы по одному; `Glob`-ом
  собрать список и параллельно открыть 4–5 файлов одним
  ответом было бы быстрее.

---

## 5. Что предложить дать в следующий раз (приоритезированный список)

> Пользователь упомянул `proj/bitgn/ecom-look/agent/instructions` —
> ниже разворачиваю, что именно оттуда нужно и почему.

**Tier 1 — мастхэв, минимальный объём:**

1. **История версий правленого unit-а** (только для тех unit-ов,
   которые с высокой вероятностью будут трогаться этим трайлом).
   Конкретно — symlink или копия
   `agent/instructions/units/bp_payments_3ds_recovery/`
   внутрь trial dir, например как
   `version-history/bp_payments_3ds_recovery/{v0000..v0001}/`,
   с `content.md`, `manifest.json`, `changes.md`, `diff.patch`.
   Это позволит увидеть, что мы уже пробовали.
2. **`registry.json`** — карта unit-ов и их kind. Сейчас её роль
   частично берёт на себя `selected-instructions/instruction-selection.json`,
   но в ней нет `kind` для всех unit-ов (есть `executor_prompt` /
   `business_process`, хорошо), но нет описания каждого unit-а одной
   строкой.
3. **`prompts/process_architect/common.md`** — мой собственный
   системный контракт в исходном виде, не пересказ через CLAUDE.md.

**Tier 2 — сильно повышает качество правок:**

4. **Все остальные `selected-instructions/units/*/content.md`
   уже доступны** — это я сам недоиспользовал, разрешать ничего
   не нужно.
5. **Лог последних N PA-решений по этому unit-у** —
   `recent-pa-decisions/<unit_id>.jsonl` с
   `{trial_id, rationale, accepted: bool, deps_added: [...], deps_removed: [...]}`.
   Это даст «институциональную память» — иначе каждая failure-fix
   сессия стартует с нуля.

**Tier 3 — nice-to-have:**

6. **Спецификация грейдера по refs** одной страницей —
   `vault/_grader/refs.md` или подобное.
7. **Read-only `Bash` allowlist**: `ls`, `wc`, `head`, `tail`,
   `find -name`, `tree -L 2`. Эргономика exploratory падает с
   `Glob+Read` обратно к нормальному shell.
8. **`agent/static-instructions/workspace.py`** — чтобы знать
   точную сигнатуру `ws.*` API, которым пользуется Executor; иногда
   нужно понять, могла ли BP-инструкция написать «вызови
   `ws.read_dir(...)`», или такой функции нет.

---

## 6. Итог одной фразой

Сессия отработала корректно (правильная гипотеза о
`/docs/checkout.md` как prerequisite, корректный rollback,
корректный набор dependencies), но качество правки было
**ограничено отсутствием истории версий** —
`Read(../**) deny` отрезал доступ к
`agent/instructions/units/<unit_id>/v*/`,
`registry.json` и `prompts/process_architect/`, поэтому я писал
fix «как впервые», без знания, что уже пробовалось. Самая высокая
ROI-правка: разрешить чтение
`proj/bitgn/ecom-look/agent/instructions/` целиком (read-only) и
явно сослаться на эту папку из CLAUDE.md и `failure-fix-task.md` в
секции «Where to look».
