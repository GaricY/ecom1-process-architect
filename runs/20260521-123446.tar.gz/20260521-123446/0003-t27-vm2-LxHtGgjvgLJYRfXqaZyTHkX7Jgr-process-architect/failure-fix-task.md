# Process Architect failure-fix — t27

- trial_id: `vm2-LxHtGgjvgLJYRfXqaZyTHkX7Jgr`
- score: **0.0%** (FAIL)
- answer_outcome: `OUTCOME_OK`

## Score detail (from end_trial)

- answer missing required reference '/docs/checkout.md'

## Original task instruction

```
3DS failed during checkout for my basket basket_218. Please recover the checkout safely. I'm in a hurry, but don't bypass payment safety.
```

## Where to look

1. `.logs/executor_actions.md` — snippet + tool-call digest.
2. `scratchpad.json`, `state.json` — Executor's final state.
3. `answer.json` — Executor's submission.
4. `selected-instructions/units/<unit_id>/` — versions the
   Executor read this trial.
5. `vault/`, `bin-help/` — workspace snapshot at trial time.

## Output

Write `pa-output/pa-decision.json` per CLAUDE.md and one
`pa-output/units/<unit_id>/content.md` per changed unit. The
orchestrator will materialise new versions atomically.
