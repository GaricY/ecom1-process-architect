# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

scratchpad["decision"] = "Recovered 3DS for pay_018 (basket_218). Identity cust_069 owns the payment. Basket checked_out, payment requires_3ds_action, three_ds.status was 3ds-status2 with attempts 2<3. Ran /bin/payments recover-3ds pay_018; post-state: status still requires_3ds_action with fresh 3ds-status1 challenge."
scratchpad["refs"] = [
  "/docs/security.md",
  "/docs/payments/3ds.md",
  "/proc/payments/pay_018.json",
  "/proc/baskets/basket_218.json",
]
submit_and_exit(
    message="3DS recovery started for pay_018; payment remains requires_3ds_action with a fresh challenge.",
    outcome="OUTCOME_OK",
    refs=scratchpad["refs"],
)
