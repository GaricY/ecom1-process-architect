# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import json
res = ws.exec_tool("/bin/payments", args=["recover-3ds", "pay_018"])
print("RECOVER:", res)
pay = ws.read("/proc/payments/pay_018.json")
print("POST:", pay)
