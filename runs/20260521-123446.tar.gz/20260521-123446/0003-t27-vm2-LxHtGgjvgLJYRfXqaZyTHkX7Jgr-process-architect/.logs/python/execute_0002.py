# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

pay = ws.read("/proc/payments/pay_018.json")
print(pay)
