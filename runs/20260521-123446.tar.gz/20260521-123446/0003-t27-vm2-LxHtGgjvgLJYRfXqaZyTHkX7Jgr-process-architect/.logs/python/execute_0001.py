# Auto-prepended by execute_python; do not duplicate exec().
exec(open('runtime_prelude.py').read())
# --- agent code below ---

import json
me = ws.id()
print("ID:", json.dumps(me, indent=2))
basket = ws.read("/proc/baskets/basket_218.json")
print("BASKET:", basket)
# Find payment for basket_218
rows = ws.sql("SELECT id, basket_id, customer_id, status, path FROM payments WHERE basket_id='basket_218'")
print("PAYMENTS:", json.dumps(rows, indent=2))
